/* 用户管理端逻辑：三级角色权限、统计、用户列表分页/筛选、增删改、重置密码 */

let currentAdmin = null;
let query = { page: 1, page_size: 10, keyword: '', role: '', status: '' };
let totalUsers = 0;
let passwordTarget = null;

// 角色权限层级（与后端 ROLE_LEVELS 一致）
const ROLE_LEVELS = { user: 1, admin: 2, super_admin: 3 };
const ROLE_LABELS = {
    super_admin: '超级管理员',
    admin: '管理员',
    user: '普通用户'
};

// ==================== 视图切换 ====================
function showView(name) {
    document.getElementById('login-view').style.display = name === 'login' ? 'flex' : 'none';
    document.getElementById('forbidden-view').style.display = name === 'forbidden' ? 'flex' : 'none';
    document.getElementById('admin-main').style.display = name === 'main' ? 'block' : 'none';
}

function showError(elementId, msg) {
    const el = document.getElementById(elementId);
    el.textContent = msg;
    el.style.display = 'block';
}

function hideError(elementId) {
    const el = document.getElementById(elementId);
    el.textContent = '';
    el.style.display = 'none';
}

function escapeHtml(text) {
    return String(text == null ? '' : text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

// 判断操作者能否管理目标用户（op_level > tgt_level）
function canManage(targetRole) {
    if (!currentAdmin) return false;
    return ROLE_LEVELS[currentAdmin.role] > ROLE_LEVELS[targetRole];
}

// ==================== 鉴权 ====================
async function checkAccess() {
    try {
        const resp = await fetch('/api/auth/me');
        if (resp.status === 401) { showView('login'); return; }
        const data = await resp.json();
        if (data.success && data.user) {
            if (ROLE_LEVELS[data.user.role] >= ROLE_LEVELS.admin) {
                enterAdmin(data.user);
            } else {
                currentAdmin = null;
                document.getElementById('forbidden-username').textContent = data.user.username;
                showView('forbidden');
            }
            return;
        }
        showView('login');
    } catch (err) {
        console.error('鉴权检查失败:', err);
        showView('login');
    }
}

function enterAdmin(user) {
    currentAdmin = user;
    const roleLabel = ROLE_LABELS[user.role] || user.role;
    document.getElementById('current-admin').textContent = '👤 ' + user.username + '（' + roleLabel + '）';
    document.getElementById('current-admin').style.display = 'inline';
    document.getElementById('header-logout').style.display = 'inline-block';
    // 管理员只能创建普通用户，隐藏高角色选项
    if (user.role === 'admin') {
        document.getElementById('create-role').innerHTML =
            '<option value="user">普通用户（使用课件与知识库功能）</option>';
    }
    showView('main');
    loadStats();
    loadUsers();
}

async function adminLogin() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    hideError('login-error');

    if (!username || !password) {
        showError('login-error', '请输入用户名和密码');
        return;
    }

    const btn = document.getElementById('login-submit');
    btn.disabled = true;
    btn.textContent = '登录中...';

    try {
        const resp = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password})
        });
        const data = await resp.json();

        if (!data.success) {
            showError('login-error', data.error || '登录失败');
            return;
        }
        if (ROLE_LEVELS[data.user.role] < ROLE_LEVELS.admin) {
            document.getElementById('forbidden-username').textContent = data.user.username;
            showView('forbidden');
            return;
        }
        document.getElementById('login-password').value = '';
        enterAdmin(data.user);
    } catch (err) {
        console.error('登录请求失败:', err);
        showError('login-error', '网络错误，请稍后重试');
    } finally {
        btn.disabled = false;
        btn.textContent = '登录';
    }
}

async function adminLogout() {
    if (!confirm('确定退出登录吗？')) return;
    try {
        await fetch('/api/auth/logout', {method: 'POST'});
    } catch (err) {
        console.error('退出失败:', err);
    }
    currentAdmin = null;
    document.getElementById('current-admin').style.display = 'none';
    document.getElementById('header-logout').style.display = 'none';
    showView('login');
}

// ==================== 统计 ====================
async function loadStats() {
    try {
        const resp = await fetch('/api/admin/stats');
        if (resp.status === 401) { showView('login'); return; }
        if (resp.status === 403) { showView('forbidden'); return; }
        const data = await resp.json();
        if (data.success) {
            const s = data.stats;
            document.getElementById('stat-total').textContent = s.total;
            document.getElementById('stat-active').textContent = s.active;
            document.getElementById('stat-disabled').textContent = s.disabled;
            document.getElementById('stat-super-admins').textContent = s.super_admins;
            document.getElementById('stat-admins').textContent = s.admins;
            document.getElementById('stat-today').textContent = s.new_today;
        }
    } catch (err) {
        console.error('加载统计失败:', err);
    }
}

// ==================== 用户列表 ====================
async function loadUsers() {
    const params = new URLSearchParams({
        page: query.page,
        page_size: query.page_size,
        keyword: query.keyword,
        role: query.role,
        status: query.status
    });
    try {
        const resp = await fetch('/api/admin/users?' + params.toString());
        if (resp.status === 401) { showView('login'); return; }
        if (resp.status === 403) { showView('forbidden'); return; }
        const data = await resp.json();
        if (!data.success) {
            alert(data.error || '加载用户列表失败');
            return;
        }
        totalUsers = data.total;
        renderUsers(data.users);
        renderPagination();
    } catch (err) {
        console.error('加载用户列表失败:', err);
        alert('网络错误，加载用户列表失败');
    }
}

function roleBadgeHtml(role) {
    if (role === 'super_admin') return '<span class="badge badge-super-admin">超级管理员</span>';
    if (role === 'admin') return '<span class="badge badge-admin">管理员</span>';
    return '<span class="badge badge-user">普通用户</span>';
}

function renderUsers(users) {
    const tbody = document.getElementById('users-tbody');
    const empty = document.getElementById('table-empty');

    if (!users.length) {
        tbody.innerHTML = '';
        empty.style.display = 'block';
        return;
    }
    empty.style.display = 'none';

    tbody.innerHTML = users.map(function(u) {
        const isSelf = currentAdmin && u.id === currentAdmin.id;
        const manageable = !isSelf && canManage(u.role);

        const statusBadge = u.status === 'active'
            ? '<span class="badge badge-active">正常</span>'
            : '<span class="badge badge-disabled">已禁用</span>';

        // 角色切换按钮（仅超管可见，管理员不显示角色按钮）
        let roleBtns = '';
        if (manageable && currentAdmin.role === 'super_admin') {
            if (u.role === 'user') {
                roleBtns = '<button class="row-btn" onclick="toggleRole(' + u.id + ',&#39;admin&#39;)">设为管理员</button>'
                    + '<button class="row-btn" onclick="toggleRole(' + u.id + ',&#39;super_admin&#39;)">设为超管</button>';
            } else if (u.role === 'admin') {
                roleBtns = '<button class="row-btn" onclick="toggleRole(' + u.id + ',&#39;super_admin&#39;)">设为超管</button>'
                    + '<button class="row-btn warn" onclick="toggleRole(' + u.id + ',&#39;user&#39;)">降为普通用户</button>';
            }
        }

        // 状态按钮（有权管理时显示）
        let statusBtn = '';
        if (manageable) {
            statusBtn = u.status === 'active'
                ? '<button class="row-btn warn" onclick="toggleStatus(' + u.id + ',&#39;disabled&#39;)">禁用</button>'
                : '<button class="row-btn ok" onclick="toggleStatus(' + u.id + ',&#39;active&#39;)">启用</button>';
        }

        // 密码按钮（有权管理时显示，自己也可重置）
        let passwordBtn = (manageable || isSelf)
            ? '<button class="row-btn" onclick="openPasswordModal(' + u.id + ')">重置密码</button>'
            : '';

        // 删除按钮（仅有权管理时显示）
        let deleteBtn = manageable
            ? '<button class="row-btn danger" onclick="deleteUser(' + u.id + ')">删除</button>'
            : '';

        let actions;
        if (isSelf) {
            actions = '<span class="self-tip">当前登录账号</span>' + passwordBtn;
        } else if (!manageable) {
            actions = '<span class="self-tip">无权管理</span>';
        } else {
            actions = statusBtn + roleBtns + passwordBtn + deleteBtn;
        }

        return '<tr' + (isSelf ? ' class="row-self"' : '') + '>'
            + '<td>' + u.id + '</td>'
            + '<td class="cell-name">' + escapeHtml(u.username) + (isSelf ? ' <span class="self-tag">(我)</span>' : '') + '</td>'
            + '<td>' + roleBadgeHtml(u.role) + '</td>'
            + '<td>' + statusBadge + '</td>'
            + '<td>' + escapeHtml(u.created_at || '-') + '</td>'
            + '<td class="cell-actions">' + actions + '</td>'
            + '</tr>';
    }).join('');
}

function renderPagination() {
    const container = document.getElementById('pagination');
    const totalPages = Math.max(1, Math.ceil(totalUsers / query.page_size));
    if (query.page > totalPages) { query.page = totalPages; }

    let html = '<button class="page-btn" ' + (query.page <= 1 ? 'disabled' : '')
        + ' onclick="gotoPage(' + (query.page - 1) + ')">上一页</button>';

    let start = Math.max(1, query.page - 3);
    let end = Math.min(totalPages, start + 6);
    start = Math.max(1, end - 6);
    for (let p = start; p <= end; p++) {
        html += '<button class="page-btn ' + (p === query.page ? 'active' : '')
            + '" onclick="gotoPage(' + p + ')">' + p + '</button>';
    }

    html += '<button class="page-btn" ' + (query.page >= totalPages ? 'disabled' : '')
        + ' onclick="gotoPage(' + (query.page + 1) + ')">下一页</button>';
    html += '<span class="page-info">共 ' + totalUsers + ' 人，第 ' + query.page + ' / ' + totalPages + ' 页</span>';
    container.innerHTML = html;
}

function gotoPage(page) {
    query.page = page;
    loadUsers();
}

// ==================== 筛选 ====================
function applyFilters() {
    query.keyword = document.getElementById('filter-keyword').value.trim();
    query.role = document.getElementById('filter-role').value;
    query.status = document.getElementById('filter-status').value;
    query.page = 1;
    loadUsers();
}

function resetFilters() {
    document.getElementById('filter-keyword').value = '';
    document.getElementById('filter-role').value = '';
    document.getElementById('filter-status').value = '';
    query.keyword = '';
    query.role = '';
    query.status = '';
    query.page = 1;
    loadUsers();
}

function handleSearchKey(event) {
    if (event.key === 'Enter') applyFilters();
}

document.getElementById('login-password').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') adminLogin();
});
document.getElementById('login-username').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') document.getElementById('login-password').focus();
});

// ==================== 行操作 ====================
async function updateUser(userId, payload, confirmMessage) {
    if (confirmMessage && !confirm(confirmMessage)) return;
    try {
        const resp = await fetch('/api/admin/users/' + userId, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });
        const data = await resp.json();
        if (data.success) {
            loadUsers();
            loadStats();
        } else {
            alert(data.error || '操作失败');
        }
    } catch (err) {
        console.error('更新用户失败:', err);
        alert('网络错误，操作失败');
    }
}

function toggleStatus(userId, newStatus) {
    if (newStatus === 'disabled') {
        updateUser(userId, {status: 'disabled'},
            '确定禁用该账号吗？禁用后对方将立即无法登录和使用系统，历史数据保留。');
    } else {
        updateUser(userId, {status: 'active'}, '确定启用该账号吗？');
    }
}

function toggleRole(userId, newRole) {
    const label = ROLE_LABELS[newRole] || newRole;
    const msg = newRole === 'user'
        ? '确定将该用户降为普通用户吗？降级后将无法进入管理端。'
        : '确定将该用户设为' + label + '吗？';
    updateUser(userId, {role: newRole}, msg);
}

async function deleteUser(userId) {
    if (!confirm('确定删除该用户账号吗？此操作不可恢复（其历史课件与知识库文档会保留）。')) return;
    try {
        const resp = await fetch('/api/admin/users/' + userId, {method: 'DELETE'});
        const data = await resp.json();
        if (data.success) {
            loadUsers();
            loadStats();
        } else {
            alert(data.error || '删除失败');
        }
    } catch (err) {
        console.error('删除用户失败:', err);
        alert('网络错误，删除失败');
    }
}

// ==================== 重置密码弹窗 ====================
function openPasswordModal(userId) {
    let username = '';
    document.querySelectorAll('#users-tbody tr').forEach(function(tr) {
        if (tr.querySelector('.cell-actions') &&
            tr.querySelector('.cell-actions').innerHTML.indexOf('openPasswordModal(' + userId + ')') !== -1) {
            const nameCell = tr.querySelector('.cell-name');
            if (nameCell) username = nameCell.textContent.replace('(我)', '').trim();
        }
    });
    passwordTarget = userId;
    document.getElementById('password-username').textContent = username ? username : ('ID ' + userId);
    document.getElementById('password-new').value = '';
    hideError('password-error');
    document.getElementById('password-modal').style.display = 'flex';
    document.getElementById('password-new').focus();
}

function closePasswordModal() {
    document.getElementById('password-modal').style.display = 'none';
    passwordTarget = null;
}

async function submitPassword() {
    const newPassword = document.getElementById('password-new').value;
    hideError('password-error');
    if (newPassword.length < 6) {
        showError('password-error', '新密码至少6位');
        return;
    }
    const btn = document.getElementById('password-submit');
    btn.disabled = true;
    btn.textContent = '提交中...';
    try {
        const resp = await fetch('/api/admin/users/' + passwordTarget, {
            method: 'PUT',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({password: newPassword})
        });
        const data = await resp.json();
        if (data.success) {
            closePasswordModal();
            alert('密码已重置');
        } else {
            showError('password-error', data.error || '重置失败');
        }
    } catch (err) {
        console.error('重置密码失败:', err);
        showError('password-error', '网络错误，重置失败');
    } finally {
        btn.disabled = false;
        btn.textContent = '确认重置';
    }
}

// ==================== 新增用户弹窗 ====================
function openCreateModal() {
    document.getElementById('create-username').value = '';
    document.getElementById('create-password').value = '';
    document.getElementById('create-role').value = 'user';
    document.getElementById('create-status').value = 'active';
    hideError('create-error');
    document.getElementById('create-modal').style.display = 'flex';
    document.getElementById('create-username').focus();
}

function closeCreateModal() {
    document.getElementById('create-modal').style.display = 'none';
}

async function submitCreate() {
    const username = document.getElementById('create-username').value.trim();
    const password = document.getElementById('create-password').value;
    const role = document.getElementById('create-role').value;
    const status = document.getElementById('create-status').value;
    hideError('create-error');

    if (!/^[一-龥A-Za-z0-9_]{3,20}$/.test(username)) {
        showError('create-error', '用户名需为3-20位，支持中英文、数字、下划线');
        return;
    }
    if (password.length < 6) {
        showError('create-error', '密码至少6位');
        return;
    }

    const btn = document.getElementById('create-submit');
    btn.disabled = true;
    btn.textContent = '创建中...';
    try {
        const resp = await fetch('/api/admin/users', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password, role, status})
        });
        const data = await resp.json();
        if (data.success) {
            closeCreateModal();
            query.page = 1;
            loadUsers();
            loadStats();
        } else {
            showError('create-error', data.error || '创建失败');
        }
    } catch (err) {
        console.error('创建用户失败:', err);
        showError('create-error', '网络错误，创建失败');
    } finally {
        btn.disabled = false;
        btn.textContent = '创建';
    }
}

document.getElementById('create-modal').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); submitCreate(); }
});
document.getElementById('password-modal').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') { e.preventDefault(); submitPassword(); }
});

window.onload = checkAccess;
