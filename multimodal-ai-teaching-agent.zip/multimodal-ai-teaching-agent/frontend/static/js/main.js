// 全局状态
let conversationHistory = [];
let uploadedFiles = [];
let currentIntent = {};
let generatedFiles = {
    ppt: null,
    word: null,
    game: null
};
// 当前会话ID（首次发送消息前为 null，由后端创建后回传）
let currentConversationId = null;
// 会话列表缓存
let conversationsList = [];

// 切换标签页
function switchTab(tabName) {
    // 隐藏所有标签内容
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // 移除所有导航按钮的激活状态
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // 显示选中的标签内容
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // 激活对应的导航按钮
    event.target.classList.add('active');
}

// 切换预览标签
function switchPreview(previewType) {
    // 隐藏所有预览内容
    document.querySelectorAll('.preview-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // 移除所有预览按钮的激活状态
    document.querySelectorAll('.preview-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // 显示选中的预览内容
    document.getElementById(previewType + '-preview').classList.add('active');
    
    // 激活对应的预览按钮
    event.target.classList.add('active');
}

// 处理回车键
function handleKeyPress(event) {
    if (event.key === 'Enter') {
        sendMessage();
    }
}

// 发送消息
function sendMessage() {
    const input = document.getElementById('user-input');
    const message = input.value.trim();
    
    if (!message) return;
    
    // 添加用户消息到界面
    addMessageToChat('user', message);
    
    // 清空输入框
    input.value = '';
    
    // 发送到后端
    processMessage(message);
}

// 添加消息到聊天界面
function addMessageToChat(role, content) {
    const chatHistory = document.getElementById('chat-history');
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.innerHTML = content.replace(/\n/g, '<br>');
    
    messageDiv.appendChild(contentDiv);
    chatHistory.appendChild(messageDiv);
    
    // 滚动到底部
    chatHistory.scrollTop = chatHistory.scrollHeight;
    
    // 添加到历史记录
    conversationHistory.push({
        role: role,
        content: content
    });
}

// 处理消息（调用后端API）
async function processMessage(message) {
    showLoading();
    // 动态提示已等待时间（LLM服务首字延迟约40秒，避免用户误以为卡死）
    const loadingText = document.querySelector('#loading-overlay .loading-text');
    const startTs = Date.now();
    const waitTimer = setInterval(() => {
        const sec = Math.round((Date.now() - startTs) / 1000);
        loadingText.textContent = `AI 正在分析中，已等待 ${sec} 秒（课件需求约需 1~2 分钟，请勿关闭页面）...`;
    }, 3000);
    
    // 获取RAG开关状态
    const ragEnabled = document.getElementById('rag-enabled').checked;
    
    try {
        // 150秒超时兜底：后端LLM调用异常卡住时，前端不再无限转圈
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 150000);
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                history: conversationHistory,
                files: uploadedFiles,
                rag_enabled: ragEnabled,
                conversation_id: currentConversationId
            }),
            signal: controller.signal
        });
        clearTimeout(timeoutId);
        
        const data = await response.json();
        
        if (data.success) {
            let responseText = data.response;

            // 后端会回传 conversation_id（首次创建会话时与请求不同）
            if (data.conversation_id) {
                const wasFirst = !currentConversationId;
                currentConversationId = data.conversation_id;
                // 首条消息创建会话后，刷新侧边栏以显示新会话
                if (wasFirst) {
                    loadConversations();
                }
            }

            // 如果使用了RAG，添加来源标注
            if (data.used_rag) {
                responseText += '\n\n【参考资料：本地知识库上传文档】';
            } else if (data.rag_error) {
                responseText += '\n\n【知识库未检索到匹配资料，将使用模型原生知识回答】';
            }

            addMessageToChat('assistant', responseText);

            // 更新当前意图
            if (data.intent) {
                currentIntent = data.intent;
            }
            
            // 检查是否需要用户确认
            if (data.need_user_confirm) {
                // ①将后端返回的结构化需求完整赋值给全局变量
                window.currentConfirmReq = data.intent;
                console.log("保存待确认需求", window.currentConfirmReq);
                
                // ②调用 showConfirmModal
                showConfirmModal(data.confirm_summary_text);
            } else {
                // 4. 当收到新一轮聊天消息返回结果时，执行 window.currentConfirmReq = null
                window.currentConfirmReq = null;
                console.log('新消息返回，清空window.currentConfirmReq');
                
                // 检查是否可以生成课件（兼容旧逻辑）
                if (data.is_complete && data.is_course_demand) {
                    checkCanGenerate(true);
                }
            }
        } else {
            addMessageToChat('assistant', '抱歉，处理您的请求时出错：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        if (error.name === 'AbortError') {
            addMessageToChat('assistant', '抱歉，请求超时（等待超过150秒），可能是大模型服务响应过慢，请稍后重试。');
        } else {
            addMessageToChat('assistant', '抱歉，网络连接出现问题，请稍后重试。');
        }
    }
    
    clearInterval(waitTimer);
    hideLoading();
}

// 检查是否可以生成课件
function checkCanGenerate(isComplete) {
    const generateBtn = document.getElementById('generate-btn');
    
    // 根据后端返回的is_complete状态决定按钮是否可用
    if (isComplete === true) {
        generateBtn.disabled = false;
    } else {
        generateBtn.disabled = true;
    }
}

// 语音输入
function startVoiceInput() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        alert('您的浏览器不支持语音识别功能，请使用Chrome浏览器。');
        return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    
    recognition.lang = 'zh-CN';
    recognition.continuous = false;
    recognition.interimResults = false;
    
    recognition.onstart = function() {
        addMessageToChat('assistant', '🎤 正在聆听，请说话...');
    };
    
    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById('user-input').value = transcript;
    };
    
    recognition.onerror = function(event) {
        console.error('Speech recognition error:', event.error);
        addMessageToChat('assistant', '语音识别失败，请重试或使用文字输入。');
    };
    
    recognition.onend = function() {
        // 识别结束
    };
    
    recognition.start();
}

// 处理文件上传
function handleFileUpload(event) {
    const files = event.target.files;
    
    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // 检查是否是图片文件
        if (file.type.startsWith('image/')) {
            // 上传图片并进行解析
            uploadAndParseImage(file);
        } else {
            // 普通文件，直接添加到列表
            uploadedFiles.push(file);
            displayUploadedFile(file);
        }
    }
    
    // 更新文件状态
    updateFileStatus();
}

// 上传并解析图片
async function uploadAndParseImage(file) {
    const formData = new FormData();
    formData.append('image', file);
    
    try {
        showLoading();
        
        const response = await fetch('/api/parse-image', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            // 显示图片预览
            displayImagePreview(file, data.parsed_text);
            
            // 将解析结果添加到消息历史
            addMessageToChat('user', `[上传图片: ${file.name}]`);
            addMessageToChat('assistant', `✅ 图片解析成功（DashScope qwen3.7-plus）\n\n${data.parsed_text}\n\n💡 提示：您可以询问关于这张图片的问题，如"分析这张抓包图的seq、ack数值"`);
            
            // 保存解析结果供后续使用
            uploadedFiles.push({
                name: file.name,
                type: 'image',
                parsed_text: data.parsed_text,
                raw_file: file
            });
            
            // 显示保存到知识库按钮
            showSaveToKBButton(file.name, data.parsed_text);
        } else {
            // 提供友好的错误提示
            let errorMsg = data.error;
            if (errorMsg.includes('API密钥')) {
                errorMsg = '❌ API密钥错误：请在.env文件中设置DASHSCOPE_API_KEY';
            } else if (errorMsg.includes('额度')) {
                errorMsg = '❌ API额度不足：请检查阿里云百炼账户余额';
            } else if (errorMsg.includes('图片过大')) {
                errorMsg = '❌ 图片过大：请上传小于10MB的图片';
            }
            addMessageToChat('assistant', errorMsg);
        }
    } catch (error) {
        console.error('Error parsing image:', error);
        addMessageToChat('assistant', '图片解析时出现错误，请稍后重试。');
    } finally {
        hideLoading();
    }
}

// 显示图片预览
function displayImagePreview(file, parsedText) {
    const container = document.getElementById('uploaded-files');
    const imagePreview = document.createElement('div');
    imagePreview.className = 'image-preview';
    
    const reader = new FileReader();
    reader.onload = function(e) {
        imagePreview.innerHTML = `
            <div class="image-item">
                <img src="${e.target.result}" alt="${file.name}" class="thumbnail">
                <div class="image-info">
                    <span class="image-name">📷 ${file.name}</span>
                    <span class="remove" onclick="removeFile('${file.name}', this)">×</span>
                </div>
                <div class="parsed-text-preview">
                    <details>
                        <summary>查看解析结果（DashScope qwen3.7-plus）</summary>
                        <p>${parsedText}</p>
                    </details>
                </div>
            </div>
        `;
    };
    reader.readAsDataURL(file);
    
    container.appendChild(imagePreview);
}

// 显示保存到知识库按钮
function showSaveToKBButton(fileName, parsedText) {
    const container = document.getElementById('uploaded-files');
    const saveButton = document.createElement('div');
    saveButton.className = 'save-to-kb-area';
    saveButton.id = `save-kb-${fileName}`;
    saveButton.innerHTML = `
        <button class="save-kb-btn" onclick="saveImageToKB('${fileName}')">💾 将DashScope解析结果保存到知识库</button>
    `;
    container.appendChild(saveButton);
    
    // 保存解析结果到全局变量
    window.imageParsedTexts = window.imageParsedTexts || {};
    window.imageParsedTexts[fileName] = parsedText;
}

// 保存图片解析结果到知识库
async function saveImageToKB(fileName) {
    const parsedText = window.imageParsedTexts[fileName];
    
    if (!parsedText) {
        alert('未找到图片解析结果');
        return;
    }
    
    try {
        showLoading();
        
        const response = await fetch('/api/save-to-knowledge-base', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                content: parsedText,
                source: `图片解析: ${fileName}`,
                type: 'image_analysis'
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            addMessageToChat('assistant', `✅ 图片解析结果已成功保存到知识库！`);
            
            // 移除保存按钮
            const saveButton = document.getElementById(`save-kb-${fileName}`);
            if (saveButton) {
                saveButton.remove();
            }
            
            // 刷新知识库统计
            loadKnowledgeBaseStats();
        } else {
            addMessageToChat('assistant', `保存到知识库失败：${data.error}`);
        }
    } catch (error) {
        console.error('Error saving to KB:', error);
        addMessageToChat('assistant', '保存到知识库时出现错误，请稍后重试。');
    } finally {
        hideLoading();
    }
}

// 显示上传的文件
function displayUploadedFile(file) {
    const container = document.getElementById('uploaded-files');
    const fileTag = document.createElement('div');
    fileTag.className = 'file-tag';
    fileTag.innerHTML = `
        📄 ${file.name}
        <span class="remove" onclick="removeFile('${file.name}', this)">×</span>
    `;
    container.appendChild(fileTag);
}

// 移除文件
function removeFile(fileName, element) {
    uploadedFiles = uploadedFiles.filter(f => f.name !== fileName);
    element.parentElement.remove();
    updateFileStatus();
}

// 更新文件状态
function updateFileStatus() {
    const status = document.getElementById('file-status');
    if (uploadedFiles.length > 0) {
        status.textContent = `已上传 ${uploadedFiles.length} 个文件`;
    } else {
        status.textContent = '';
    }
}

// 生成课件
async function generateCourseware() {
    showLoading();
    
    // 获取RAG开关状态
    const ragEnabled = document.getElementById('rag-enabled').checked;
    
    try {
        // 创建FormData上传文件
        const formData = new FormData();
        formData.append('intent', JSON.stringify(currentIntent));
        formData.append('rag_enabled', ragEnabled);
        
        uploadedFiles.forEach(file => {
            formData.append('files', file);
        });
        
        const response = await fetch('/api/generate', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            let successMessage = '✅ 课件生成成功！您可以在"课件预览"标签页查看和下载生成的课件。';
            
            // 如果使用了RAG，添加来源标注
            if (data.used_rag) {
                successMessage += '\n\n【参考资料：本地知识库上传文档】';
            }
            
            addMessageToChat('assistant', successMessage);
            
            // 保存生成的文件路径
            generatedFiles = {
                ppt: data.ppt_path,
                word: data.word_path,
                game: data.game_path
            };
            
            // 更新预览界面
            updatePreview(data);
        } else {
            addMessageToChat('assistant', '❌ 课件生成失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        addMessageToChat('assistant', '❌ 课件生成时出现网络错误，请稍后重试。');
    }
    
    hideLoading();
}

// 渲染TCP握手知识幻灯片（左右分栏布局，只展示本页知识点，不嵌答题面板）
function renderTcpHandshakeSlide(slide, index) {
    const title = slide.title || 'TCP三次握手';

    return `
        <div class="tcp-header">
            <div class="tcp-title">${title}</div>
            <div class="tcp-subtitle">理解连接建立过程、seq与ack规则，以及为什么需要三次握手</div>
        </div>
        <div class="tcp-divider"></div>
        <div class="tcp-layout">
            <div class="tcp-left">
                <div class="tcp-section-title">知识点讲解</div>
                <div class="tcp-flow-box">
                    <div class="tcp-box-title">三次握手流程</div>
                    <div class="tcp-flow-content">
                        1. 客户端发送<span class="tcp-highlight">SYN</span>，请求建立连接<br>
                        2. 服务端回复<span class="tcp-highlight">SYN+ACK</span>，确认并请求<br>
                        3. 客户端回复<span class="tcp-highlight">ACK</span>，确认连接建立
                    </div>
                </div>
                <div class="tcp-formula-box">
                    <div class="tcp-box-title">seq与ack计算规则</div>
                    <div class="tcp-formula-content">
                        <span class="tcp-highlight">seq</span>：发送方序号 | <span class="tcp-highlight">ack</span> = 对方seq + 1
                    </div>
                </div>
                <div class="tcp-state-box">
                    <div class="tcp-box-title">状态转换</div>
                    <div class="tcp-state-content">
                        CLOSED → SYN_SENT → ESTABLISHED<br>
                        LISTEN → SYN_RCVD → ESTABLISHED
                    </div>
                </div>
            </div>
            <div class="tcp-right">
                <div class="tcp-section-title">拓展与误区</div>
                <div class="tcp-wireshark-box">
                    <div class="tcp-box-title">Wireshark抓包图占位</div>
                    <div class="tcp-wireshark-placeholder">
                        [此处显示Wireshark抓包截图]
                    </div>
                </div>
                <div class="tcp-misconception-box">
                    <div class="tcp-box-title">认知误区提示</div>
                    <div class="tcp-misconception-content">
                        ⚠️ 三次握手不是"发三个包"，而是双方确认建立可靠连接的过程
                    </div>
                </div>
                <div class="tcp-game-note">互动答题请见「课堂互动练习」页</div>
            </div>
        </div>
        <div class="tcp-footer">
            三次握手的本质：通过双方确认，建立可靠连接，同时协调初始序号。
        </div>
    `;
}

// 渲染互动答题幻灯片（答题面板单独成页，全课件仅此一页）
function renderQuizSlide(slide, index) {
    const title = slide.title || '课堂互动练习';

    return `
        <div class="tcp-header">
            <div class="tcp-title">${title}</div>
            <div class="tcp-subtitle">TCP握手序号大挑战 · 完整答题游戏请打开配套HTML文件</div>
        </div>
        <div class="tcp-divider"></div>
        <div class="tcp-quiz-page">
            <div class="tcp-quiz-box">
                <div class="tcp-question">
                    <div class="tcp-q-title">第1题：TCP第一次握手发送什么报文？</div>
                    <div class="tcp-q-options">A. SYN  B. SYN+ACK  C. ACK  D. FIN</div>
                    <div class="tcp-q-answer">答案：<span class="tcp-answer-correct">A</span></div>
                </div>
                <div class="tcp-question">
                    <div class="tcp-q-title">第2题：客户端seq=100，服务端ack是多少？</div>
                    <div class="tcp-q-options">A. 100  B. 101  C. 99  D. 102</div>
                    <div class="tcp-q-answer">答案：<span class="tcp-answer-correct">B</span></div>
                </div>
                <div class="tcp-question">
                    <div class="tcp-q-title">第3题：TCP三次握手最主要目的是？</div>
                    <div class="tcp-q-options">A. 加快传输速度  B. 防止失效历史报文  C. 加密传输  D. 校验完整性</div>
                    <div class="tcp-q-answer">答案：<span class="tcp-answer-correct">B</span></div>
                </div>
            </div>
        </div>
        <div class="tcp-footer">
            答题面板单独成页，知识页不再重复嵌入。
        </div>
    `;
}

// 幻灯片点击放大（简单灯箱）
function showSlideLightbox(url) {
    let overlay = document.getElementById('slide-lightbox');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'slide-lightbox';
        overlay.className = 'slide-lightbox';
        overlay.innerHTML = '<img alt="放大预览">';
        overlay.onclick = () => { overlay.style.display = 'none'; };
        document.body.appendChild(overlay);
    }
    overlay.querySelector('img').src = url;
    overlay.style.display = 'flex';
}

// 更新预览界面
function updatePreview(data) {
    // PPT预览
    if (data.ppt_path) {
        document.getElementById('ppt-placeholder').style.display = 'none';
        document.getElementById('ppt-content').style.display = 'block';
        document.getElementById('ppt-export').style.display = 'block';
        
        // 显示PPT幻灯片预览
        const slidesContainer = document.getElementById('ppt-slides');
        slidesContainer.innerHTML = '';
        
        if (data.ppt_images && data.ppt_images.length > 0) {
            // 优先展示后端渲染的逐页PNG缩略图：纵向列表，点击放大
            slidesContainer.className = 'ppt-slides ppt-slides-images';
            data.ppt_images.forEach((url, i) => {
                const item = document.createElement('div');
                item.className = 'ppt-image-item';
                
                const num = document.createElement('div');
                num.className = 'slide-number';
                num.textContent = `第 ${i + 1} 页`;
                item.appendChild(num);
                
                const img = document.createElement('img');
                img.src = url;
                img.alt = `第${i + 1}页`;
                img.loading = 'lazy';
                img.title = '点击放大';
                img.onclick = () => showSlideLightbox(url);
                item.appendChild(img);
                
                slidesContainer.appendChild(item);
            });
        } else if (data.ppt_structure && data.ppt_structure.length > 0) {
            // 无渲染图但有大纲：按大纲展示结构预览
            slidesContainer.className = 'ppt-slides';
            data.ppt_structure.forEach((slide, index) => {
                const slideDiv = document.createElement('div');
                const templateType = slide.template_type || slide.slide_type || 'knowledge';
                
                console.log(`网页预览加载的template_type: ${templateType}, 幻灯片标题: ${slide.title}`);
                
                // 互动答题面板只在quiz页渲染；TCP知识页不再嵌入答题面板
                if (templateType === 'quiz') {
                    slideDiv.className = 'ppt-slide tcp-handshake-slide';
                    slideDiv.innerHTML = renderQuizSlide(slide, index);
                } else if (templateType === 'tcp_handshake') {
                    slideDiv.className = 'ppt-slide tcp-handshake-slide';
                    slideDiv.innerHTML = renderTcpHandshakeSlide(slide, index);
                } else {
                    slideDiv.className = 'ppt-slide';
                    slideDiv.innerHTML = `
                        <div class="slide-number">第 ${index + 1} 页</div>
                        <div class="slide-title">${slide.title || '无标题'}</div>
                        <div class="slide-content">${slide.content || ''}</div>
                    `;
                }
                slidesContainer.appendChild(slideDiv);
            });
        } else {
            // 渲染链路不可用且没有大纲：明确提示，不留空白框
            slidesContainer.className = 'ppt-slides';
            slidesContainer.innerHTML = '<div class="ppt-preview-hint">✅ PPT课件已生成<br>预览渲染不可用，请下载PPTX后查看</div>';
        }
    }
    
    // Word预览
    if (data.word_path) {
        document.getElementById('word-placeholder').style.display = 'none';
        document.getElementById('word-content').style.display = 'block';
        document.getElementById('word-export').style.display = 'block';
        
        document.getElementById('word-text').textContent = data.word_preview || '✅ Word教案已生成，请下载DOCX后查看完整内容';
    }
    
    // 游戏预览（HTML内联嵌入iframe）
    if (data.game_path) {
        document.getElementById('game-placeholder').style.display = 'none';
        document.getElementById('game-content').style.display = 'block';
        document.getElementById('game-export').style.display = 'block';
        
        document.getElementById('game-iframe').src = '/api/preview/game?t=' + Date.now();
    }
}

// 解码后端返回的unicode转义字符串（如 游戏文件不存在），正常显示中文
function decodeUnicodeEscapes(str) {
    if (!str) return str;
    return String(str).replace(/\\u([0-9a-fA-F]{4})/g, function(_, hex) {
        return String.fromCharCode(parseInt(hex, 16));
    });
}

// 通用下载：先校验后端响应，失败时解码并展示可读中文错误
async function downloadFile(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            let errMsg = '文件不存在或已被删除，请重新生成课件';
            try {
                const data = await response.json();
                errMsg = decodeUnicodeEscapes(data.error || data.msg || errMsg);
            } catch (e) {
                // 响应不是JSON，使用默认提示
            }
            addMessageToChat('assistant', '❌ 下载失败：' + errMsg);
            return;
        }
        window.open(url, '_blank');
    } catch (error) {
        console.error('Error:', error);
        addMessageToChat('assistant', '❌ 下载时出现网络错误，请稍后重试。');
    }
}

// 下载PPT
function downloadPPT() {
    if (generatedFiles.ppt) {
        downloadFile('/api/download/ppt');
    }
}

// 下载Word
function downloadWord() {
    if (generatedFiles.word) {
        downloadFile('/api/download/word');
    }
}

// 下载游戏
function downloadGame() {
    if (generatedFiles.game) {
        downloadFile('/api/download/game');
    }
}

// 迭代优化
function handleIterationKeyPress(event) {
    if (event.key === 'Enter') {
        iterateCourseware();
    }
}

async function iterateCourseware() {
    const input = document.getElementById('iteration-input');
    const modification = input.value.trim();
    
    if (!modification) return;
    
    showLoading();
    
    try {
        const response = await fetch('/api/iterate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                modification: modification,
                current_intent: currentIntent
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            addMessageToChat('assistant', '✅ 课件已根据您的意见更新！请查看"课件预览"标签页。');
            
            // 更新生成的文件
            generatedFiles = {
                ppt: data.ppt_path,
                word: data.word_path,
                game: data.game_path
            };
            
            // 更新当前意图
            if (data.updated_intent) {
                currentIntent = data.updated_intent;
            }
            
            // 更新预览
            updatePreview(data);
            
            // 清空输入框
            input.value = '';
        } else {
            addMessageToChat('assistant', '❌ 更新失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        addMessageToChat('assistant', '❌ 更新时出现网络错误，请稍后重试。');
    }
    
    hideLoading();
}

// 知识库上传
async function handleKBUpload(event) {
    const files = event.target.files;
    
    if (files.length === 0) return;
    
    showLoading();
    
    // 显示上传进度
    const progressBar = document.getElementById('kb-upload-progress');
    const progressText = document.getElementById('kb-upload-text');
    progressBar.style.display = 'block';
    progressText.textContent = '正在解析文档...';
    
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
        formData.append('files', files[i]);
    }
    
    try {
        const response = await fetch('/api/knowledge/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            progressText.textContent = '正在分块入库...';
            
            // 显示上传详情
            let uploadDetails = `成功上传 ${data.count} 个文档到知识库\n`;
            data.uploaded_files.forEach(file => {
                uploadDetails += `- ${file.filename}: 提取${file.text_length}字符`;
                if (file.ocr_text_length > 0) {
                    uploadDetails += `（含图片OCR ${file.ocr_text_length}字符）`;
                }
                uploadDetails += `，分块${file.chunks}个，入库${file.added}个\n`;
            });
            uploadDetails += `总入库块数: ${data.total_chunks}`;

            // 展示未入库文件及原因（如纯扫描件PDF无文字层）
            if (data.skipped_files && data.skipped_files.length > 0) {
                uploadDetails += `\n\n跳过 ${data.skipped_files.length} 个文件:\n`;
                data.skipped_files.forEach(file => {
                    uploadDetails += `- ${file.filename}: ${file.reason}\n`;
                });
            }
            
            alert(uploadDetails);
            updateKnowledgeStats();
            updateKnowledgeDocumentList(data.stats);
        } else {
            alert('上传失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('上传时出现网络错误');
    }
    
    hideLoading();
    progressBar.style.display = 'none';
}

// 更新知识库统计
async function updateKnowledgeStats() {
    try {
        const response = await fetch('/api/knowledge/stats');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('kb-count').textContent = data.stats.total_documents;
            updateKnowledgeDocumentList(data.stats);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

// 更新知识库文档列表
function updateKnowledgeDocumentList(stats) {
    const container = document.getElementById('kb-documents');
    if (!container) return;
    
    container.innerHTML = '';
    
    if (!stats.documents || stats.documents.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999;">暂无文档</p>';
        return;
    }
    
    stats.documents.forEach(docName => {
        const docDiv = document.createElement('div');
        docDiv.className = 'kb-document-item';
        docDiv.innerHTML = `
            <span class="doc-name">📄 ${docName}</span>
            <span class="doc-chunks">${stats.doc_stats[docName]} 块</span>
            <button class="delete-doc-btn" onclick="deleteDocument('${docName}')">删除</button>
        `;
        container.appendChild(docDiv);
    });
}

// 删除文档
async function deleteDocument(sourceName) {
    if (!confirm(`确定要删除文档 "${sourceName}" 吗？`)) return;
    
    showLoading();
    
    try {
        const response = await fetch('/api/knowledge/delete', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ source_name: sourceName })
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`成功删除 ${data.deleted_count} 个文本块`);
            updateKnowledgeStats();
        } else {
            alert('删除失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('删除时出现网络错误');
    }
    
    hideLoading();
}

// 清空知识库
async function clearKnowledgeBase() {
    if (!confirm('确定要清空知识库吗？这将删除所有文档和文本块！')) return;
    
    showLoading();
    
    try {
        const response = await fetch('/api/knowledge/clear', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert(`成功清空知识库，删除了 ${data.deleted_count} 个文本块`);
            updateKnowledgeStats();
        } else {
            alert('清空失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('清空时出现网络错误');
    }
    
    hideLoading();
}

// 知识库搜索
function handleKBSearch(event) {
    if (event.key === 'Enter') {
        searchKnowledgeBase();
    }
}

async function searchKnowledgeBase() {
    const query = document.getElementById('kb-search-input').value.trim();
    
    if (!query) return;
    
    showLoading();
    
    try {
        const response = await fetch('/api/knowledge/search', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ query: query })
        });
        
        const data = await response.json();
        
        if (data.success) {
            displaySearchResults(data.results);
        } else {
            alert('搜索失败：' + data.error);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('搜索时出现网络错误');
    }
    
    hideLoading();
}

// 显示搜索结果
function displaySearchResults(results) {
    const container = document.getElementById('knowledge-results');
    container.innerHTML = '';
    
    if (results.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #999;">未检索到相关知识库资料</p>';
        return;
    }
    
    results.forEach(result => {
        const item = document.createElement('div');
        item.className = 'knowledge-item';
        
        // 获取来源文档名称
        const sourceName = result.metadata?.source || '未知文档';
        
        // 相似度
        const similarity = result.similarity || (1 - result.distance);
        const similarityPercent = (similarity * 100).toFixed(1);
        
        // 低相似度警告
        const lowSimilarityWarning = result.is_low_similarity ? 
            '<span class="low-similarity-warning">【匹配度较低】</span>' : '';
        
        item.innerHTML = `
            <div class="knowledge-header">
                <span class="source-name">📄 ${sourceName}</span>
                <span class="similarity-score">相似度: ${similarityPercent}%</span>
            </div>
            <div class="knowledge-preview">${result.preview || result.content.substring(0, 100) + '...'}</div>
            <div class="knowledge-content">${result.content}</div>
            ${lowSimilarityWarning}
        `;
        container.appendChild(item);
    });
}

// 显示需求确认弹窗
function showConfirmModal(summaryText) {
    const modal = document.getElementById('confirm-modal');
    const summaryDiv = document.getElementById('confirm-summary');
    
    // 仅使用confirm_summary_text用于展示
    summaryDiv.textContent = summaryText;
    modal.style.display = 'flex';
}

// 关闭需求确认弹窗
function closeConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    modal.style.display = 'none';
    // 点击【继续修改需求】仅关闭弹窗，不清空该变量
}

// 确认并生成课件
async function confirmAndGenerate() {
    if (!window.currentConfirmReq) {
        alert("暂无待确认的教学需求");
        return;
    }
    
    try {
        // 先把教学需求提交保存到后端session
        const saveResp = await fetch("/api/save-teaching-demand", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                demand: window.currentConfirmReq
            })
        });
        
        const saveData = await saveResp.json();
        
        if (!saveData.success) {
            addMessageToChat('assistant', '保存教学需求失败：' + (saveData.msg || '未知错误'));
            return;
        }
        
        const resp = await fetch("/api/generate-course", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                structured_requirement: window.currentConfirmReq
            })
        });
        
        const data = await resp.json();
        
        if (data.success) {
            // 后续原有生成成功逻辑
            closeConfirmModal();
            window.currentConfirmReq = null;
            
            // 显示生成结果
            addMessageToChat('assistant', '✅ 课件生成成功！');
            
            // 更新生成的文件路径
            generatedFiles = {
                ppt: data.ppt_path,
                word: data.word_path,
                game: data.game_path
            };

            // 显示生成的文件
            if (data.ppt_path) {
                addMessageToChat('assistant', `📄 PPT文件：${data.ppt_path}`);
            }
            if (data.word_path) {
                addMessageToChat('assistant', `📄 Word文件：${data.word_path}`);
            }
            if (data.game_path) {
                addMessageToChat('assistant', `🎮 游戏文件：${data.game_path}`);
            }

            // 显示知识库引用来源（文档名称）
            if (data.citation_sources && data.citation_sources.length > 0) {
                addMessageToChat('assistant', `📚 引用来源：${data.citation_sources.join('、')}`);
            } else if (data.used_rag === false) {
                addMessageToChat('assistant', '📚 本次生成未检索到知识库参考资料，课件内容基于教学需求生成');
            }

            // 更新预览界面
            updatePreview({
                ppt_path: data.ppt_path,
                word_path: data.word_path,
                game_path: data.game_path
            });
        } else {
            addMessageToChat('assistant', '课件生成失败：' + data.msg);
        }
    } catch (err) {
        console.error(err);
        addMessageToChat('assistant', '课件生成失败，请稍后重试。');
    }
}

// 显示加载提示
function showLoading() {
    document.getElementById('loading-overlay').style.display = 'flex';
}

// 隐藏加载提示
function hideLoading() {
    document.getElementById('loading-overlay').style.display = 'none';
    const t = document.querySelector('#loading-overlay .loading-text');
    if (t) t.textContent = '正在处理中，请稍候...';
}

// ==================== 对话历史 ====================

// 加载当前用户的全部会话列表（按更新时间倒序）
async function loadConversations() {
    try {
        const resp = await fetch('/api/conversations');
        const data = await resp.json();
        if (data.success) {
            conversationsList = data.conversations || [];
            renderConversationsSidebar();
        }
    } catch (err) {
        console.error('加载会话列表失败:', err);
    }
}

// 渲染左侧会话列表
function renderConversationsSidebar() {
    const list = document.getElementById('conversation-list');
    if (!list) return;
    if (!conversationsList.length) {
        list.innerHTML = '<p class="no-conversation">暂无历史对话</p>';
        return;
    }
    list.innerHTML = conversationsList.map(c => {
        const active = (c.id === currentConversationId) ? ' active' : '';
        const preview = (c.preview || c.title || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const title = (c.title || '新对话').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        const time = (c.updated_at || '').replace('T', ' ');
        return `
            <div class="conversation-item${active}" data-id="${c.id}" onclick="selectConversation(${c.id})">
                <div class="conv-title">${title}</div>
                <div class="conv-preview">${preview}</div>
                <div class="conv-meta">
                    <span class="conv-time">${time}</span>
                    <span class="conv-ops">
                        <button title="重命名" onclick="event.stopPropagation();renameConversation(${c.id})">✏️</button>
                        <button title="删除" onclick="event.stopPropagation();deleteConversation(${c.id})">🗑️</button>
                    </span>
                </div>
            </div>
        `;
    }).join('');
}

// 切换到指定会话并加载历史消息
async function selectConversation(convId) {
    if (convId === currentConversationId) return;
    try {
        const resp = await fetch(`/api/conversations/${convId}`);
        const data = await resp.json();
        if (!data.success) {
            alert(data.error || '打开会话失败');
            return;
        }
        currentConversationId = convId;
        // 重置对话上下文与课件状态
        conversationHistory = [];
        uploadedFiles = [];
        currentIntent = {};
        generatedFiles = { ppt: null, word: null, game: null };
        window.currentConfirmReq = null;
        // 重新渲染聊天窗口
        const chatHistory = document.getElementById('chat-history');
        chatHistory.innerHTML = '';
        const msgs = data.messages || [];
        if (!msgs.length) {
            // 空会话：显示欢迎语
            addMessageToChat('assistant', '👋 您好！我是您的AI教学助手。请告诉我您想要制作什么课件？');
        } else {
            msgs.forEach(m => addMessageToChat(m.role, m.content));
            // 恢复最后一条 assistant 携带的意图
            const lastIntent = [...msgs].reverse().find(m => m.intent);
            if (lastIntent && lastIntent.intent) {
                currentIntent = lastIntent.intent;
            }
        }
        // 高亮侧边栏
        renderConversationsSidebar();
        // 重置生成按钮状态
        const generateBtn = document.getElementById('generate-btn');
        if (generateBtn) generateBtn.disabled = true;
        // 滚动到底部
        chatHistory.scrollTop = chatHistory.scrollHeight;
    } catch (err) {
        console.error('打开会话失败:', err);
        alert('打开会话失败，请稍后重试');
    }
}

// 新建会话：清空聊天界面并重置上下文
function newConversation() {
    currentConversationId = null;
    conversationHistory = [];
    uploadedFiles = [];
    currentIntent = {};
    generatedFiles = { ppt: null, word: null, game: null };
    window.currentConfirmReq = null;
    const chatHistory = document.getElementById('chat-history');
    chatHistory.innerHTML = `
        <div class="message assistant">
            <div class="message-content">
                <p>👋 您好！我是您的AI教学助手。请告诉我您想要制作什么课件？</p>
                <p>您可以：</p>
                <ul>
                    <li>📝 直接输入教学主题（文字或语音）</li>
                    <li>📁 上传参考文档（PDF、Word、PPT、图片、视频）</li>
                    <li>💬 我会主动追问缺失信息，确保课件质量</li>
                </ul>
            </div>
        </div>
    `;
    // 清空上传文件显示
    const uploadedFilesBox = document.getElementById('uploaded-files');
    if (uploadedFilesBox) uploadedFilesBox.innerHTML = '';
    const fileStatus = document.getElementById('file-status');
    if (fileStatus) fileStatus.textContent = '';
    // 重置生成按钮
    const generateBtn = document.getElementById('generate-btn');
    if (generateBtn) generateBtn.disabled = true;
    renderConversationsSidebar();
}

// 删除会话
async function deleteConversation(convId) {
    if (!confirm('确定删除此对话？删除后无法恢复。')) return;
    try {
        const resp = await fetch(`/api/conversations/${convId}`, { method: 'DELETE' });
        const data = await resp.json();
        if (data.success) {
            // 若删的是当前会话，回到欢迎界面
            if (convId === currentConversationId) {
                newConversation();
            }
            await loadConversations();
        } else {
            alert(data.error || '删除失败');
        }
    } catch (err) {
        console.error('删除会话失败:', err);
        alert('删除失败，请稍后重试');
    }
}

// 重命名会话
async function renameConversation(convId) {
    // 从 DOM 读取当前标题作为 prompt 默认值（避免在 onclick 内嵌字符串字面量）
    const titleEl = document.querySelector(`.conversation-item[data-id="${convId}"] .conv-title`);
    const currentTitle = titleEl ? titleEl.textContent : '';
    const newTitle = prompt('请输入新的对话标题：', currentTitle);
    if (newTitle === null) return;
    const trimmed = newTitle.trim();
    if (!trimmed) {
        alert('标题不能为空');
        return;
    }
    try {
        const resp = await fetch(`/api/conversations/${convId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title: trimmed })
        });
        const data = await resp.json();
        if (data.success) {
            await loadConversations();
        } else {
            alert(data.error || '重命名失败');
        }
    } catch (err) {
        console.error('重命名会话失败:', err);
        alert('重命名失败，请稍后重试');
    }
}

// ==================== 用户系统 ====================
let currentUser = null;
let authMode = 'login';

// 检查当前登录会话，未登录则强制弹出登录框
async function checkAuth() {
    try {
        const resp = await fetch('/api/auth/me');
        if (resp.ok) {
            const data = await resp.json();
            if (data.success && data.user) {
                currentUser = data.user;
                renderUserArea();
                return true;
            }
        }
    } catch (err) {
        console.error('会话检查失败:', err);
    }
    currentUser = null;
    document.getElementById('user-area').style.display = 'none';
    showAuthModal('login');
    return false;
}

// 渲染顶部当前登录用户（仅管理员显示用户管理入口）
function renderUserArea() {
    document.getElementById('header-username').textContent = '👤 ' + currentUser.username;
    document.getElementById('user-area').style.display = 'flex';
    const adminEntry = document.getElementById('admin-entry');
    if (adminEntry) {
        adminEntry.style.display = (currentUser.role === 'admin' || currentUser.role === 'super_admin') ? 'inline-block' : 'none';
    }
}

function showAuthModal(mode) {
    switchAuthTab(mode || 'login');
    document.getElementById('auth-modal').style.display = 'flex';
    document.getElementById('auth-username').focus();
}

function hideAuthModal() {
    document.getElementById('auth-modal').style.display = 'none';
    hideAuthError();
    document.getElementById('auth-username').value = '';
    document.getElementById('auth-password').value = '';
}

function showAuthError(msg) {
    const el = document.getElementById('auth-error');
    el.textContent = msg;
    el.style.display = 'block';
}

function hideAuthError() {
    const el = document.getElementById('auth-error');
    el.textContent = '';
    el.style.display = 'none';
}

// 切换登录/注册选项卡
function switchAuthTab(mode) {
    authMode = mode;
    document.getElementById('auth-tab-login').classList.toggle('active', mode === 'login');
    document.getElementById('auth-tab-register').classList.toggle('active', mode === 'register');
    document.getElementById('auth-submit-btn').textContent = mode === 'login' ? '登录' : '注册并登录';
    document.getElementById('auth-password').autocomplete =
        mode === 'login' ? 'current-password' : 'new-password';
    hideAuthError();
}

// 提交登录或注册
async function submitAuth() {
    const usernameInput = document.getElementById('auth-username');
    const passwordInput = document.getElementById('auth-password');
    const username = usernameInput.value.trim();
    const password = passwordInput.value;

    if (!/^[一-龥A-Za-z0-9_]{3,20}$/.test(username)) {
        showAuthError('用户名需为3-20位，支持中英文、数字、下划线');
        usernameInput.focus();
        return;
    }
    if (password.length < 6) {
        showAuthError('密码至少6位');
        passwordInput.focus();
        return;
    }

    const btn = document.getElementById('auth-submit-btn');
    btn.disabled = true;
    btn.textContent = '请稍候...';
    hideAuthError();

    try {
        const url = authMode === 'login' ? '/api/auth/login' : '/api/auth/register';
        const resp = await fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({username, password})
        });
        const data = await resp.json();

        if (data.success) {
            currentUser = data.user;
            renderUserArea();
            hideAuthModal();
            // 登录成功后刷新知识库统计与会话列表
            updateKnowledgeStats();
            currentConversationId = null;
            conversationsList = [];
            loadConversations();
        } else {
            showAuthError(data.error || '操作失败，请重试');
        }
    } catch (err) {
        console.error('认证请求失败:', err);
        showAuthError('网络错误，请稍后重试');
    } finally {
        btn.disabled = false;
        btn.textContent = authMode === 'login' ? '登录' : '注册并登录';
    }
}

// 退出登录
async function logout() {
    if (!confirm('确定退出登录吗？')) return;
    try {
        await fetch('/api/auth/logout', {method: 'POST'});
    } catch (err) {
        console.error('退出登录失败:', err);
    }
    currentUser = null;
    document.getElementById('user-area').style.display = 'none';
    // 清空对话历史状态
    currentConversationId = null;
    conversationsList = [];
    conversationHistory = [];
    const list = document.getElementById('conversation-list');
    if (list) list.innerHTML = '';
    showAuthModal('login');
}

// 登录弹窗内回车直接提交
document.getElementById('auth-modal').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        submitAuth();
    }
});

// 全局拦截401/403响应：会话过期或账号被禁用时自动弹出登录框（认证接口自身的错误由表单处理）
(function() {
    const originalFetch = window.fetch;
    window.fetch = async function(...args) {
        const resp = await originalFetch.apply(this, args);
        const url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
        const isAuthApi = url.indexOf && url.indexOf('/api/auth/') !== -1;

        const forceLogin = function(message) {
            currentUser = null;
            const userArea = document.getElementById('user-area');
            if (userArea) userArea.style.display = 'none';
            if (typeof hideLoading === 'function') hideLoading();
            if (message) alert(message);
            showAuthModal('login');
        };

        if (resp.status === 401 && !isAuthApi) {
            forceLogin();
        } else if (resp.status === 403 && !isAuthApi) {
            // clone读取错误码，不影响业务代码再次解析响应体
            let code = '';
            try {
                code = (await resp.clone().json()).code || '';
            } catch (e) { /* 忽略解析失败 */ }
            if (code === 'ACCOUNT_DISABLED') {
                forceLogin('账号已被禁用，请联系管理员');
            }
        }
        return resp;
    };
})();

// 页面加载时初始化：先校验登录状态，已登录才加载知识库统计与会话历史
window.onload = async function() {
    const loggedIn = await checkAuth();
    if (loggedIn) {
        updateKnowledgeStats();
        loadConversations();
    }
};
