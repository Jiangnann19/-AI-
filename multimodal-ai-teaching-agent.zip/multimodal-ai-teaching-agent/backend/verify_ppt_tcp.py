# -*- coding: utf-8 -*-
"""
TCP三次握手PPT验证脚本

验证目标（对应修改要求）：
1. 互动答题面板只出现一次：单独成页"课堂互动练习"（多页TCP知识点大纲下复现原重复bug场景）
2. 内容页有渐变/色块背景，不是纯白
3. 关键词（SYN/ACK/seq=x等）有橙色高亮强调
4. 正文文字为纯黑(#000000)

运行方式（项目依赖在Python3.7环境）：
    cd backend && D:\\python37\\python.exe verify_ppt_tcp.py
"""

import os
import sys
import json

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app'))

from pptx import Presentation
from pptx.dml.color import RGBColor
from app.generators.ppt_generator import get_ppt_generator

OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'outputs')

CHECK_PASS = []
CHECK_FAIL = []


def check(name, ok, detail=''):
    (CHECK_PASS if ok else CHECK_FAIL).append(name)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}  {detail}")


def build_tcp_instruction(with_outline=True):
    """以chat_result2.json的教学需求为底，构造融合指令"""
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    with open(os.path.join(root, 'chat_result2.json', ), encoding='utf-8') as f:
        intent = json.load(f)['intent']

    instruction = dict(intent)
    instruction['course_title'] = 'TCP三次握手：连接建立的核心机制'
    instruction['key_points'] = intent['key_difficulties']['key_points']
    instruction['difficult_points'] = [
        dp['content'] for dp in intent['key_difficulties']['difficult_points']
    ]
    instruction['interactive_game'] = {
        'type': '问答游戏',
        'title': 'TCP握手序号大挑战',
        'content': '基于TCP三次握手知识点的问答互动'
    }

    if with_outline:
        # 模拟LLM生成的大纲：多个知识点页标题都含"TCP/握手"（原bug下第3/4/6页全被嵌入答题面板）
        instruction['ppt_structure'] = [
            {'slide_type': 'cover', 'title': 'TCP三次握手：连接建立的核心机制'},
            {'slide_type': 'directory', 'title': '课程目录'},
            {'slide_type': 'knowledge', 'title': 'TCP连接建立时的状态流转',
             'content': '客户端：CLOSED → SYN_SENT → ESTABLISHED\n服务端：CLOSED → LISTEN → SYN_RCVD → ESTABLISHED\n状态变迁由报文收发驱动'},
            {'slide_type': 'knowledge', 'title': 'TCP三次握手流程',
             'content': '第一次：客户端发送SYN，seq=x\n第二次：服务端回复SYN+ACK，seq=y，ack=x+1\n第三次：客户端回复ACK，seq=x+1，ack=y+1'},
            {'slide_type': 'case', 'title': 'Wireshark抓包案例分析',
             'content': '观察真实抓包中的三次握手报文\n定位Flags中的SYN与ACK标志位'},
            {'slide_type': 'knowledge', 'title': 'TCP中seq与ack的计算',
             'content': 'ack = 收到的seq + 1\n示例：客户端seq=100，服务端ack=101\nack表示期望收到的下一个字节序号'},
            {'slide_type': 'summary', 'title': '本课重点总结'},
            {'slide_type': 'ending', 'title': '课程结束'},
        ]
    return instruction


def slide_texts(slide):
    texts = []
    for shape in slide.shapes:
        if shape.has_text_frame:
            texts.append(shape.text_frame.text)
    return '\n'.join(texts)


def is_gradient(slide):
    try:
        return slide.background.fill.type is not None and 'GRADIENT' in str(slide.background.fill.type)
    except Exception:
        return False


def count_highlight_runs(slide, hex_color='F59E0B'):
    """统计幻灯片中带指定颜色高亮底色的run数量"""
    xml = slide._element.xml
    return xml.count('a:highlight') and xml.count(f'<a:srgbClr val="{hex_color}"/>') or 0


def body_color_stats(slide):
    """统计文本run颜色：返回(纯黑run数, 其他显式颜色run数)"""
    black, other = 0, 0
    for shape in slide.shapes:
        if not shape.has_text_frame:
            continue
        for p in shape.text_frame.paragraphs:
            for run in p.runs:
                try:
                    rgb = run.font.color.rgb
                except Exception:
                    rgb = None
                if rgb is None:
                    continue
                if rgb == RGBColor(0, 0, 0):
                    black += 1
                else:
                    other += 1
    return black, other


def verify_deck(ppt_path, scenario):
    print(f"\n===== 场景：{scenario} =====")
    print(f"生成文件: {ppt_path}")
    prs = Presentation(ppt_path)
    print(f"总页数: {len(prs.slides)}")

    quiz_pages = []
    for idx, slide in enumerate(prs.slides, 1):
        text = slide_texts(slide)
        title = text.split('\n')[0] if text else ''
        is_quiz = ('第1题' in text) or ('答案：' in text)
        if is_quiz:
            quiz_pages.append(idx)
        print(f"  第{idx}页: {title[:30]:<32} 渐变背景={is_gradient(slide)} "
              f"橙色高亮run={count_highlight_runs(slide)} 含答题面板={is_quiz}")

    # ① 答题面板只出现一次且单独成页
    check('①答题面板全课件只出现一次', len(quiz_pages) == 1, f"出现在第{quiz_pages}页")
    if quiz_pages:
        quiz_text = slide_texts(prs.slides[quiz_pages[0] - 1])
        check('①答题页标题为"课堂互动练习"', '课堂互动练习' in quiz_text)
        check('①答题页为最后一页教学内容', quiz_pages[0] == len(prs.slides) - 1
              if '感谢聆听' in slide_texts(prs.slides[-1]) else quiz_pages[0] == len(prs.slides),
              f"答题页=第{quiz_pages[0]}页/共{len(prs.slides)}页")

    # ② 每页都有渐变背景，且底部有深蓝页脚色条
    all_gradient = all(is_gradient(s) for s in prs.slides)
    check('②所有页面均为渐变背景（非纯白）', all_gradient)
    all_footer = all('1E3A8A' in s._element.xml for s in prs.slides)
    check('②每页底部有深蓝色(#1E3A8A)页脚色条', all_footer)

    # ③ 关键词有橙色高亮强调
    total_hl = sum(count_highlight_runs(s) for s in prs.slides)
    check('③关键词(SYN/ACK/seq=x等)有橙色高亮强调', total_hl > 0, f"共{total_hl}处")

    # ④ 正文为纯黑：内容页存在纯黑正文run（封面/结尾页按设计为深色渐变底白字，跳过）
    for idx, slide in enumerate(prs.slides, 1):
        text = slide_texts(slide)
        if idx == 1 or '感谢聆听' in text:
            continue
        black, other = body_color_stats(slide)
        check(f'④第{idx}页正文含纯黑(#000000)文本', black > 0, f"纯黑run={black}")


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    gen = get_ppt_generator()
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 场景一：多页TCP知识点大纲（复现原"3/4/6页重复嵌入答题面板"的输入）
    path1 = gen.generate(build_tcp_instruction(with_outline=True),
                         output_path=os.path.join(OUTPUT_DIR, 'verify_tcp_multipage.pptx'))
    verify_deck(path1, '多页TCP大纲（原bug输入）')

    # 场景二：mock融合输出（cover/directory/tcp_handshake三页结构）
    instruction2 = build_tcp_instruction(with_outline=False)
    instruction2['ppt_structure'] = [
        {'slide_type': 'cover', 'title': 'TCP三次握手：连接建立的核心机制'},
        {'slide_type': 'directory', 'title': '课程目录'},
        {'slide_type': 'tcp_handshake', 'title': 'TCP三次握手：连接建立的核心机制',
         'content': '三次握手流程、序号规则、报文含义、设计目的'},
    ]
    path2 = gen.generate(instruction2,
                         output_path=os.path.join(OUTPUT_DIR, 'verify_tcp_mock.pptx'))
    verify_deck(path2, 'mock融合三页大纲')

    print(f"\n===== 结果汇总：{len(CHECK_PASS)} 通过, {len(CHECK_FAIL)} 失败 =====")
    if CHECK_FAIL:
        print('失败项:', CHECK_FAIL)
        sys.exit(1)
    print('全部验证通过')


if __name__ == '__main__':
    main()
