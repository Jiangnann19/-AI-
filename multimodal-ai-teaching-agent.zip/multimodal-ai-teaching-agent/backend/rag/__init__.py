"""
RAG向量知识库模块（chromadb + DashScope embedding）
"""

from .vector_store import ChromaVectorStore, get_vector_store

__all__ = ['ChromaVectorStore', 'get_vector_store']
