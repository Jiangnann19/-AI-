"""
chromadb向量知识库
文档分块、向量化入库、相似度检索、清空与统计
"""

import os
import logging
import uuid
from typing import List, Dict, Optional

import chromadb

from .embeddings import DashScopeEmbeddingFunction

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

COLLECTION_NAME = 'teaching_knowledge'


class ChromaVectorStore:
    """chromadb本地向量知识库"""

    def __init__(self):
        from dotenv import load_dotenv
        load_dotenv()

        self.persist_dir = os.getenv('CHROMA_PERSIST_DIR', './backend/knowledge_base/chroma_db')
        if not os.path.isabs(self.persist_dir):
            # 相对路径统一锚定到项目根目录，避免因启动目录不同而读写不同的向量库
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            self.persist_dir = os.path.normpath(os.path.join(project_root, self.persist_dir))
        self.chunk_size = int(os.getenv('CHUNK_SIZE', '300'))
        self.chunk_overlap = int(os.getenv('CHUNK_OVERLAP', '50'))

        os.makedirs(self.persist_dir, exist_ok=True)

        self.embedding_function = DashScopeEmbeddingFunction()
        self.client = chromadb.PersistentClient(path=self.persist_dir)
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=self.embedding_function,
            metadata={'hnsw:space': 'cosine'}
        )
        logger.info(f"chromadb向量库初始化完成: {self.persist_dir}, 当前块数: {self.collection.count()}")

    def chunk_text(self, text: str, chunk_size: int = None, overlap: int = None) -> List[str]:
        """
        文本分块（langchain递归字符分块）

        Args:
            text: 原始文本
            chunk_size: 块大小，默认读CHUNK_SIZE
            overlap: 重叠大小，默认读CHUNK_OVERLAP

        Returns:
            文本块列表
        """
        try:
            from langchain_text_splitters import RecursiveCharacterTextSplitter
        except ImportError:
            from langchain.text_splitter import RecursiveCharacterTextSplitter

        splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size or self.chunk_size,
            chunk_overlap=overlap if overlap is not None else self.chunk_overlap,
            separators=['\n\n', '\n', '。', '，']
        )
        chunks = [chunk for chunk in splitter.split_text(text) if chunk.strip()]
        logger.info(f"文本分块完成: 原文{len(text)}字符 -> {len(chunks)}个块")
        return chunks

    def add_documents(self, chunks: List[str], metadatas: Optional[List[Dict]] = None) -> int:
        """
        文本块入库

        Args:
            chunks: 文本块列表
            metadatas: 元数据列表

        Returns:
            实际入库块数
        """
        if not chunks:
            return 0

        valid_chunks = []
        valid_metadatas = []
        for idx, chunk in enumerate(chunks):
            if chunk and chunk.strip():
                valid_chunks.append(chunk)
                meta = metadatas[idx] if metadatas and idx < len(metadatas) else {}
                valid_metadatas.append(meta)

        if not valid_chunks:
            return 0

        ids = [str(uuid.uuid4()) for _ in valid_chunks]
        self.collection.add(documents=valid_chunks, metadatas=valid_metadatas, ids=ids)

        logger.info(f"向量库入库完成: 尝试添加{len(chunks)}个块，成功入库{len(valid_chunks)}个块")
        return len(valid_chunks)

    def add_document(self, content: str, metadata: Optional[Dict] = None) -> int:
        """
        单条内容入库（自动分块）

        Args:
            content: 文本内容
            metadata: 元数据

        Returns:
            入库块数
        """
        chunks = self.chunk_text(content)
        return self.add_documents(chunks, metadatas=[metadata or {} for _ in chunks])

    def search(self, query: str, top_k: int = 5, similarity_threshold: float = 0.3) -> List[Dict]:
        """
        相似度检索

        Args:
            query: 查询文本
            top_k: 返回数量
            similarity_threshold: 相似度阈值（cosine，similarity = 1 - distance），
                生效阈值最低为0.3，低于0.3的chunk一律过滤丢弃

        Returns:
            检索结果列表 [{content, metadata, similarity, distance, preview, is_low_similarity}]，
            按相似度从高到低排序；全部低于阈值时返回空列表
        """
        if not query or not query.strip():
            return []

        if self.collection.count() == 0:
            logger.info("向量库为空，无检索结果")
            return []

        # 阈值下限：相似度小于0.3（30%）的chunk直接过滤丢弃，不返回给前端
        effective_threshold = max(similarity_threshold, 0.3)

        result = self.collection.query(
            query_texts=[query],
            n_results=min(top_k, self.collection.count())
        )

        documents = result.get('documents', [[]])[0]
        metadatas = result.get('metadatas', [[]])[0]
        distances = result.get('distances', [[]])[0]

        results = []
        for content, metadata, distance in zip(documents, metadatas, distances):
            similarity = max(0.0, 1.0 - distance)
            preview = content[:100] + ('...' if len(content) > 100 else '')
            results.append({
                'content': content,
                'metadata': metadata or {},
                'distance': distance,
                'similarity': similarity,
                'preview': preview,
                'is_low_similarity': similarity < effective_threshold
            })

        # 按阈值过滤：低于阈值的结果全部丢弃；无达标结果时返回空列表，不再兜底保留
        final_results = [r for r in results if not r['is_low_similarity']]

        logger.info(f"向量库检索: 查询='{query}', 召回{len(results)}个, 阈值={effective_threshold}, 过滤后返回{len(final_results)}个")
        for i, item in enumerate(final_results):
            logger.info(f"  结果{i+1}: 相似度={item['similarity']:.4f}, 来源={item['metadata'].get('source', 'unknown')}")

        return final_results

    def get_stats(self) -> Dict:
        """
        知识库统计

        Returns:
            {total_chunks, total_documents, documents, doc_stats}
        """
        total = self.collection.count()
        doc_stats = {}

        if total > 0:
            data = self.collection.get(include=['metadatas'])
            for meta in data.get('metadatas', []):
                source = (meta or {}).get('source', 'unknown')
                doc_stats[source] = doc_stats.get(source, 0) + 1

        return {
            'total_chunks': total,
            'total_documents': len(doc_stats),
            'documents': list(doc_stats.keys()),
            'doc_stats': doc_stats
        }

    def delete_document(self, source_name: str) -> int:
        """
        删除指定来源文档的所有块

        Args:
            source_name: 文档来源名

        Returns:
            删除块数
        """
        data = self.collection.get(
            where={'source': source_name},
            include=['metadatas']
        )
        ids = data.get('ids', [])
        if ids:
            self.collection.delete(ids=ids)

        logger.info(f"删除文档: {source_name}, 删除了{len(ids)}个块")
        return len(ids)

    def clear_all(self) -> int:
        """
        清空知识库

        Returns:
            删除块数
        """
        count = self.collection.count()
        self.client.delete_collection(COLLECTION_NAME)
        self.collection = self.client.get_or_create_collection(
            name=COLLECTION_NAME,
            embedding_function=self.embedding_function,
            metadata={'hnsw:space': 'cosine'}
        )

        logger.info(f"清空向量库: 删除了{count}个块")
        return count


# 全局单例
_vector_store = None


def get_vector_store() -> ChromaVectorStore:
    """
    获取全局向量库实例（单例模式）

    Returns:
        ChromaVectorStore实例
    """
    global _vector_store
    if _vector_store is None:
        _vector_store = ChromaVectorStore()
    return _vector_store
