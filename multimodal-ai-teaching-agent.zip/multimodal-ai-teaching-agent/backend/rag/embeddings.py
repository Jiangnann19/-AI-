"""
DashScope向量化模块
实现chromadb EmbeddingFunction协议，使用阿里云DashScope text-embedding模型
"""

import os
import logging
from typing import List

import dashscope

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

EMBEDDING_MODEL = os.getenv('DASHSCOPE_EMBEDDING_MODEL', 'text-embedding-v2')
BATCH_SIZE = 20  # DashScope text-embedding单批上限25，留余量


class DashScopeEmbeddingFunction:
    """DashScope向量化函数，兼容chromadb EmbeddingFunction协议"""

    def __init__(self):
        from dotenv import load_dotenv
        load_dotenv()

        self.api_key = os.getenv('DASHSCOPE_API_KEY') or os.getenv('OPENAI_API_KEY')
        if not self.api_key or 'your_' in self.api_key:
            raise ValueError("未配置DASHSCOPE_API_KEY，请在.env文件中设置阿里云百炼API密钥")
        dashscope.api_key = self.api_key
        logger.info(f"DashScope向量化初始化完成，模型: {EMBEDDING_MODEL}")

    def __call__(self, input: List[str]) -> List[List[float]]:
        """
        将文本列表转为向量列表（chromadb回调接口）

        Args:
            input: 文本列表

        Returns:
            向量列表
        """
        if not input:
            return []

        embeddings = []
        for i in range(0, len(input), BATCH_SIZE):
            batch = [text if text and text.strip() else '空' for text in input[i:i + BATCH_SIZE]]
            response = dashscope.TextEmbedding.call(
                model=EMBEDDING_MODEL,
                input=batch
            )
            if response.status_code != 200:
                raise RuntimeError(f"DashScope向量化失败: {response.code} - {response.message}")

            # 按text_index排序，保证与输入顺序一致
            sorted_items = sorted(response.output['embeddings'], key=lambda x: x.get('text_index', 0))
            embeddings.extend([item['embedding'] for item in sorted_items])

        logger.info(f"DashScope向量化完成: {len(input)}条文本")
        return embeddings

    def embed_documents(self, input: List[str]) -> List[List[float]]:
        """chromadb >= 0.5 批量嵌入接口（入库链路）"""
        return self.__call__(input)

    def embed_query(self, input):
        """chromadb >= 0.5 查询嵌入接口（兼容 str / list 输入，返回向量列表）"""
        if isinstance(input, str):
            input = [input]
        return self.__call__(input)
