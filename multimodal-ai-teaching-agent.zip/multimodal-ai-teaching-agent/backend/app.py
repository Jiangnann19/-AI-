"""
多模态AI互动式教学智能体 - Flask后端主程序
锐捷网络教育信息化应用场景
"""

import os
import sys
import json
import uuid
import logging
from datetime import datetime
from flask import Flask, request, jsonify, send_file, render_template, session
from flask_cors import CORS
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
import traceback
from urllib.parse import quote

# 按绝对路径显式加载环境配置：根目录.env（API密钥等）优先，backend/.env补充
# 各模块内部load_dotenv()只会向上查找到backend/.env，导致根目录密钥配置被跳过
_BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(os.path.dirname(_BACKEND_DIR), '.env'))
load_dotenv(os.path.join(_BACKEND_DIR, '.env'))

# 添加app目录到Python路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'app'))

# 导入自定义模块
from app.auth import auth_bp, init_auth_db, login_required, current_user
from app.admin import admin_bp
from app.chat_history import chat_history_bp, init_chat_history_db, save_message
from app.parsers.document_parser import get_document_parser
from app.utils.intent_analyzer import get_intent_analyzer
from app.utils.llm_client import get_llm_client
from rag.vector_store import get_vector_store
from multimodal_parser import get_multimodal_parser
from app.utils.multimodal_fusion import get_multimodal_fusion
from app.utils.image_parser import get_image_parser
from app.generators.ppt_generator import get_ppt_generator
from app.generators.word_generator import get_word_generator
from app.generators.game_generator import get_game_generator

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__, 
            template_folder='../frontend/templates',
            static_folder='../frontend/static')
CORS(app)

# session加密密钥（用于保存教学需求等会话数据）
app.secret_key = os.getenv('FLASK_SECRET_KEY', 'multimodal-ai-teaching-agent-dev-secret')

# 注册用户认证蓝图、管理端蓝图与对话历史蓝图，并初始化用户数据库
app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(chat_history_bp)
init_auth_db()
init_chat_history_db()

# 配置
UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'uploads')
OUTPUT_FOLDER = os.path.join(os.path.dirname(__file__), 'outputs')
ALLOWED_EXTENSIONS = {'pdf', 'docx', 'pptx', 'png', 'jpg', 'jpeg', 'mp4', 'avi', 'mov', 'txt'}
MAX_CONTENT_LENGTH = 50 * 1024 * 1024  # 50MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH

# 确保目录存在
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# 生成的课件文件按登录用户隔离存储：{user_id: {'ppt': path, 'word': path, 'game': path}}
_user_generated_files = {}


def _get_user_generated_files():
    """获取当前登录用户的生成文件记录（每个用户相互独立）"""
    user_id = session.get('user_id')
    if user_id not in _user_generated_files:
        _user_generated_files[user_id] = {'ppt': None, 'word': None, 'game': None}
    return _user_generated_files[user_id]


def allowed_file(filename):
    """检查文件扩展名是否允许"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def secure_filename_keep_ext(filename):
    """
    secure_filename会把纯中文文件名全部剥掉（如 教案.docx -> docx），
    保存后丢失扩展名，导致按扩展名路由的解析器无法识别docx。
    保底策略：安全名不含扩展名时补回原扩展名；名称为空时生成唯一名。
    """
    safe = secure_filename(filename)
    ext = filename.rsplit('.', 1)[1].lower() if '.' in filename else ''
    if not ext or safe.lower().endswith('.' + ext):
        return safe
    stem = safe[:-len(ext)].strip('.') if safe.lower().endswith(ext) else safe.strip('.')
    if not stem:
        stem = f"upload_{uuid.uuid4().hex[:8]}"
    logger.info(f"文件名经secure_filename处理后丢失扩展名，已补回: {filename!r} -> {stem}.{ext}")
    return f"{stem}.{ext}"


def verify_generated_file(filepath, label):
    """
    校验生成的文件：转为Windows绝对路径，确认文件已成功写入磁盘
    返回 (绝对路径, None) 或 (None, 错误信息)
    """
    abs_path = os.path.abspath(filepath) if filepath else None
    if abs_path and os.path.exists(abs_path) and os.path.getsize(abs_path) > 0:
        logger.info(f"{label}文件写入成功，完整路径: {abs_path}，大小: {os.path.getsize(abs_path)} 字节")
        return abs_path, None
    logger.error(f"{label}文件写入失败或内容为空: {abs_path}")
    return None, f"{label}文件保存失败，请重新生成"


@app.route('/')
def index():
    """主页"""
    return render_template('index.html')


@app.route('/admin')
def admin_page():
    """用户管理端页面（管理员身份由前端调用/api/auth/me校验，管理接口另有admin_required强校验）"""
    return render_template('admin.html')


@app.route('/api/chat', methods=['POST'])
@login_required
def chat():
    """
    智能对话API
    处理用户输入，进行意图分析和多轮对话
    """
    try:
        data = request.json
        message = data.get('message', '')
        history = data.get('history', [])
        files = data.get('files', [])
        rag_enabled = data.get('rag_enabled', True)  # 默认开启RAG
        # 客户端传入的会话ID（首次对话为 null，由后端创建并回传）
        conversation_id = data.get('conversation_id')

        logger.info(f"收到对话请求: {message}, RAG启用: {rag_enabled}, 会话ID: {conversation_id}")

        # 先保存用户消息（同时确定最终 conversation_id），AI 回复稍后保存
        user = current_user()
        try:
            conversation_id, _ = save_message(
                user['id'], conversation_id, 'user', message
            )
        except Exception as se:
            logger.error(f"保存用户消息失败: {se}")
            conversation_id = conversation_id or None
        
        # 处理图片解析结果
        image_context = ""
        if files:
            for file_info in files:
                if isinstance(file_info, dict) and file_info.get('type') == 'image':
                    parsed_text = file_info.get('parsed_text', '')
                    if parsed_text:
                        image_context += f"\n[图片解析: {file_info.get('name', '未知图片')}]\n{parsed_text}\n"
                        logger.info(f"包含图片解析结果: {file_info.get('name')}")
        
        # RAG检索
        rag_context = ""
        used_rag = False
        rag_error = False
        
        if rag_enabled:
            try:
                knowledge_base = get_vector_store()
                search_results = knowledge_base.search(message, top_k=5, similarity_threshold=0.015)
                
                if search_results:
                    # 提取检索到的内容
                    rag_context_parts = []
                    for result in search_results:
                        source = result.get('metadata', {}).get('source', '未知文档')
                        content = result.get('content', '')
                        similarity = result.get('similarity', 0)
                        rag_context_parts.append(f"[来源: {source}, 相似度: {similarity:.4f}] {content}")
                    
                    rag_context = "\n\n".join(rag_context_parts)
                    used_rag = True
                    
                    logger.info(f"RAG检索成功: 查询='{message}', 检索到{len(search_results)}个片段")
                    for i, result in enumerate(search_results):
                        logger.info(f"  片段{i+1}: 相似度={result.get('similarity', 0):.4f}, 来源={result.get('metadata', {}).get('source', 'unknown')}")
                else:
                    rag_error = True
                    logger.warning(f"RAG检索未找到匹配内容: 查询='{message}'")
            except Exception as e:
                rag_error = True
                logger.error(f"RAG检索失败: {str(e)}")
        
        # 合并上下文（图片解析 + RAG）
        combined_context = image_context
        if rag_context:
            combined_context += "\n\n" + rag_context
        
        # 获取意图分析器
        intent_analyzer = get_intent_analyzer()
        
        # 使用新的完整性分析方法
        completeness_result = intent_analyzer.analyze_requirement_completeness(message, history, combined_context)
        
        # 根据完整性分析结果生成回复
        if completeness_result['is_course_demand']:
            if completeness_result['need_user_confirm']:
                # 信息完整，需要用户确认
                response = completeness_result['confirm_summary_text']
                response += "\n\n【请确认以上教学需求，如需修改请补充信息】"
            else:
                # 信息不完整，使用追问
                response = completeness_result.get('clarification_question', '请提供更多教学需求信息')
        else:
            # 不是课件需求：RAG检索上下文与用户问题拼接，传给DeepSeek生成回答
            llm_client = get_llm_client()
            deepseek_messages = [{
                'role': 'system',
                'content': '你是一位专业的教学助手。请优先结合给出的知识库参考内容回答用户问题；参考内容不足时，用自己的知识回答，并主动引导用户描述课件制作需求。'
            }]
            if combined_context.strip():
                deepseek_messages[0]['content'] += f"\n\n【知识库参考内容】\n{combined_context}"
            for item in history[-6:]:
                if isinstance(item, dict) and item.get('role') in ('user', 'assistant'):
                    deepseek_messages.append({'role': item['role'], 'content': item.get('content', '')})
            deepseek_messages.append({'role': 'user', 'content': message})
            try:
                response = llm_client.chat_with_deepseek(deepseek_messages)
            except Exception as e:
                logger.error(f"DeepSeek对话失败: {str(e)}，回退DashScope主通道")
                # DeepSeek不可用时（如密钥失效），回退到已配置可用的DashScope主通道
                try:
                    response = llm_client.chat(
                        deepseek_messages, temperature=0.7, max_tokens=2000, use_rag=False)
                except Exception as e2:
                    logger.error(f"DashScope回退也失败: {str(e2)}")
                    response = (f"对话生成暂时不可用（DeepSeek：{str(e)}；主通道：{str(e2)}）。"
                                f"如需生成课件，请直接告诉我您想制作什么课件。")
        
        # 保存AI回复到对话历史（含意图结构化结果，便于下次继续）
        try:
            save_message(
                user['id'], conversation_id, 'assistant', response,
                completeness_result.get('structured_requirement', {})
            )
        except Exception as se:
            logger.error(f"保存AI回复失败: {se}")

        return jsonify({
            'success': True,
            'response': response,
            'conversation_id': conversation_id,
            'intent': completeness_result.get('structured_requirement', {}),
            'is_complete': completeness_result['is_complete'],
            'is_course_demand': completeness_result['is_course_demand'],
            'missing_fields': completeness_result['missing_fields'],
            'need_user_confirm': completeness_result['need_user_confirm'],
            'confirm_summary_text': completeness_result['confirm_summary_text'],
            'used_rag': used_rag,
            'rag_error': rag_error
        })
        
    except Exception as e:
        logger.error(f"对话处理错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/generate', methods=['POST'])
@login_required
def generate():
    """
    课件生成API
    融合多模态信息，生成PPT、Word和互动游戏
    """
    try:
        # 获取意图信息
        intent_str = request.form.get('intent', '{}')
        intent = json.loads(intent_str)
        rag_enabled = request.form.get('rag_enabled', 'true').lower() == 'true'  # 默认开启RAG
        
        logger.info(f"收到课件生成请求: {intent.get('course_title', '未命名')}, RAG启用: {rag_enabled}")
        
        # RAG检索（如果启用）
        rag_context = ""
        used_rag = False
        citation_sources = []
        
        if rag_enabled:
            try:
                knowledge_base = get_vector_store()
                # 使用课程标题和知识点作为查询词
                query_terms = []
                course_title = intent.get('course_title', '')
                knowledge_points = intent.get('knowledge_points', [])
                
                if course_title:
                    query_terms.append(course_title)
                if knowledge_points:
                    query_terms.extend(knowledge_points)
                
                # 对每个查询词进行检索
                all_search_results = []
                for query in query_terms[:3]:  # 最多检索3个查询词
                    if query:
                        results = knowledge_base.search(query, top_k=5, similarity_threshold=0.015)
                        all_search_results.extend(results)
                
                if all_search_results:
                    # 去重并按相似度排序
                    seen_contents = set()
                    unique_results = []
                    for result in all_search_results:
                        content = result.get('content', '')
                        if content not in seen_contents:
                            seen_contents.add(content)
                            unique_results.append(result)
                    
                    # 按相似度排序
                    unique_results.sort(key=lambda x: x.get('similarity', 0), reverse=True)
                    unique_results = unique_results[:10]  # 最多保留10个结果
                    
                    # 提取检索到的内容
                    rag_context_parts = []
                    for result in unique_results:
                        source = result.get('metadata', {}).get('source', '未知文档')
                        content = result.get('content', '')
                        similarity = result.get('similarity', 0)
                        rag_context_parts.append(f"[来源: {source}, 相似度: {similarity:.4f}] {content}")
                        if source not in citation_sources:
                            citation_sources.append(source)
                    
                    rag_context = "\n\n".join(rag_context_parts)
                    used_rag = True
                    
                    logger.info(f"课件生成RAG检索成功: 检索到{len(unique_results)}个片段")
                    for i, result in enumerate(unique_results):
                        logger.info(f"  片段{i+1}: 相似度={result.get('similarity', 0):.4f}, 来源={result.get('metadata', {}).get('source', 'unknown')}")
                else:
                    logger.warning(f"课件生成RAG检索未找到匹配内容")
            except Exception as e:
                logger.error(f"课件生成RAG检索失败: {str(e)}")
        
        # 处理上传的文件
        reference_materials = []
        if 'files' in request.files:
            files = request.files.getlist('files')
            document_parser = get_document_parser()
            
            for file in files:
                if file and allowed_file(file.filename):
                    filename = secure_filename_keep_ext(file.filename)
                    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                    file.save(filepath)
                    
                    try:
                        # 解析文件
                        parsed = document_parser.parse(filepath)
                        reference_materials.append(parsed)
                        logger.info(f"成功解析文件: {filename}")
                    except Exception as e:
                        logger.error(f"文件解析失败 {filename}: {str(e)}")
        
        # 将RAG检索到的内容添加到参考资料
        if rag_context:
            reference_materials.append({
                'type': 'rag_knowledge',
                'full_text': rag_context,
                'source': 'knowledge_base'
            })
        
        # 多模态融合
        fusion = get_multimodal_fusion()
        fusion_instruction = fusion.fuse(intent, reference_materials, use_knowledge_base=True)
        # 溯源信息传入生成器：课件末尾追加"参考资料"页
        fusion_instruction['citation_sources'] = citation_sources
        
        # 生成PPT
        ppt_generator = get_ppt_generator()
        ppt_path = ppt_generator.generate(fusion_instruction)
        ppt_images = _render_ppt_images(ppt_path)
        
        # 生成Word
        word_generator = get_word_generator()
        word_path = word_generator.generate(fusion_instruction)
        
        # 生成互动游戏
        game_generator = get_game_generator()
        game_path = game_generator.generate(fusion_instruction)
        
        # 保存生成的文件路径（按用户隔离）
        _get_user_generated_files().update({
            'ppt': ppt_path,
            'word': word_path,
            'game': game_path
        })
        
        # 生成预览信息
        ppt_structure = fusion_instruction.get('ppt_structure', [])
        word_preview = f"教案标题：{fusion_instruction.get('course_title', '未命名')}\n"
        word_preview += f"教学目标：{fusion_instruction.get('teaching_objective', '')}\n"
        word_preview += f"授课时长：{fusion_instruction.get('duration', '')}\n"
        word_preview += f"受众：{fusion_instruction.get('target_audience', '')}"
        
        logger.info("课件生成成功")
        
        return jsonify({
            'success': True,
            'ppt_path': '/api/download/ppt',
            'word_path': '/api/download/word',
            'game_path': '/api/download/game',
            'ppt_structure': ppt_structure,
            'ppt_images': ppt_images,
            'word_preview': word_preview,
            'fusion_instruction': fusion_instruction,
            'used_rag': used_rag
        })
        
    except Exception as e:
        logger.error(f"课件生成错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/iterate', methods=['POST'])
@login_required
def iterate():
    """
    迭代优化API
    根据用户修改意见更新课件
    """
    try:
        data = request.json
        modification = data.get('modification', '')
        current_intent = data.get('current_intent', {})
        
        logger.info(f"收到迭代优化请求: {modification}")
        
        # 使用意图分析器处理修改指令
        intent_analyzer = get_intent_analyzer()
        updated_intent = intent_analyzer.apply_modification(current_intent, modification)
        
        # 融合更新后的意图
        fusion = get_multimodal_fusion()
        fusion_instruction = fusion.fuse(updated_intent, [], use_knowledge_base=True)
        
        # 重新生成
        ppt_generator = get_ppt_generator()
        ppt_path = ppt_generator.generate(fusion_instruction)
        ppt_images = _render_ppt_images(ppt_path)
        
        word_generator = get_word_generator()
        word_path = word_generator.generate(fusion_instruction)
        
        game_generator = get_game_generator()
        game_path = game_generator.generate(fusion_instruction)
        
        # 更新当前用户的文件路径
        _get_user_generated_files().update({
            'ppt': ppt_path,
            'word': word_path,
            'game': game_path
        })
        
        # 生成预览信息
        ppt_structure = fusion_instruction.get('ppt_structure', [])
        word_preview = f"教案标题：{fusion_instruction.get('course_title', '未命名')}\n"
        word_preview += f"教学目标：{fusion_instruction.get('teaching_objective', '')}\n"
        word_preview += f"授课时长：{fusion_instruction.get('duration', '')}\n"
        word_preview += f"受众：{fusion_instruction.get('target_audience', '')}"
        
        logger.info("迭代优化成功")
        
        return jsonify({
            'success': True,
            'ppt_path': '/api/download/ppt',
            'word_path': '/api/download/word',
            'game_path': '/api/download/game',
            'ppt_structure': ppt_structure,
            'ppt_images': ppt_images,
            'word_preview': word_preview,
            'fusion_instruction': fusion_instruction,
            'updated_intent': updated_intent
        })
        
    except Exception as e:
        logger.error(f"迭代优化错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/download/ppt', methods=['GET'])
@login_required
def download_ppt():
    """下载PPT文件"""
    try:
        filepath = _get_user_generated_files().get('ppt')
        logger.info(f"PPT下载请求，当前记录路径: {filepath}")
        if filepath and os.path.exists(filepath):
            return send_file(filepath, as_attachment=True, download_name='课件.pptx')
        else:
            logger.warning(f"PPT文件不存在: {filepath}")
            return jsonify({'success': False, 'error': 'PPT文件不存在'}), 404
    except Exception as e:
        logger.error(f"PPT下载错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/download/word', methods=['GET'])
@login_required
def download_word():
    """下载Word文件"""
    try:
        filepath = _get_user_generated_files().get('word')
        logger.info(f"Word下载请求，当前记录路径: {filepath}")
        if filepath and os.path.exists(filepath):
            return send_file(filepath, as_attachment=True, download_name='教案.docx')
        else:
            logger.warning(f"Word文件不存在: {filepath}")
            return jsonify({'success': False, 'error': 'Word文件不存在'}), 404
    except Exception as e:
        logger.error(f"Word下载错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/download/game', methods=['GET'])
@login_required
def download_game():
    """下载游戏HTML文件"""
    try:
        filepath = _get_user_generated_files().get('game')
        logger.info(f"游戏下载请求，当前记录路径: {filepath}")
        if filepath and os.path.exists(filepath):
            return send_file(filepath, as_attachment=True, download_name='互动游戏.html')
        else:
            logger.warning(f"游戏文件不存在: {filepath}")
            return jsonify({'success': False, 'error': '游戏文件不存在'}), 404
    except Exception as e:
        logger.error(f"游戏下载错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


def _render_ppt_images(ppt_path):
    """
    把PPT每页渲染成PNG，返回可访问的图片URL列表
    渲染链路不可用（无LibreOffice/PowerPoint）时返回空列表，前端据此提示下载查看
    """
    try:
        from app.utils.ppt_renderer import render_ppt_slides
        rel_paths = render_ppt_slides(ppt_path, app.config['OUTPUT_FOLDER'])
        urls = ['/api/outputs/' + quote(rel.replace(os.sep, '/')) for rel in rel_paths]
        logger.info(f"PPT预览图渲染完成: {len(urls)}页")
        return urls
    except Exception as e:
        logger.error(f"PPT预览图渲染失败: {str(e)}")
        return []


@app.route('/api/outputs/<path:relpath>', methods=['GET'])
@login_required
def serve_output_file(relpath):
    """按相对路径访问outputs目录下的文件（PPT预览图等），防目录穿越"""
    try:
        root = os.path.abspath(app.config['OUTPUT_FOLDER'])
        target = os.path.abspath(os.path.join(root, relpath))
        if not target.startswith(root + os.sep) or not os.path.isfile(target):
            return jsonify({'success': False, 'error': '文件不存在'}), 404
        return send_file(target)
    except Exception as e:
        logger.error(f"输出文件访问错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/preview/game', methods=['GET'])
@login_required
def preview_game():
    """内联预览互动游戏HTML（不作为附件下载，供iframe嵌入）"""
    try:
        filepath = _get_user_generated_files().get('game')
        if filepath and os.path.exists(filepath):
            return send_file(filepath, mimetype='text/html')
        return jsonify({'success': False, 'error': '游戏文件不存在'}), 404
    except Exception as e:
        logger.error(f"游戏预览错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/knowledge/upload', methods=['POST'])
@login_required
def knowledge_upload():
    """
    知识库上传API
    上传教学文档到本地RAG知识库
    """
    try:
        if 'files' not in request.files:
            return jsonify({'success': False, 'error': '没有文件'}), 400
        
        files = request.files.getlist('files')
        knowledge_base = get_vector_store()
        # 多模态解析器：pymupdf提取PDF文字（PyPDF2对CID编码的中文PDF普遍提取为空），文档内图片走OCR
        multimodal_parser = get_multimodal_parser()

        count = 0
        total_chunks_added = 0
        uploaded_files = []
        skipped_files = []

        for file in files:
            if file and allowed_file(file.filename):
                original_name = file.filename
                filename = secure_filename_keep_ext(original_name)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)

                try:
                    # 解析文件（正文文字 + 页内图片OCR）
                    parsed = multimodal_parser.parse_file(filepath)
                    full_text = parsed.get('full_text', '')

                    if full_text and full_text.strip():
                        # 记录提取的文本长度
                        text_length = len(full_text)
                        ocr_text_length = len(parsed.get('ocr_text', ''))
                        logger.info(f"文件 {original_name} 提取文本长度: {text_length} 字符（含OCR {ocr_text_length} 字符）")

                        # 分块（使用向量库默认参数 CHUNK_SIZE=300 / CHUNK_OVERLAP=50）
                        chunks = knowledge_base.chunk_text(full_text)
                        logger.info(f"文件 {original_name} 分块数量: {len(chunks)}")

                        # 添加到知识库（source保留原始文件名，便于知识库列表展示与按名删除；owner记录上传者）
                        metadatas = [{'source': original_name, 'type': parsed.get('type', 'unknown'), 'owner': session.get('username', '')} for _ in chunks]
                        added_count = knowledge_base.add_documents(chunks, metadatas=metadatas)
                        total_chunks_added += added_count
                        count += 1

                        uploaded_files.append({
                            'filename': original_name,
                            'type': parsed.get('type', 'unknown'),
                            'text_length': text_length,
                            'ocr_text_length': ocr_text_length,
                            'chunks': len(chunks),
                            'added': added_count
                        })

                        logger.info(f"成功添加到知识库: {original_name}, 入库块数: {added_count}")
                    else:
                        reason = '未提取到文本内容（若为纯扫描件PDF，需OCR可用才能识别）'
                        logger.warning(f"文件 {original_name} 提取文本为空，跳过入库")
                        skipped_files.append({'filename': original_name, 'reason': reason})
                except Exception as e:
                    logger.error(f"知识库添加失败 {original_name}: {str(e)}")
                    logger.error(traceback.format_exc())
                    skipped_files.append({'filename': original_name, 'reason': f'解析失败: {str(e)}'})
        
        # 获取更新后的统计信息
        stats = knowledge_base.get_stats()
        
        logger.info(f"知识库上传完成: 成功处理{count}个文件，总入库{total_chunks_added}个文本块")
        
        return jsonify({
            'success': True,
            'count': count,
            'total_chunks': total_chunks_added,
            'uploaded_files': uploaded_files,
            'skipped_files': skipped_files,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"知识库上传错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/knowledge/rebuild', methods=['POST'])
@login_required
def knowledge_rebuild():
    """
    知识库重建索引API
    清空向量库后，按当前分块参数（默认chunk_size=300/overlap=50）
    重新解析并入库uploads目录中的全部文档
    """
    try:
        knowledge_base = get_vector_store()
        multimodal_parser = get_multimodal_parser()

        # 清空旧索引
        cleared_chunks = knowledge_base.clear_all()
        logger.info(f"知识库重建：已清空 {cleared_chunks} 个旧块")

        rebuilt_files = []
        skipped_files = []
        total_chunks = 0

        for filename in sorted(os.listdir(app.config['UPLOAD_FOLDER'])):
            if not allowed_file(filename):
                continue
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            try:
                # 与上传链路一致：多模态解析（正文 + 图片OCR）
                parsed = multimodal_parser.parse_file(filepath)
                full_text = parsed.get('full_text', '')

                if not full_text.strip():
                    skipped_files.append({'filename': filename, 'reason': '未提取到文本内容'})
                    continue

                # 分块（向量库默认参数300/50）
                chunks = knowledge_base.chunk_text(full_text)
                metadatas = [{'source': filename, 'type': parsed.get('type', 'unknown')} for _ in chunks]
                added = knowledge_base.add_documents(chunks, metadatas=metadatas)
                total_chunks += added
                rebuilt_files.append({'filename': filename, 'chunks': added})
                logger.info(f"重建入库: {filename} -> {added}块")
            except Exception as e:
                logger.error(f"重建处理失败 {filename}: {str(e)}")
                skipped_files.append({'filename': filename, 'reason': str(e)})

        stats = knowledge_base.get_stats()
        logger.info(f"知识库重建完成: {len(rebuilt_files)}个文件, 共{total_chunks}块")

        return jsonify({
            'success': True,
            'cleared_chunks': cleared_chunks,
            'rebuilt_files': rebuilt_files,
            'skipped_files': skipped_files,
            'total_chunks': total_chunks,
            'stats': stats
        })

    except Exception as e:
        logger.error(f"知识库重建错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/knowledge/stats', methods=['GET'])
@login_required
def knowledge_stats():
    """
    知识库统计API
    获取知识库统计信息
    """
    try:
        knowledge_base = get_vector_store()
        stats = knowledge_base.get_stats()
        
        return jsonify({
            'success': True,
            'stats': stats
        })
        
    except Exception as e:
        logger.error(f"知识库统计错误: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/knowledge/search', methods=['POST'])
@login_required
def knowledge_search():
    """
    知识库搜索API
    语义检索知识库内容
    """
    try:
        data = request.json
        query = data.get('query', '')
        top_k = data.get('top_k', 5)  # 允许前端指定top_k，默认5
        similarity_threshold = data.get('similarity_threshold', 0.015)  # 相似度阈值
        
        if not query:
            return jsonify({'success': False, 'error': '查询内容不能为空'}), 400
        
        logger.info(f"知识库搜索请求: 查询='{query}', top_k={top_k}, 阈值={similarity_threshold}")
        
        knowledge_base = get_vector_store()
        results = knowledge_base.search(query, top_k=top_k, similarity_threshold=similarity_threshold)
        
        logger.info(f"知识库搜索返回: {len(results)}个结果")
        
        return jsonify({
            'success': True,
            'results': results,
            'query': query,
            'top_k': top_k,
            'similarity_threshold': similarity_threshold
        })
        
    except Exception as e:
        logger.error(f"知识库搜索错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/knowledge/delete', methods=['POST'])
@login_required
def knowledge_delete():
    """
    知识库删除API
    删除指定文档的所有块
    """
    try:
        data = request.json
        source_name = data.get('source_name', '')
        
        if not source_name:
            return jsonify({'success': False, 'error': '文档名称不能为空'}), 400
        
        logger.info(f"知识库删除请求: 文档={source_name}")
        
        knowledge_base = get_vector_store()
        deleted_count = knowledge_base.delete_document(source_name)
        
        logger.info(f"知识库删除完成: 删除了{deleted_count}个块")
        
        return jsonify({
            'success': True,
            'deleted_count': deleted_count,
            'source_name': source_name
        })
        
    except Exception as e:
        logger.error(f"知识库删除错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/knowledge/clear', methods=['POST'])
@login_required
def knowledge_clear():
    """
    知识库清空API
    清空所有文档和文本块
    """
    try:
        logger.info("知识库清空请求")
        
        knowledge_base = get_vector_store()
        deleted_count = knowledge_base.clear_all()
        
        logger.info(f"知识库清空完成: 删除了{deleted_count}个块")
        
        return jsonify({
            'success': True,
            'deleted_count': deleted_count
        })
        
    except Exception as e:
        logger.error(f"知识库清空错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


@app.route('/api/parse-image', methods=['POST'])
@login_required
def parse_image():
    """
    图片解析API
    使用多模态模型识别图片中的文字、报文信息、拓扑结构
    """
    try:
        if 'image' not in request.files:
            return jsonify({'success': False, 'error': '未上传图片'}), 400
        
        image_file = request.files['image']
        
        if image_file.filename == '':
            return jsonify({'success': False, 'error': '未选择文件'}), 400
        
        if not allowed_file(image_file.filename):
            return jsonify({'success': False, 'error': '不支持的文件类型'}), 400
        
        # 检查文件大小（限制为10MB）
        image_file.seek(0, os.SEEK_END)
        file_size = image_file.tell()
        image_file.seek(0)
        
        if file_size > 10 * 1024 * 1024:  # 10MB
            return jsonify({'success': False, 'error': '图片过大，请上传小于10MB的图片'}), 400
        
        # 保存上传的图片
        filename = secure_filename_keep_ext(image_file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        image_file.save(filepath)
        
        logger.info(f"收到图片上传请求: {filename}, 大小: {file_size} 字节")
        
        # 调用多模态解析
        from app.utils.image_parser import get_image_parser
        image_parser = get_image_parser()
        
        parsed_text = image_parser.parse_image(filepath)
        
        logger.info(f"图片解析成功: {filename}, 解析文本长度: {len(parsed_text)}")
        
        return jsonify({
            'success': True,
            'parsed_text': parsed_text,
            'filename': filename
        })
        
    except Exception as e:
        error_msg = str(e)
        logger.error(f"图片解析错误: {error_msg}")
        traceback.print_exc()
        
        # 提供友好的错误提示
        if 'API密钥' in error_msg or 'api_key' in error_msg.lower():
            return jsonify({'success': False, 'error': 'API密钥错误，请检查DASHSCOPE_API_KEY环境变量'}), 500
        elif '额度' in error_msg or 'quota' in error_msg.lower():
            return jsonify({'success': False, 'error': 'API额度不足，请检查阿里云百炼账户'}), 500
        elif 'dashscope' in error_msg.lower():
            return jsonify({'success': False, 'error': 'DashScope服务错误，请稍后重试'}), 500
        else:
            return jsonify({'success': False, 'error': f'图片解析失败: {error_msg}'}), 500


@app.route('/api/save-to-knowledge-base', methods=['POST'])
@login_required
def save_to_knowledge_base():
    """
    保存到知识库API
    将图片解析结果保存到知识库
    """
    try:
        data = request.get_json()
        content = data.get('content', '')
        source = data.get('source', '未知来源')
        doc_type = data.get('type', 'text')
        
        if not content:
            return jsonify({'success': False, 'error': '内容不能为空'}), 400
        
        # 获取知识库实例
        kb = get_vector_store()
        
        # 添加到知识库
        kb.add_document(content, metadata={
            'source': source,
            'type': doc_type,
            'timestamp': datetime.now().isoformat()
        })
        
        logger.info(f"成功保存到知识库: 来源={source}, 类型={doc_type}, 内容长度={len(content)}")
        
        return jsonify({
            'success': True,
            'message': '成功保存到知识库'
        })
        
    except Exception as e:
        logger.error(f"保存到知识库错误: {str(e)}")
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/save-teaching-demand', methods=['POST'])
@login_required
def save_teaching_demand():
    """
    保存教学需求API
    接收demand字段，存入session，供课件生成接口读取
    """
    try:
        data = request.get_json() or {}
        demand = data.get('demand')

        if not demand:
            logger.warning("保存教学需求失败：demand为空")
            return jsonify({
                'success': False,
                'msg': '教学需求不能为空'
            }), 400

        session['teaching_demand'] = demand
        logger.info(f"教学需求已存入session: {demand}")

        return jsonify({
            'success': True,
            'msg': '教学需求已保存'
        })

    except Exception as e:
        logger.error(f"保存教学需求错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'msg': str(e)
        }), 500


# 课件生成接口的系统提示词：优先采用知识库参考资料，表单已确认参数禁止改写
_COURSE_GENERATION_SYSTEM_PROMPT = """你是一位专业的教学课件设计专家。你的任务是根据知识库参考资料和教师已确认的教学需求，生成标准化的课件生成指令。

规则：
1. 优先采用【知识库参考资料】中的事实、概念、案例、数据，保证课件内容与参考资料一致；参考资料未覆盖的部分，结合你的教学专业知识补全
2. 教师已确认的表单参数（教学目标、重难点、授课时长、知识点等）必须原样保留，禁止改写
3. 输出必须严格遵守给定JSON结构，字段名称保持不变
4. 【硬性要求】课件内容中凡引用或改写自【知识库参考资料】的内容（如幻灯片内容、教学流程、板书设计、课后作业等文本字段），必须在该段内容末尾标注来源文件名，格式为【参考：文档名称】，例如【参考：TCP三次握手教学素材.docx】；同一段内容参考多个文档时，文档名称用顿号分隔；未引用参考资料的内容禁止标注。只要使用了参考资料中的事实、概念或数据就必须标注，遗漏标注视为不合规输出"""


def _build_course_query_terms(intent):
    """
    从表单教学需求中提取RAG检索关键词
    （课程标题、三层教学目标、知识点、教学重难点）
    """
    terms = []

    course_title = intent.get('course_title')
    if course_title:
        terms.append(str(course_title))

    teaching_objective = intent.get('teaching_objective')
    if isinstance(teaching_objective, dict):
        for obj_key in ('knowledge_objective', 'ability_objective', 'quality_objective'):
            obj_value = teaching_objective.get(obj_key)
            if obj_value:
                terms.append(str(obj_value))
    elif teaching_objective:
        terms.append(str(teaching_objective))

    knowledge_points = intent.get('knowledge_points')
    if isinstance(knowledge_points, (list, tuple)):
        terms.extend(str(point) for point in knowledge_points if point)
    elif knowledge_points:
        terms.append(str(knowledge_points))

    key_difficulties = intent.get('key_difficulties')
    if isinstance(key_difficulties, dict):
        for point in key_difficulties.get('key_points') or []:
            terms.append(str(point))
        for dp in key_difficulties.get('difficult_points') or []:
            dp_text = dp.get('content', '') if isinstance(dp, dict) else dp
            if dp_text:
                terms.append(str(dp_text))
    elif isinstance(key_difficulties, (list, tuple)):
        terms.extend(str(item) for item in key_difficulties if item)
    elif key_difficulties:
        terms.append(str(key_difficulties))

    # 去重保序
    seen = set()
    unique_terms = []
    for term in terms:
        term = term.strip()
        if term and term not in seen:
            seen.add(term)
            unique_terms.append(term)
    return unique_terms


def _format_teaching_requirement(intent):
    """将表单教学需求序列化为prompt文本"""
    lines = []

    teaching_objective = intent.get('teaching_objective')
    if isinstance(teaching_objective, dict):
        lines.append(f"知识目标：{teaching_objective.get('knowledge_objective', '未指定')}")
        lines.append(f"能力目标：{teaching_objective.get('ability_objective', '未指定')}")
        lines.append(f"素养目标：{teaching_objective.get('quality_objective', '未指定')}")
    elif teaching_objective:
        lines.append(f"教学目标：{teaching_objective}")

    lines.append(f"授课时长：{intent.get('duration', '未指定')}")
    lines.append(f"受众年级：{intent.get('target_grade', '未指定')}")

    knowledge_points = intent.get('knowledge_points') or []
    if isinstance(knowledge_points, (list, tuple)):
        lines.append(f"知识点：{', '.join(str(p) for p in knowledge_points)}")
    else:
        lines.append(f"知识点：{knowledge_points}")

    key_difficulties = intent.get('key_difficulties')
    if isinstance(key_difficulties, dict):
        key_points = key_difficulties.get('key_points') or []
        lines.append(f"教学重点：{', '.join(str(p) for p in key_points)}")
        dp_texts = []
        for dp in key_difficulties.get('difficult_points') or []:
            if isinstance(dp, dict):
                dp_text = dp.get('content', '')
                if dp.get('reason'):
                    dp_text += f"（{dp['reason']}）"
                dp_texts.append(dp_text)
            else:
                dp_texts.append(str(dp))
        lines.append(f"教学难点：{'；'.join(dp_texts)}")
    elif key_difficulties:
        lines.append(f"教学重难点：{key_difficulties}")

    audience_analysis = intent.get('audience_analysis')
    if isinstance(audience_analysis, dict):
        lines.append(f"前置知识：{audience_analysis.get('prerequisite_knowledge', '未指定')}")
        misconceptions = audience_analysis.get('cognitive_misconceptions') or []
        lines.append(f"认知误区：{', '.join(str(m) for m in misconceptions)}")

    activities = intent.get('classroom_activities') or []
    if activities:
        act_texts = []
        for act in activities:
            if isinstance(act, dict):
                act_texts.append(f"{act.get('activity', '')}：{act.get('description', '')}")
            else:
                act_texts.append(str(act))
        lines.append(f"课堂活动：{'；'.join(act_texts)}")

    questions = intent.get('classroom_questions') or []
    if questions:
        lines.append(f"课堂提问：{'；'.join(str(q) for q in questions)}")

    if intent.get('style_preference'):
        lines.append(f"课件风格：{intent['style_preference']}")
    if intent.get('special_requirements'):
        lines.append(f"特殊要求：{intent['special_requirements']}")

    return "\n".join(lines)


def _build_course_generation_prompt(intent, retrieved_chunks):
    """
    组装课件生成prompt：知识库检索片段作为参考资料拼在前面，用户教学需求拼在后面
    """
    prompt = ""
    if retrieved_chunks:
        prompt += "【知识库参考资料】（生成课件时优先采用其中的事实、概念、案例与数据）\n"
        for i, chunk in enumerate(retrieved_chunks, 1):
            source = chunk.get('metadata', {}).get('source', '未知文档')
            prompt += f"\n[片段{i}]【来源：{source}】\n{chunk.get('content', '')}\n"
        prompt += "\n"

    prompt += "【教师教学需求】（以下为教师已确认的表单参数，禁止改动）\n"
    prompt += _format_teaching_requirement(intent)

    prompt += """

请结合上述知识库参考资料与教师教学需求，以JSON格式返回课件生成指令，包含以下字段：
{
    "course_title": "课件标题",
    "teaching_objective": "教学目标（详细描述，字符串）",
    "target_audience": "目标受众",
    "duration": "授课时长",
    "knowledge_points": ["知识点1", "知识点2"],
    "key_points": ["重点1", "重点2"],
    "difficult_points": ["难点1", "难点2"],
    "teaching_flow": [
        {
            "stage": "导入/新授/练习/总结",
            "content": "阶段内容描述",
            "time_allocation": "时间分配"
        }
    ],
    "classroom_activities": [
        {
            "activity": "活动名称",
            "description": "活动描述",
            "interaction_type": "问答/讨论/游戏/演示"
        }
    ],
    "homework": "课后作业设计",
    "blackboard_design": "板书设计",
    "ppt_structure": [
        {
            "slide_type": "cover/directory/knowledge/case/interaction/summary/ending",
            "title": "幻灯片标题",
            "content": "幻灯片内容要点",
            "visual_elements": "视觉元素建议"
        }
    ],
    "interactive_game": {
        "type": "问答游戏/填空游戏/配对游戏",
        "title": "游戏标题",
        "content": "游戏内容设计"
    }
}

注意：上述JSON的所有文本内容字段（teaching_flow的content、ppt_structure的content、blackboard_design、homework、classroom_activities的description等），凡引用或改写自【知识库参考资料】的内容，必须在该段内容末尾标注来源，格式为【参考：文档名称】（例如【参考：TCP三次握手教学素材.docx】），文档名称与片段标注的来源保持一致；未引用参考资料的内容不要标注。
"""
    return prompt


def _normalize_instruction_for_generators(instruction):
    """
    补齐/规范下游生成器消费的字段，不改动表单已确认的教学需求内容
    """
    # teaching_objective：三层目标字典转为文本（Word生成器需要字符串）
    teaching_objective = instruction.get('teaching_objective')
    if isinstance(teaching_objective, dict):
        instruction['teaching_objective'] = (
            f"知识目标：{teaching_objective.get('knowledge_objective', '')}\n"
            f"能力目标：{teaching_objective.get('ability_objective', '')}\n"
            f"素养目标：{teaching_objective.get('quality_objective', '')}"
        ).strip()

    # key_points / difficult_points：从表单 key_difficulties 补齐
    key_difficulties = instruction.get('key_difficulties')
    if isinstance(key_difficulties, dict):
        if not instruction.get('key_points'):
            instruction['key_points'] = key_difficulties.get('key_points') or []
        if not instruction.get('difficult_points'):
            dp_texts = []
            for dp in key_difficulties.get('difficult_points') or []:
                if isinstance(dp, dict):
                    dp_text = dp.get('content', '')
                    if dp.get('reason'):
                        dp_text += f"（{dp['reason']}）"
                    dp_texts.append(dp_text)
                else:
                    dp_texts.append(str(dp))
            instruction['difficult_points'] = dp_texts

    # difficult_points 中的字典项统一转为字符串
    normalized_dps = []
    for dp in instruction.get('difficult_points') or []:
        if isinstance(dp, dict):
            dp_text = dp.get('content', '')
            if dp.get('reason'):
                dp_text += f"（{dp['reason']}）"
            normalized_dps.append(dp_text)
        else:
            normalized_dps.append(str(dp))
    if normalized_dps:
        instruction['difficult_points'] = normalized_dps

    # target_audience：从表单 target_grade 补齐
    if not instruction.get('target_audience') and instruction.get('target_grade'):
        instruction['target_audience'] = instruction['target_grade']

    # course_title 兜底
    if not instruction.get('course_title'):
        knowledge_points = instruction.get('knowledge_points') or []
        if isinstance(knowledge_points, (list, tuple)) and knowledge_points:
            instruction['course_title'] = str(knowledge_points[0])
        else:
            instruction['course_title'] = '教学课件'


@app.route('/api/generate-course', methods=['POST'])
@login_required
def generate_course():
    """
    基于确认的教学需求生成课件
    接收POST参数 structured_requirement，为空时读取session中的teaching_demand
    生成前先按教学需求关键词检索知识库，检索片段作为参考资料拼在教学需求前面一起传给LLM
    """
    try:
        # 获取结构化需求
        data = request.get_json() or {}
        structured_requirement = data.get('structured_requirement')
        
        # 请求中未携带时，读取session中保存的教学需求
        if not structured_requirement:
            structured_requirement = session.get('teaching_demand')
        
        # 打印日志
        logger.info(f"收到课件生成请求，structured_requirement={structured_requirement}")
        
        # 校验教学需求非空
        if not structured_requirement or not isinstance(structured_requirement, dict):
            logger.warning("未找到待确认的教学需求")
            return jsonify({
                'success': False,
                'msg': '未找到待确认的教学需求'
            }), 400
        
        logger.info(f"结构化需求已接收，开始生成课件")
        
        # 使用结构化需求生成课件（复用原有逻辑）
        intent = structured_requirement

        # 第一步：RAG检索——按教学需求关键词（标题/教学目标/知识点/重难点）检索知识库
        rag_context = ""
        used_rag = False
        citation_sources = []
        retrieved_chunks = []

        try:
            knowledge_base = get_vector_store()
            query_terms = _build_course_query_terms(intent)

            all_search_results = []
            for query in query_terms[:5]:  # 最多检索5个查询词
                results = knowledge_base.search(query, top_k=5, similarity_threshold=0.015)
                all_search_results.extend(results)

            if all_search_results:
                # 去重并按相似度排序
                seen_contents = set()
                unique_results = []
                for result in all_search_results:
                    content = result.get('content', '')
                    if content and content not in seen_contents:
                        seen_contents.add(content)
                        unique_results.append(result)

                # 按相似度排序
                unique_results.sort(key=lambda x: x.get('similarity', 0), reverse=True)
                retrieved_chunks = unique_results[:10]  # 最多保留10个结果

                # 收集引用来源（文档名称，按相关度顺序去重）
                for result in retrieved_chunks:
                    source = result.get('metadata', {}).get('source', '未知文档')
                    if source not in citation_sources:
                        citation_sources.append(source)

                # 提取检索到的内容
                rag_context_parts = []
                for result in retrieved_chunks:
                    source = result.get('metadata', {}).get('source', '未知文档')
                    content = result.get('content', '')
                    similarity = result.get('similarity', 0)
                    rag_context_parts.append(f"[来源: {source}, 相似度: {similarity:.4f}] {content}")

                rag_context = "\n\n".join(rag_context_parts)
                used_rag = True

                logger.info(f"课件生成RAG检索成功: 检索到{len(retrieved_chunks)}个片段, 引用来源: {citation_sources}")
                for i, result in enumerate(retrieved_chunks):
                    logger.info(f"  片段{i+1}: 相似度={result.get('similarity', 0):.4f}, 来源={result.get('metadata', {}).get('source', 'unknown')}")
            else:
                logger.warning("课件生成RAG检索未找到匹配内容")
        except Exception as e:
            logger.error(f"课件生成RAG检索失败: {str(e)}")

        # 生成前确保输出目录存在（适配Windows路径）
        os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)

        # 第二步：组装LLM prompt——检索片段作为参考资料拼在教学需求前面，一起传给LLM
        llm_instruction = None
        llm_client = get_llm_client()
        if not llm_client.use_mock:
            try:
                prompt = _build_course_generation_prompt(intent, retrieved_chunks)
                llm_instruction = llm_client.structured_completion(
                    prompt,
                    _COURSE_GENERATION_SYSTEM_PROMPT,
                    use_rag=False  # 检索片段已手动拼入prompt，不再重复检索
                )
                if not isinstance(llm_instruction, dict) or not llm_instruction:
                    llm_instruction = None
                    logger.warning("LLM返回结果为空，回退为表单参数直接生成")
                else:
                    logger.info("LLM已基于知识库参考资料生成课件生成指令")
            except Exception as e:
                llm_instruction = None
                logger.error(f"课件生成LLM调用失败，回退为表单参数直接生成: {str(e)}")

        # 第三步：合并指令——LLM结果为底，表单已确认参数原样覆盖，保证知识目标/重难点/时长等不变
        final_instruction = dict(llm_instruction) if llm_instruction else {}
        for key, value in intent.items():
            final_instruction[key] = value
        final_instruction['rag_context'] = rag_context
        # 溯源信息传入生成器：课件/教案末尾追加"参考资料"，兜底保证来源可见
        final_instruction['citation_sources'] = citation_sources
        _normalize_instruction_for_generators(final_instruction)

        # 生成PPT
        ppt_generator = get_ppt_generator()
        ppt_path = ppt_generator.generate(final_instruction)
        ppt_path, ppt_err = verify_generated_file(ppt_path, 'PPT')
        if ppt_err:
            return jsonify({'success': False, 'msg': ppt_err, 'error': ppt_err}), 500
        ppt_images = _render_ppt_images(ppt_path)

        # 生成Word
        word_generator = get_word_generator()
        word_path = word_generator.generate(final_instruction)
        word_path, word_err = verify_generated_file(word_path, 'Word教案')
        if word_err:
            return jsonify({'success': False, 'msg': word_err, 'error': word_err}), 500

        # 生成游戏
        game_generator = get_game_generator()
        game_path = game_generator.generate(final_instruction)
        game_path, game_err = verify_generated_file(game_path, '互动游戏')
        if game_err:
            return jsonify({'success': False, 'msg': game_err, 'error': game_err}), 500
        
        # 保存生成的文件路径（按用户隔离，键名与下载接口保持一致）
        _get_user_generated_files().update({
            'ppt': ppt_path,
            'word': word_path,
            'game': game_path
        })
        
        logger.info(f"课件生成成功: PPT={ppt_path}, Word={word_path}, Game={game_path}")
        
        return jsonify({
            'success': True,
            'ppt_path': ppt_path,
            'word_path': word_path,
            'game_path': game_path,
            'ppt_file': ppt_path,
            'word_file': word_path,
            'game_file': game_path,
            'ppt_images': ppt_images,
            'used_rag': used_rag,
            'citation_sources': citation_sources
        })
        
    except Exception as e:
        logger.error(f"课件生成错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'msg': str(e)
        }), 500


@app.route('/api/generate-courseware', methods=['POST'])
@login_required
def generate_courseware():
    """
    基于确认的教学需求生成课件
    接收POST参数 structured_requirement
    """
    try:
        # 获取结构化需求
        data = request.get_json()
        structured_requirement = data.get('structured_requirement')
        
        # 打印日志
        logger.info(f"课件生成收到结构化需求: {structured_requirement}")
        
        # 检查structured_requirement是否为空或不存在
        if not structured_requirement or not isinstance(structured_requirement, dict):
            logger.warning("未找到待确认的教学需求")
            return jsonify({
                'success': False,
                'error': '未找到待确认的教学需求'
            }), 400
        
        logger.info(f"结构化需求已接收，开始生成课件")
        
        # 使用结构化需求生成课件（复用原有逻辑）
        # 这里简化处理，直接调用原有的生成逻辑
        # 实际项目中可能需要适配数据结构
        
        # 临时：将structured_requirement转换为intent格式
        intent = structured_requirement
        
        # RAG检索（默认启用）
        rag_context = ""
        used_rag = False
        citation_sources = []
        
        try:
            knowledge_base = get_vector_store()
            # 使用知识点作为查询词
            knowledge_points = intent.get('knowledge_points', [])
            
            if knowledge_points:
                all_search_results = []
                for query in knowledge_points[:3]:  # 最多检索3个查询词
                    if query:
                        results = knowledge_base.search(query, top_k=5, similarity_threshold=0.015)
                        all_search_results.extend(results)
                
                if all_search_results:
                    # 去重并按相似度排序
                    seen_contents = set()
                    unique_results = []
                    for result in all_search_results:
                        content = result.get('content', '')
                        if content not in seen_contents:
                            seen_contents.add(content)
                            unique_results.append(result)
                    
                    # 按相似度排序
                    unique_results.sort(key=lambda x: x.get('similarity', 0), reverse=True)
                    unique_results = unique_results[:10]  # 最多保留10个结果
                    
                    # 提取检索到的内容
                    rag_context_parts = []
                    for result in unique_results:
                        source = result.get('metadata', {}).get('source', '未知文档')
                        content = result.get('content', '')
                        similarity = result.get('similarity', 0)
                        rag_context_parts.append(f"[来源: {source}, 相似度: {similarity:.4f}] {content}")
                        if source not in citation_sources:
                            citation_sources.append(source)
                    
                    rag_context = "\n\n".join(rag_context_parts)
                    used_rag = True
                    
                    logger.info(f"课件生成RAG检索成功: 检索到{len(unique_results)}个片段")
        except Exception as e:
            logger.error(f"课件生成RAG检索失败: {str(e)}")
        
        # 生成前确保输出目录存在（适配Windows路径）
        os.makedirs(app.config['OUTPUT_FOLDER'], exist_ok=True)
        
        # 将RAG检索到的教学素材挂到intent，供下游生成器/大模型prompt使用
        intent['rag_context'] = rag_context
        # 溯源信息传入生成器：课件/教案末尾追加"参考资料"
        intent['citation_sources'] = citation_sources
        
        # 生成PPT
        ppt_generator = get_ppt_generator()
        ppt_path = ppt_generator.generate(intent)
        ppt_path, ppt_err = verify_generated_file(ppt_path, 'PPT')
        if ppt_err:
            return jsonify({'success': False, 'msg': ppt_err, 'error': ppt_err}), 500
        ppt_images = _render_ppt_images(ppt_path)
        
        # 生成Word
        word_generator = get_word_generator()
        word_path = word_generator.generate(intent)
        word_path, word_err = verify_generated_file(word_path, 'Word教案')
        if word_err:
            return jsonify({'success': False, 'msg': word_err, 'error': word_err}), 500
        
        # 生成游戏
        game_generator = get_game_generator()
        game_path = game_generator.generate(intent)
        game_path, game_err = verify_generated_file(game_path, '互动游戏')
        if game_err:
            return jsonify({'success': False, 'msg': game_err, 'error': game_err}), 500
        
        # 保存生成的文件路径（按用户隔离，键名与下载接口保持一致）
        _get_user_generated_files().update({
            'ppt': ppt_path,
            'word': word_path,
            'game': game_path
        })
        
        logger.info(f"课件生成成功: PPT={ppt_path}, Word={word_path}, Game={game_path}")
        
        return jsonify({
            'success': True,
            'ppt_path': ppt_path,
            'word_path': word_path,
            'game_path': game_path,
            'ppt_file': ppt_path,
            'word_file': word_path,
            'game_file': game_path,
            'ppt_images': ppt_images,
            'used_rag': used_rag,
            'citation_sources': citation_sources
        })
        
    except Exception as e:
        logger.error(f"课件生成错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


RAG_UPLOAD_EXTENSIONS = {'pdf', 'docx', 'pptx', 'png', 'jpg', 'jpeg', 'txt'}


@app.route('/api/upload_rag_file', methods=['POST'])
@login_required
def upload_rag_file():
    """
    RAG文件上传API
    上传PDF/Word/PPT/图片，自动多模态解析（文字+图片OCR），解析结果存入chromadb向量库
    """
    try:
        if 'file' not in request.files:
            return jsonify({'success': False, 'error': '没有文件'}), 400

        file = request.files['file']
        if not file or not file.filename:
            return jsonify({'success': False, 'error': '未选择文件'}), 400

        file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
        if file_ext not in RAG_UPLOAD_EXTENSIONS:
            return jsonify({'success': False, 'error': f'不支持的文件类型: {file_ext}，支持: {"/".join(sorted(RAG_UPLOAD_EXTENSIONS))}'}), 400

        # 保存上传文件
        filename = secure_filename_keep_ext(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        logger.info(f"RAG上传文件已保存: {filepath}")

        # 多模态解析（文字 + 图片OCR）
        from multimodal_parser import get_multimodal_parser
        from multimodal_parser.ocr import is_ocr_available

        parser = get_multimodal_parser()
        parsed = parser.parse_file(filepath)

        full_text = parsed.get('full_text', '')
        if not full_text.strip():
            return jsonify({
                'success': False,
                'error': '未从文件中解析出任何文本内容',
                'ocr_available': is_ocr_available()
            }), 400

        # 分块入库
        vector_store = get_vector_store()
        chunks = vector_store.chunk_text(full_text)
        metadatas = [{'source': filename, 'type': file_ext, 'owner': session.get('username', '')} for _ in chunks]
        chunks_added = vector_store.add_documents(chunks, metadatas=metadatas)

        logger.info(f"RAG文件入库完成: {filename}, 文字{len(parsed['text'])}字符, OCR{len(parsed['ocr_text'])}字符, 入库{chunks_added}块")

        return jsonify({
            'success': True,
            'file_name': filename,
            'text_length': len(parsed['text']),
            'ocr_text_length': len(parsed['ocr_text']),
            'chunks_added': chunks_added,
            'ocr_available': is_ocr_available(),
            'stats': vector_store.get_stats()
        })

    except Exception as e:
        logger.error(f"RAG文件上传错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/rag_query', methods=['POST'])
@login_required
def rag_query():
    """
    RAG检索API
    用户提问，检索chromadb向量库，返回参考片段
    """
    try:
        data = request.get_json() or {}
        query = data.get('query', '')
        top_k = int(data.get('top_k', 5))

        if not query.strip():
            return jsonify({'success': False, 'error': '查询内容不能为空'}), 400

        vector_store = get_vector_store()
        results = vector_store.search(query, top_k=top_k)

        return jsonify({
            'success': True,
            'query': query,
            'top_k': top_k,
            'results': [{
                'content': r['content'],
                'metadata': r['metadata'],
                'similarity': r['similarity']
            } for r in results]
        })

    except Exception as e:
        logger.error(f"RAG检索错误: {str(e)}")
        logger.error(traceback.format_exc())
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    from dotenv import load_dotenv
    load_dotenv()
    
    host = os.getenv('FLASK_HOST', '0.0.0.0')
    port = int(os.getenv('FLASK_PORT', 5000))
    debug = os.getenv('FLASK_DEBUG', 'True').lower() == 'true'
    
    logger.info(f"启动Flask服务器: {host}:{port}")
    logger.info(f"调试模式: {debug}")
    
    app.run(host=host, port=port, debug=debug)
