"""生成一张带中文文字的测试图片，用于验证PaddleOCR"""
import sys

from PIL import Image, ImageDraw, ImageFont

img = Image.new('RGB', (600, 160), color='white')
draw = ImageDraw.Draw(img)

font = None
for path in (r'C:\Windows\Fonts\msyh.ttc', r'C:\Windows\Fonts\simhei.ttf'):
    try:
        font = ImageFont.truetype(path, 40)
        break
    except Exception:
        continue
if font is None:
    sys.exit('未找到可用中文字体')

draw.text((20, 20), '人工智能教学助手', font=font, fill='black')
draw.text((20, 90), '机器学习与深度学习基础', font=font, fill='black')

out = sys.argv[1] if len(sys.argv) > 1 else 'test_ocr.png'
img.save(out)
print(f'测试图片已生成: {out}')
