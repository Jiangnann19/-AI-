"""
多模态文档解析模块
解析PDF/DOCX/PPTX提取文字，文档内图片执行OCR；独立图片直接OCR
解析出的全部文本（文字+OCR内容）用于送入RAG向量库
"""

import os
import logging
from typing import Dict, List

from .ocr import ocr_image_bytes, ocr_image_file

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg'}


class MultimodalParser:
    """多模态文档解析器"""

    def __init__(self):
        self.supported_formats = {
            'pdf': self._parse_pdf,
            'docx': self._parse_docx,
            'pptx': self._parse_pptx,
            'txt': self._parse_txt,
            'png': self._parse_image,
            'jpg': self._parse_image,
            'jpeg': self._parse_image,
        }
        # OCR引擎懒加载：只在真正遇到图片时才初始化，不干扰文档正文提取
        logger.info("多模态解析器初始化完成（OCR按需加载，仅处理图片）")

    def parse_file(self, file_path: str) -> Dict:
        """
        解析文件，提取文字和图片OCR内容

        Args:
            file_path: 文件路径

        Returns:
            {type, file_name, text, ocr_text, full_text}
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"文件不存在: {file_path}")

        file_ext = os.path.splitext(file_path)[1].lower().lstrip('.')

        if file_ext not in self.supported_formats:
            raise ValueError(f"不支持的文件格式: {file_ext}")

        parser_func = self.supported_formats[file_ext]
        text, ocr_text = parser_func(file_path)

        full_text = text
        if ocr_text:
            full_text = f"{text}\n\n【图片OCR识别内容】\n{ocr_text}" if text else ocr_text

        result = {
            'type': file_ext,
            'file_name': os.path.basename(file_path),
            'text': text,
            'ocr_text': ocr_text,
            'full_text': full_text
        }

        logger.info(f"多模态解析完成: {file_path}, 文字{len(text)}字符, OCR{len(ocr_text)}字符")
        return result

    def _parse_pdf(self, file_path: str):
        """解析PDF：pymupdf提取文字 + 页内图片OCR"""
        import fitz  # pymupdf

        text_parts: List[str] = []
        ocr_parts: List[str] = []

        doc = fitz.open(file_path)
        try:
            for page_num in range(len(doc)):
                page = doc[page_num]

                page_text = page.get_text().strip()
                if page_text:
                    text_parts.append(page_text)

                # 提取页内图片并OCR
                for img_index, img_info in enumerate(page.get_images(full=True)):
                    xref = img_info[0]
                    try:
                        image_bytes = doc.extract_image(xref)['image']
                        ocr_text = ocr_image_bytes(image_bytes)
                        if ocr_text:
                            ocr_parts.append(f"[第{page_num + 1}页图片{img_index + 1}] {ocr_text}")
                    except Exception as e:
                        logger.warning(f"PDF第{page_num + 1}页图片{img_index + 1}提取失败: {e}")
        finally:
            doc.close()

        logger.info(f"PDF解析成功: {file_path}, 总页数: {len(text_parts)}, OCR图片数: {len(ocr_parts)}")
        return '\n'.join(text_parts), '\n'.join(ocr_parts)

    def _parse_docx(self, file_path: str):
        """解析DOCX：段落+表格文字，嵌入图片OCR"""
        from docx import Document

        text_parts: List[str] = []
        ocr_parts: List[str] = []

        doc = Document(file_path)

        for para in doc.paragraphs:
            if para.text.strip():
                text_parts.append(para.text)

        # 提取表格内容
        for table in doc.tables:
            for row in table.rows:
                row_text = ' | '.join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    text_parts.append(row_text)

        # 提取嵌入图片并OCR
        img_index = 0
        for rel in doc.part.rels.values():
            if 'image' in rel.reltype:
                img_index += 1
                try:
                    ocr_text = ocr_image_bytes(rel.target_part.blob)
                    if ocr_text:
                        ocr_parts.append(f"[文档图片{img_index}] {ocr_text}")
                except Exception as e:
                    logger.warning(f"DOCX图片{img_index}提取失败: {e}")

        logger.info(f"DOCX解析成功: {file_path}, 段落数: {len(text_parts)}, OCR图片数: {len(ocr_parts)}")
        return '\n'.join(text_parts), '\n'.join(ocr_parts)

    def _parse_pptx(self, file_path: str):
        """解析PPTX：幻灯片文字，图片shape OCR"""
        from pptx import Presentation

        text_parts: List[str] = []
        ocr_parts: List[str] = []

        prs = Presentation(file_path)
        for slide_num, slide in enumerate(prs.slides):
            for shape in slide.shapes:
                if hasattr(shape, 'text') and shape.text.strip():
                    text_parts.append(shape.text)

                # 图片shape执行OCR
                if shape.shape_type == 13:  # MSO_SHAPE_TYPE.PICTURE
                    try:
                        ocr_text = ocr_image_bytes(shape.image.blob)
                        if ocr_text:
                            ocr_parts.append(f"[第{slide_num + 1}页图片] {ocr_text}")
                    except Exception as e:
                        logger.warning(f"PPTX第{slide_num + 1}页图片提取失败: {e}")

        logger.info(f"PPTX解析成功: {file_path}, 幻灯片数: {len(prs.slides)}, OCR图片数: {len(ocr_parts)}")
        return '\n'.join(text_parts), '\n'.join(ocr_parts)

    def _parse_image(self, file_path: str):
        """独立图片：直接OCR"""
        ocr_text = ocr_image_file(file_path)
        logger.info(f"图片OCR完成: {file_path}, 提取{len(ocr_text)}字符")
        return '', ocr_text

    def _parse_txt(self, file_path: str):
        """纯文本直读"""
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read(), ''


# 全局解析器实例
_multimodal_parser = None


def get_multimodal_parser() -> MultimodalParser:
    """
    获取全局多模态解析器实例（单例模式）

    Returns:
        MultimodalParser实例
    """
    global _multimodal_parser
    if _multimodal_parser is None:
        _multimodal_parser = MultimodalParser()
    return _multimodal_parser
