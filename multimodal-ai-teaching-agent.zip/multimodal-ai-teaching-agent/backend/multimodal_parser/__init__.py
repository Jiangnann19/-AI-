"""
多模态解析模块（PDF/DOCX/PPTX/图片OCR）
"""

from .parser import MultimodalParser, get_multimodal_parser
from .ocr import ocr_image_bytes, ocr_image_file, is_ocr_available

__all__ = [
    'MultimodalParser', 'get_multimodal_parser',
    'ocr_image_bytes', 'ocr_image_file', 'is_ocr_available'
]
