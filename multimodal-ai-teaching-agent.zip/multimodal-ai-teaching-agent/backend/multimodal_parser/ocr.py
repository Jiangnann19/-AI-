"""
OCR文字识别模块（PaddleOCR封装）
PaddleOCR未安装时优雅降级：跳过OCR、记录日志，不阻塞文本入库
首次使用会自动下载中文识别模型，缓存在用户目录 ~/.paddlex
"""

import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

_ocr_available = None
_ocr_engine = None


def _get_ocr_engine():
    """懒加载PaddleOCR引擎（首次调用时初始化并下载模型）"""
    global _ocr_engine
    if _ocr_engine is None:
        from paddleocr import PaddleOCR
        _ocr_engine = PaddleOCR(
            lang='ch',
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=True,
        )
    return _ocr_engine


def is_ocr_available() -> bool:
    """
    探测PaddleOCR是否可用（首次探测会初始化引擎、下载模型）

    Returns:
        True表示可用
    """
    global _ocr_available
    if _ocr_available is not None:
        return _ocr_available

    try:
        logger.info("正在初始化PaddleOCR，首次运行需下载中文模型，请稍候...")
        _get_ocr_engine()
        _ocr_available = True
        logger.info("PaddleOCR可用")
    except Exception as e:
        _ocr_available = False
        logger.warning(f"PaddleOCR不可用，图片OCR将被跳过: {e}")

    return _ocr_available


def ocr_image_bytes(image_bytes: bytes) -> str:
    """
    对图片字节内容执行OCR识别

    Args:
        image_bytes: 图片二进制内容

    Returns:
        识别出的文字，失败或不可用返回空字符串
    """
    if not image_bytes:
        return ''

    if not is_ocr_available():
        return ''

    try:
        import cv2
        import numpy as np

        image = cv2.imdecode(np.frombuffer(image_bytes, dtype=np.uint8), cv2.IMREAD_COLOR)
        if image is None:
            logger.warning("图片解码失败，跳过OCR")
            return ''

        result = _get_ocr_engine().predict(input=image)

        lines = []
        for res in result or []:
            try:
                lines.extend(str(t) for t in res['rec_texts'])
            except Exception as e:
                logger.warning(f"解析OCR结果失败: {e}")

        text = '\n'.join(lines).strip()
        if text:
            logger.info(f"OCR识别成功，提取{len(text)}字符")
        return text
    except Exception as e:
        logger.warning(f"OCR识别失败，跳过该图片: {e}")
        return ''


def ocr_image_file(file_path: str) -> str:
    """
    对图片文件执行OCR识别

    Args:
        file_path: 图片文件路径

    Returns:
        识别出的文字
    """
    try:
        with open(file_path, 'rb') as f:
            return ocr_image_bytes(f.read())
    except Exception as e:
        logger.warning(f"读取图片失败 {file_path}: {e}")
        return ''
