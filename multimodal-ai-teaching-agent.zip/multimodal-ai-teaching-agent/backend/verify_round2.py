# -*- coding: utf-8 -*-
"""
遗留问题第二轮验证脚本

验证目标：
1. PPT预览图：render_ppt_slides能把pptx逐页渲染为PNG
2. 分块参数：向量库chunk_size=300/overlap=50，TCP docx切成3块
3. RAG溯源：prompt片段带【来源：】；课件最后一页/Word正文出现"参考：TCP三次握手教学素材.docx"
4. 端到端：/api/generate-course返回ppt_images，且引用非空时课件含参考标注

运行方式（项目依赖在Python3.11环境）：
    cd backend && D:\\leePython\\Python311\\python.exe verify_round2.py
"""

import os
import sys
import json

# python-pptx 0.6.21在py311下需先导入collections.abc
import collections.abc  # noqa: F401

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(BACKEND_DIR)
sys.path.insert(0, BACKEND_DIR)
sys.path.insert(0, os.path.join(BACKEND_DIR, 'app'))

PASS, FAIL = [], []

_FLASK_APP = None


def get_flask_app():
    """按文件路径加载backend/app.py（避免与backend/app/包目录撞名）"""
    global _FLASK_APP
    if _FLASK_APP is None:
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            'flask_app_main', os.path.join(BACKEND_DIR, 'app.py'))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _FLASK_APP = mod
    return _FLASK_APP


def check(name, ok, detail=''):
    (PASS if ok else FAIL).append(name)
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}  {detail}")


def verify_chunking():
    print("\n===== 1. 分块参数 =====")
    from rag.vector_store import get_vector_store
    vs = get_vector_store()
    check('向量库chunk_size=300', vs.chunk_size == 300, f"实际={vs.chunk_size}")
    check('向量库chunk_overlap=50', vs.chunk_overlap == 50, f"实际={vs.chunk_overlap}")

    from docx import Document
    doc = Document(os.path.join(BACKEND_DIR, 'uploads', 'TCP.docx'))
    text = '\n'.join(p.text for p in doc.paragraphs if p.text.strip())
    chunks = vs.chunk_text(text)
    check('TCP.docx按300/50分块', len(chunks) == 3,
          f"正文{len(text)}字符 -> {len(chunks)}块 " + str([len(c) for c in chunks]))
    print('  >> 预期块数：3块（809字符 ÷ 300/50）')


def verify_ppt_render():
    print("\n===== 2. PPT逐页渲染PNG =====")
    from app.utils.ppt_renderer import render_ppt_slides
    ppt_path = os.path.join(BACKEND_DIR, 'outputs', 'verify_tcp_multipage.pptx')
    rel_images = render_ppt_slides(ppt_path, os.path.join(BACKEND_DIR, 'outputs'))
    all_exist = bool(rel_images) and all(
        os.path.isfile(os.path.join(BACKEND_DIR, 'outputs', p)) for p in rel_images)
    check('渲染输出PNG列表非空', len(rel_images) > 0, f"{len(rel_images)}页")
    check('PNG文件均落盘存在', all_exist)
    if rel_images:
        print('  >> 示例URL: /api/outputs/' + rel_images[0].replace(os.sep, '/'))


def verify_citation():
    print("\n===== 3. RAG溯源标注 =====")
    # 3a. prompt片段头部带【来源：文件名】
    flask_app = get_flask_app()
    chunks = [{'content': 'TCP三次握手内容……', 'metadata': {'source': 'TCP三次握手教学素材.docx'}}]
    prompt = flask_app._build_course_generation_prompt({'course_title': 'TCP三次握手'}, chunks)
    check('prompt片段前带【来源：文件名】', '【来源：TCP三次握手教学素材.docx】' in prompt)
    check('system prompt含硬性标注要求', '硬性要求' in flask_app._COURSE_GENERATION_SYSTEM_PROMPT)

    # 3b. 兜底：PPT最后一页 + Word正文出现"参考：TCP三次握手教学素材.docx"
    with open(os.path.join(ROOT_DIR, 'chat_result2.json'), encoding='utf-8') as f:
        intent = json.load(f)['intent']
    instruction = dict(intent)
    instruction['course_title'] = 'TCP三次握手：连接建立的核心机制'
    instruction['citation_sources'] = ['TCP三次握手教学素材.docx']

    from app.generators.ppt_generator import get_ppt_generator
    from app.generators.word_generator import get_word_generator
    ppt_path = get_ppt_generator().generate(
        instruction, output_path=os.path.join(BACKEND_DIR, 'outputs', 'verify_citation.pptx'))
    word_path = get_word_generator().generate(
        instruction, output_path=os.path.join(BACKEND_DIR, 'outputs', 'verify_citation.docx'))

    from pptx import Presentation
    prs = Presentation(ppt_path)
    last_slide = prs.slides[-1]
    last_text = '\n'.join(sh.text_frame.text for sh in last_slide.shapes if sh.has_text_frame)
    check('PPT最后一页为"参考资料"', '参考资料' in last_text)
    check('PPT最后一页含"参考：TCP三次握手教学素材.docx"',
          '参考：TCP三次握手教学素材.docx' in last_text)

    from docx import Document
    word_text = '\n'.join(p.text for p in Document(word_path).paragraphs)
    check('Word正文含"参考：TCP三次握手教学素材.docx"',
          '参考：TCP三次握手教学素材.docx' in word_text)


def verify_e2e():
    print("\n===== 4. 端到端 /api/generate-course =====")
    flask_app = get_flask_app()
    llm = flask_app.get_llm_client()
    if not llm.use_mock:
        # 拦掉真实OpenAI大纲调用（走表单参数兜底分支），其余链路（RAG检索/生成/渲染）全真
        print('  >> 检测到真实OPENAI_API_KEY，已拦截LLM大纲调用（structured_completion返回None）')
        llm.structured_completion = lambda *a, **kw: None

    with open(os.path.join(ROOT_DIR, 'chat_result2.json'), encoding='utf-8') as f:
        intent = json.load(f)['intent']

    client = flask_app.app.test_client()
    resp = client.post('/api/generate-course',
                       data=json.dumps({'structured_requirement': intent}),
                       content_type='application/json')
    data = resp.get_json()
    check('接口返回success', data.get('success') is True)
    if not data.get('success'):
        print('  >>', data.get('msg') or data.get('error'))
        return

    images = data.get('ppt_images') or []
    check('响应含ppt_images且非空', len(images) > 0, f"{len(images)}页预览图")
    check('ppt_images为/api/outputs/ URL', all(u.startswith('/api/outputs/') for u in images))
    if images:
        img_resp = client.get(images[0])
        check('预览图URL可访问且为PNG',
              img_resp.status_code == 200 and img_resp.data[:4] == b'\x89PNG')

    sources = data.get('citation_sources') or []
    print(f'  >> citation_sources = {sources}')
    if sources:
        from pptx import Presentation
        prs = Presentation(data['ppt_path'])
        last_text = '\n'.join(sh.text_frame.text for sh in prs.slides[-1].shapes if sh.has_text_frame)
        check('e2e课件最后一页为参考资料页', '参考资料' in last_text and '参考：' in last_text)
        from docx import Document
        word_text = '\n'.join(p.text for p in Document(data['word_path']).paragraphs)
        check('e2e Word正文含参考标注', '参考：' in word_text)
    else:
        print('  >> 本次RAG未检索到来源（无引用则不加兜底页，属正常分支）')

    # 游戏预览路由
    g = client.get('/api/preview/game')
    check('/api/preview/game可内联访问', g.status_code == 200 and b'<html' in g.data.lower())


def verify_rebuild():
    print("\n===== 5. 重建索引接口 /api/knowledge/rebuild（隔离环境） =====")
    import shutil
    import tempfile

    flask_app = get_flask_app()

    # 隔离：临时向量库 + 临时uploads（仅放TCP.docx副本），不碰真实知识库
    tmp_dir = tempfile.mkdtemp(prefix='rebuild_test_')
    tmp_db = os.path.join(tmp_dir, 'chroma_db')
    tmp_uploads = os.path.join(tmp_dir, 'uploads')
    os.makedirs(tmp_uploads, exist_ok=True)
    shutil.copy(os.path.join(BACKEND_DIR, 'uploads', 'TCP.docx'), tmp_uploads)

    os.environ['CHROMA_PERSIST_DIR'] = tmp_db
    try:
        from rag.vector_store import ChromaVectorStore
        temp_store = ChromaVectorStore()

        orig_get_vs = flask_app.get_vector_store
        orig_upload_folder = flask_app.app.config['UPLOAD_FOLDER']
        flask_app.get_vector_store = lambda: temp_store
        flask_app.app.config['UPLOAD_FOLDER'] = tmp_uploads
        try:
            client = flask_app.app.test_client()
            resp = client.post('/api/knowledge/rebuild')
            data = resp.get_json()
            check('rebuild接口返回success', data.get('success') is True)
            rebuilt = {f['filename']: f['chunks'] for f in data.get('rebuilt_files', [])}
            check('TCP.docx重建后切成3块', rebuilt.get('TCP.docx') == 3,
                  f"实际={rebuilt}")
            check('重建后总数=3', data.get('total_chunks') == 3)
        finally:
            flask_app.get_vector_store = orig_get_vs
            flask_app.app.config['UPLOAD_FOLDER'] = orig_upload_folder
    finally:
        os.environ.pop('CHROMA_PERSIST_DIR', None)
        shutil.rmtree(tmp_dir, ignore_errors=True)


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    # 先加载app.py：它会按真实服务顺序加载根.env再backend/.env，
    # 保证向量库等单例锚定到正确的持久化目录
    get_flask_app()
    verify_chunking()
    verify_ppt_render()
    verify_citation()
    verify_e2e()
    verify_rebuild()

    print(f"\n===== 结果汇总：{len(PASS)} 通过, {len(FAIL)} 失败 =====")
    if FAIL:
        print('失败项:', FAIL)
        sys.exit(1)
    print('全部验证通过')


if __name__ == '__main__':
    main()
