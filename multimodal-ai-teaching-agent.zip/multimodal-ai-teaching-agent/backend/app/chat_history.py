"""
用户对话历史模块
- 与用户系统共用 backend/data/users.db，独立表 conversations / messages
- conversations: (id, user_id, title, created_at, updated_at)
- messages: (id, conversation_id, role, content, intent_json, created_at)
- 提供 REST 接口：
    GET    /api/conversations                      列出当前用户的会话
    POST   /api/conversations                      创建空会话（可指定标题）
    GET    /api/conversations/<id>                 获取会话元信息+全部消息
    PUT    /api/conversations/<id>                 重命名会话
    DELETE /api/conversations/<id>                 删除会话（级联消息）
- 同时提供 save_message 工具函数供 /api/chat 调用，避免重复样板
- 所有会话与当前登录用户绑定，跨用户隔离；删除/修改前校验属主
"""

import os
import json
import logging
from datetime import datetime

from flask import Blueprint, request, jsonify, g

from app.auth import _get_db, login_required, current_user

logger = logging.getLogger(__name__)

chat_history_bp = Blueprint('chat_history', __name__)

# 会话标题最大长度（超长自动截断）
TITLE_MAX_LEN = 40
# 单条消息内容最大长度，防止超大输入打满 SQLite
CONTENT_MAX_LEN = 20000


def _now():
    return datetime.now().isoformat(timespec='seconds')


def init_chat_history_db():
    """初始化对话历史表（应用启动时调用）"""
    conn = _get_db()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                conversation_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                intent_json TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
            )
            """
        )
        # 为常用查询加索引
        conn.execute('CREATE INDEX IF NOT EXISTS idx_conv_user ON conversations(user_id)')
        conn.execute('CREATE INDEX IF NOT EXISTS idx_msg_conv ON messages(conversation_id)')
        conn.commit()
        logger.info("对话历史表初始化完成")
    finally:
        conn.close()


def _truncate(text, max_len=TITLE_MAX_LEN):
    if not text:
        return ''
    text = text.strip()
    return text if len(text) <= max_len else text[:max_len] + '...'


def _conv_row(row):
    """把 conversations 行转为字典"""
    return {
        'id': row['id'],
        'user_id': row['user_id'],
        'title': row['title'],
        'created_at': row['created_at'],
        'updated_at': row['updated_at'],
    }


def _msg_row(row):
    """把 messages 行转为字典，解析 intent_json"""
    intent = None
    if row['intent_json']:
        try:
            intent = json.loads(row['intent_json'])
        except Exception:
            intent = None
    return {
        'id': row['id'],
        'conversation_id': row['conversation_id'],
        'role': row['role'],
        'content': row['content'],
        'intent': intent,
        'created_at': row['created_at'],
    }


def _get_owned_conversation(conn, conv_id, user_id):
    """取会话并校验属主，不属于该用户返回 None"""
    row = conn.execute(
        'SELECT * FROM conversations WHERE id = ? AND user_id = ?',
        (conv_id, user_id)
    ).fetchone()
    return row


def save_message(user_id, conversation_id, role, content, intent=None):
    """
    写入一条消息并刷新会话 updated_at；供 /api/chat 调用。
    - role: 'user' 或 'assistant'
    - content 超长时截断，保证写库不抛异常
    - 若 conversation_id 为空，则自动新建会话，标题用首条用户消息
    返回 (conversation_id, message_dict) 或 (None, None)
    """
    if role not in ('user', 'assistant'):
        return None, None
    if content is None:
        content = ''
    content = content[:CONTENT_MAX_LEN]

    conn = _get_db()
    try:
        # 无会话：以首条用户消息为标题新建一个会话
        if not conversation_id:
            title = _truncate(content if role == 'user' else '新对话', TITLE_MAX_LEN)
            now = _now()
            cur = conn.execute(
                'INSERT INTO conversations (user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?)',
                (user_id, title or '新对话', now, now)
            )
            conversation_id = cur.lastrowid
            conn.commit()

        # 校验属主，避免越权写入他人的会话
        row = _get_owned_conversation(conn, conversation_id, user_id)
        if not row:
            return None, None

        now = _now()
        intent_json = json.dumps(intent, ensure_ascii=False) if intent else None
        cur = conn.execute(
            'INSERT INTO messages (conversation_id, role, content, intent_json, created_at) VALUES (?, ?, ?, ?, ?)',
            (conversation_id, role, content, intent_json, now)
        )
        # 若是首条用户消息且会话标题还是默认值，更新为该消息截断
        if role == 'user' and (row['title'] in ('新对话', '') or row['title'].startswith('新对话')):
            new_title = _truncate(content, TITLE_MAX_LEN)
            if new_title:
                conn.execute(
                    'UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?',
                    (new_title, now, conversation_id)
                )
        else:
            conn.execute(
                'UPDATE conversations SET updated_at = ? WHERE id = ?',
                (now, conversation_id)
            )
        conn.commit()
        msg_id = cur.lastrowid
        msg = {
            'id': msg_id,
            'conversation_id': conversation_id,
            'role': role,
            'content': content,
            'intent': intent,
            'created_at': now,
        }
        return conversation_id, msg
    finally:
        conn.close()


@chat_history_bp.route('/api/conversations', methods=['GET'])
@login_required
def list_conversations():
    """列出当前用户的所有会话，按 updated_at 倒序"""
    user = current_user()
    conn = _get_db()
    try:
        rows = conn.execute(
            'SELECT * FROM conversations WHERE user_id = ? ORDER BY datetime(updated_at) DESC',
            (user['id'],)
        ).fetchall()
        # 附加每个会话的消息数与首条预览
        result = []
        for r in rows:
            item = _conv_row(r)
            cnt = conn.execute(
                'SELECT COUNT(*) AS c FROM messages WHERE conversation_id = ?',
                (r['id'],)
            ).fetchone()['c']
            item['message_count'] = cnt
            # 取首条用户消息作为预览
            preview_row = conn.execute(
                'SELECT content FROM messages WHERE conversation_id = ? ORDER BY id ASC LIMIT 1',
                (r['id'],)
            ).fetchone()
            item['preview'] = preview_row['content'][:80] if preview_row else ''
            result.append(item)
        return jsonify({'success': True, 'conversations': result})
    finally:
        conn.close()


@chat_history_bp.route('/api/conversations', methods=['POST'])
@login_required
def create_conversation():
    """新建空会话（可选自定义标题）"""
    user = current_user()
    data = request.get_json(silent=True) or {}
    title = _truncate(data.get('title') or '新对话', TITLE_MAX_LEN)
    now = _now()
    conn = _get_db()
    try:
        cur = conn.execute(
            'INSERT INTO conversations (user_id, title, created_at, updated_at) VALUES (?, ?, ?, ?)',
            (user['id'], title, now, now)
        )
        conn.commit()
        conv_id = cur.lastrowid
        return jsonify({
            'success': True,
            'conversation': {
                'id': conv_id,
                'user_id': user['id'],
                'title': title,
                'created_at': now,
                'updated_at': now,
                'message_count': 0,
                'preview': ''
            }
        })
    finally:
        conn.close()


@chat_history_bp.route('/api/conversations/<int:conv_id>', methods=['GET'])
@login_required
def get_conversation(conv_id):
    """取会话元信息 + 全部消息（按 id 升序）"""
    user = current_user()
    conn = _get_db()
    try:
        conv = _get_owned_conversation(conn, conv_id, user['id'])
        if not conv:
            return jsonify({'success': False, 'error': '会话不存在或无权访问'}), 404
        msg_rows = conn.execute(
            'SELECT * FROM messages WHERE conversation_id = ? ORDER BY id ASC',
            (conv_id,)
        ).fetchall()
        return jsonify({
            'success': True,
            'conversation': _conv_row(conv),
            'messages': [_msg_row(m) for m in msg_rows]
        })
    finally:
        conn.close()


@chat_history_bp.route('/api/conversations/<int:conv_id>', methods=['PUT'])
@login_required
def rename_conversation(conv_id):
    """重命名会话"""
    user = current_user()
    data = request.get_json(silent=True) or {}
    title = _truncate(data.get('title') or '', TITLE_MAX_LEN)
    if not title:
        return jsonify({'success': False, 'error': '标题不能为空'}), 400
    conn = _get_db()
    try:
        conv = _get_owned_conversation(conn, conv_id, user['id'])
        if not conv:
            return jsonify({'success': False, 'error': '会话不存在或无权访问'}), 404
        conn.execute(
            'UPDATE conversations SET title = ?, updated_at = ? WHERE id = ?',
            (title, _now(), conv_id)
        )
        conn.commit()
        return jsonify({'success': True, 'title': title})
    finally:
        conn.close()


@chat_history_bp.route('/api/conversations/<int:conv_id>', methods=['DELETE'])
@login_required
def delete_conversation(conv_id):
    """删除会话（同时删除其全部消息）"""
    user = current_user()
    conn = _get_db()
    try:
        conv = _get_owned_conversation(conn, conv_id, user['id'])
        if not conv:
            return jsonify({'success': False, 'error': '会话不存在或无权访问'}), 404
        conn.execute('DELETE FROM messages WHERE conversation_id = ?', (conv_id,))
        conn.execute('DELETE FROM conversations WHERE id = ?', (conv_id,))
        conn.commit()
        return jsonify({'success': True})
    finally:
        conn.close()
