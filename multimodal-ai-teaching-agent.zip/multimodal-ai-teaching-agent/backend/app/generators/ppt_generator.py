"""
PPTX课件自动生成引擎
根据融合指令自动生成完整的PPTX课件

视觉规范：
- 封面页：蓝紫渐变背景 + 白色大标题居中
- 内容页：浅蓝渐变背景 + 深蓝标题栏(白字) + 浅色卡片正文 + 深蓝页脚色条
- 主色深蓝 #1E3A8A/#2563EB，强调色橙 #F59E0B，正文纯黑 #000000
- TCP关键词(SYN/ACK/seq=x等)使用橙色高亮底色强调
- 互动答题面板单独成页(课堂互动练习)，全课件只出现一次
"""

import os
import re
import logging
from typing import Dict, List
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from pptx.dml.color import RGBColor
from pptx.oxml.ns import qn
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------- 统一配色体系 ----------
COLOR_DEEP_BLUE = RGBColor(0x1E, 0x3A, 0x8A)      # 主色深蓝（标题栏/页脚）
COLOR_PRIMARY_BLUE = RGBColor(0x25, 0x63, 0xEB)   # 主色亮蓝（小标题/流程）
COLOR_ACCENT_ORANGE = RGBColor(0xF5, 0x9E, 0x0B)  # 强调橙（重点标注）
COLOR_BLACK = RGBColor(0x00, 0x00, 0x00)          # 正文纯黑
COLOR_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
COLOR_BG_TOP = RGBColor(0xEF, 0xF6, 0xFF)         # 内容页背景渐变起（浅蓝）
COLOR_BG_BOTTOM = RGBColor(0xE0, 0xE7, 0xFF)      # 内容页背景渐变止（浅蓝紫）
COLOR_CARD_BORDER = RGBColor(0xBF, 0xDB, 0xFE)    # 卡片浅蓝描边
COLOR_COVER_TOP = RGBColor(0x1E, 0x3A, 0x8A)      # 封面渐变起（深蓝）
COLOR_COVER_BOTTOM = RGBColor(0x7C, 0x3A, 0xED)   # 封面渐变止（紫）
COLOR_QUIZ_BG = RGBColor(0xFE, 0xF3, 0xC7)        # 答题卡片浅橙底

# 需要视觉强调的TCP关键词（长词优先匹配）
KEYWORD_PATTERN = re.compile(
    r'(SYN\+ACK|SYN_SENT|SYN_RCVD|ESTABLISHED|LISTEN|CLOSED|ISN|SYN|ACK|FIN'
    r'|seq\s*=\s*[^\s，。；;,、）)]+|ack\s*=\s*[^\s，。；;,、）)]+|seq|ack)'
)

# 幻灯片尺寸（16:9）
SLIDE_W = 10.0
SLIDE_H = 5.625
FOOTER_H = 0.305


class PPTGenerator:
    """PPT课件生成器"""

    def __init__(self):
        """初始化PPT生成器"""
        self.slide_templates = {
            'cover': self._create_cover_slide,
            'directory': self._create_directory_slide,
            'knowledge': self._create_knowledge_slide,
            'case': self._create_case_slide,
            'interaction': self._create_interaction_slide,
            'quiz': self._create_quiz_slide,
            'summary': self._create_summary_slide,
            'ending': self._create_ending_slide,
            'references': self._create_references_slide,
            'tcp_handshake': self._create_tcp_handshake_slide
        }
        logger.info("PPT生成器初始化完成")

    def generate(self, fusion_instruction: Dict, output_path: str = None) -> str:
        """
        生成PPT课件

        Args:
            fusion_instruction: 融合后的课件生成指令
            output_path: 输出文件路径

        Returns:
            生成的PPT文件路径
        """
        # 检测用户是否要求只要1页
        course_title = fusion_instruction.get('course_title', '')
        special_requirements = fusion_instruction.get('special_requirements', '')
        single_page_mode = '只要1页' in special_requirements or '只要1页' in course_title or '只要一页' in special_requirements

        # 创建PPT对象
        prs = Presentation()

        # 设置幻灯片尺寸（16:9）
        prs.slide_width = Inches(SLIDE_W)
        prs.slide_height = Inches(SLIDE_H)

        # 如果是单页模式且是TCP相关课程，直接生成单页完整课件
        if single_page_mode and ('TCP' in course_title or 'tcp' in course_title.lower()):
            logger.info("检测到单页TCP课件要求，生成单页完整教学幻灯片")
            # 为前端预览设置template_type
            fusion_instruction['ppt_structure'] = [{
                'slide_type': 'tcp_handshake',
                'template_type': 'tcp_handshake',
                'title': course_title,
                'content': fusion_instruction.get('knowledge_points', ['TCP三次握手'])
            }]
            self._create_tcp_handshake_single_slide(prs, fusion_instruction)
        else:
            # 获取PPT结构
            ppt_structure = fusion_instruction.get('ppt_structure', [])

            if not ppt_structure:
                logger.warning("未提供PPT结构，使用默认结构")
                ppt_structure = self._get_default_structure(fusion_instruction)

            # 互动答题面板单独成页，且全课件只出现一次
            ppt_structure = self._ensure_single_quiz_slide(ppt_structure, fusion_instruction)
            fusion_instruction['ppt_structure'] = ppt_structure

            # 根据结构生成幻灯片，知识点页只展示本页知识点，不再嵌入答题面板
            for slide_info in ppt_structure:
                slide_type = slide_info.get('slide_type', 'knowledge')
                slide_title = slide_info.get('title', '')

                template_func = self.slide_templates.get(slide_type, self._create_knowledge_slide)
                logger.info(f"使用模板: {slide_type}, 幻灯片标题: {slide_title}")
                template_func(prs, slide_info, fusion_instruction)

            # 溯源兜底：凡使用了知识库参考资料，在课件最后追加一页"参考资料"
            self._append_references_slide(prs, fusion_instruction)

        # 确保输出目录存在
        if output_path is None:
            output_dir = os.path.join(os.path.dirname(__file__), '../../outputs')
            os.makedirs(output_dir, exist_ok=True)
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            course_title = fusion_instruction.get('course_title', '教学课件')
            # 清理文件名中的非法字符
            course_title = ''.join(c for c in course_title if c.isalnum() or c in (' ', '-', '_')).strip()
            output_path = os.path.join(output_dir, f"{course_title}_{timestamp}.pptx")

        # 保存PPT
        prs.save(output_path)
        logger.info(f"PPT课件生成成功: {output_path}")

        return output_path

    # ---------- 结构保障 ----------

    def _ensure_single_quiz_slide(self, ppt_structure: List[Dict], instruction: Dict) -> List[Dict]:
        """
        保证互动答题面板单独成页且只出现一次：
        1. 移除大纲中已有的答题页，避免重复
        2. 追加一页统一的"课堂互动练习"页（放在结尾页之前，即最后一页教学内容）

        Args:
            ppt_structure: 原始大纲
            instruction: 完整指令

        Returns:
            处理后的大纲
        """
        structure = [s for s in ppt_structure
                     if s.get('slide_type') != 'quiz' and s.get('template_type') != 'quiz']

        game = instruction.get('interactive_game') or {}
        quiz_info = {
            'slide_type': 'quiz',
            'template_type': 'quiz',
            'title': '课堂互动练习',
            'content': game.get('title', '互动答题')
        }

        if structure and structure[-1].get('slide_type') == 'ending':
            # 结尾页(感谢聆听)保持最后，答题页作为最后一页教学内容
            structure.insert(len(structure) - 1, quiz_info)
        else:
            structure.append(quiz_info)

        logger.info("互动答题面板已固定为单独一页：课堂互动练习")
        return structure

    # ---------- 通用绘制助手 ----------

    @staticmethod
    def _set_bg_gradient(slide, top_color: RGBColor, bottom_color: RGBColor, angle: float = 90):
        """设置幻灯片渐变背景"""
        fill = slide.background.fill
        fill.gradient()
        try:
            fill.gradient_angle = angle
        except Exception:
            pass
        stops = fill.gradient_stops
        stops[0].color.rgb = top_color
        stops[1].color.rgb = bottom_color

    @staticmethod
    def _add_run(paragraph, text: str, size: int, color: RGBColor, bold: bool = False):
        """添加一个统一样式的文本run"""
        run = paragraph.add_run()
        run.text = text
        run.font.size = Pt(size)
        run.font.color.rgb = color
        run.font.bold = bold
        return run

    def _write_highlighted_text(self, paragraph, text: str, size: int,
                                base_color: RGBColor = COLOR_BLACK, bold: bool = False):
        """
        向段落写入正文文本（默认纯黑），其中TCP关键词用橙色高亮底色+加粗强调
        """
        pos = 0
        for m in KEYWORD_PATTERN.finditer(text):
            if m.start() > pos:
                self._add_run(paragraph, text[pos:m.start()], size, base_color, bold)
            keyword_run = self._add_run(paragraph, m.group(0), size, base_color, True)
            # 注入橙色高亮底色，让关键词从纯黑正文中跳出来
            rPr = keyword_run._r.get_or_add_rPr()
            highlight = rPr.makeelement(qn('a:highlight'), {})
            color = rPr.makeelement(qn('a:srgbClr'), {'val': 'F59E0B'})
            highlight.append(color)
            rPr.append(highlight)
            pos = m.end()
        if pos < len(text):
            self._add_run(paragraph, text[pos:], size, base_color, bold)

    def _write_bullets(self, text_frame, lines: List, font_size: int = 16, space_after: int = 8):
        """写入项目符号列表，正文纯黑，关键词橙色高亮"""
        first = True
        for line in lines:
            line = str(line).strip()
            if not line:
                continue
            p = text_frame.paragraphs[0] if first else text_frame.add_paragraph()
            first = False
            self._add_run(p, '• ', font_size, COLOR_PRIMARY_BLUE, True)
            self._write_highlighted_text(p, line, font_size)
            p.space_after = Pt(space_after)

    def _add_title_bar(self, slide, title_text: str):
        """深蓝色标题栏 + 白色32pt粗体标题 + 橙色下沿装饰线"""
        bar = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), Inches(SLIDE_W), Inches(0.95)
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = COLOR_DEEP_BLUE
        bar.line.fill.background()

        strip = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(0.95), Inches(SLIDE_W), Inches(0.05)
        )
        strip.fill.solid()
        strip.fill.fore_color.rgb = COLOR_ACCENT_ORANGE
        strip.line.fill.background()

        title_box = slide.shapes.add_textbox(Inches(0.4), Inches(0.12), Inches(9.2), Inches(0.72))
        tf = title_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        self._add_run(p, title_text, 32, COLOR_WHITE, True)

    def _add_footer_bar(self, slide):
        """每页底部统一的深蓝色装饰色条页脚"""
        accent = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(SLIDE_H - FOOTER_H - 0.05),
            Inches(SLIDE_W), Inches(0.05)
        )
        accent.fill.solid()
        accent.fill.fore_color.rgb = COLOR_ACCENT_ORANGE
        accent.line.fill.background()

        bar = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(SLIDE_H - FOOTER_H),
            Inches(SLIDE_W), Inches(FOOTER_H)
        )
        bar.fill.solid()
        bar.fill.fore_color.rgb = COLOR_DEEP_BLUE
        bar.line.fill.background()

    def _add_card(self, slide, left, top, width, height,
                  fill_color: RGBColor = COLOR_WHITE,
                  border_color: RGBColor = COLOR_CARD_BORDER,
                  border_width: float = 1.5):
        """添加浅色圆角卡片"""
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = fill_color
        card.line.color.rgb = border_color
        card.line.width = Pt(border_width)
        return card

    def _add_section_title(self, slide, left, top, width, text: str):
        """卡片小标题：20pt粗体蓝色"""
        box = slide.shapes.add_textbox(left, top, width, Inches(0.4))
        tf = box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        self._add_run(p, text, 20, COLOR_PRIMARY_BLUE, True)

    @staticmethod
    def _content_lines(content) -> List[str]:
        """slide content字段统一转为行列表"""
        if isinstance(content, list):
            lines = []
            for item in content:
                lines.extend(str(item).split('\n'))
            return lines
        return str(content or '').split('\n')

    @staticmethod
    def _is_tcp_page(slide_info: Dict) -> bool:
        """判断本页是否TCP相关内容（决定右侧是否画握手流程图）"""
        text = str(slide_info.get('title', '')) + ' ' + str(slide_info.get('content', ''))
        return ('TCP' in text or 'tcp' in text.lower() or '握手' in text
                or 'SYN' in text or 'seq' in text)

    def _draw_handshake_diagram(self, slide, left, top, width, height):
        """绘制三次握手流程图卡片（SYN/ACK等关键词用彩色圆角标签）"""
        self._add_card(slide, left, top, width, height)

        # 卡片小标题
        title_box = slide.shapes.add_textbox(left + Inches(0.1), top + Inches(0.06),
                                             width - Inches(0.2), Inches(0.34))
        p = title_box.text_frame.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        self._add_run(p, '三次握手流程图', 20, COLOR_PRIMARY_BLUE, True)

        steps = [
            ('① 客户端 → 服务端', 'SYN, seq=x', COLOR_PRIMARY_BLUE),
            ('② 服务端 → 客户端', 'SYN+ACK, seq=y, ack=x+1', COLOR_ACCENT_ORANGE),
            ('③ 客户端 → 服务端', 'ACK, seq=x+1, ack=y+1', COLOR_PRIMARY_BLUE),
        ]

        step_top = top + Inches(0.5)
        for label, chip_text, chip_color in steps:
            # 步骤说明
            label_box = slide.shapes.add_textbox(left + Inches(0.2), step_top,
                                                 width - Inches(0.4), Inches(0.26))
            self._add_run(label_box.text_frame.paragraphs[0], label, 11, COLOR_BLACK, True)

            # 彩色圆角标签
            chip_w = width - Inches(0.9)
            chip = slide.shapes.add_shape(
                MSO_SHAPE.ROUNDED_RECTANGLE,
                left + Inches(0.45), step_top + Inches(0.28), chip_w, Inches(0.44)
            )
            chip.fill.solid()
            chip.fill.fore_color.rgb = chip_color
            chip.line.fill.background()
            chip_tf = chip.text_frame
            chip_tf.word_wrap = False
            chip_tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            chip_p = chip_tf.paragraphs[0]
            chip_p.alignment = PP_ALIGN.CENTER
            self._add_run(chip_p, chip_text, 10, COLOR_WHITE, True)

            step_top += Inches(0.9)

        # 状态变迁行
        state_box = slide.shapes.add_textbox(left + Inches(0.2), step_top + Inches(0.02),
                                             width - Inches(0.4), Inches(0.5))
        state_tf = state_box.text_frame
        state_tf.word_wrap = True
        self._write_highlighted_text(
            state_tf.paragraphs[0],
            '状态：CLOSED → SYN_SENT → ESTABLISHED（服务端经SYN_RCVD）',
            10
        )

    # ---------- 各类型幻灯片 ----------

    def _create_cover_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """封面页：蓝紫渐变背景 + 白色大标题居中"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_COVER_TOP, COLOR_COVER_BOTTOM, angle=45)

        # 主标题
        title_text = slide_info.get('title') or instruction.get('course_title', '教学课件')
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(1.5), Inches(8.4), Inches(1.4))
        tf = title_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        self._add_run(p, title_text, 40, COLOR_WHITE, True)

        # 标题下橙色装饰线
        line = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(4.0), Inches(3.0), Inches(2.0), Inches(0.06)
        )
        line.fill.solid()
        line.fill.fore_color.rgb = COLOR_ACCENT_ORANGE
        line.line.fill.background()

        # 副标题信息
        info_box = slide.shapes.add_textbox(Inches(1), Inches(3.3), Inches(8), Inches(0.5))
        info_p = info_box.text_frame.paragraphs[0]
        info_p.alignment = PP_ALIGN.CENTER
        self._add_run(
            info_p,
            f"授课教师：教师姓名  |  授课时长：{instruction.get('duration', '45分钟')}"
            f"  |  受众：{instruction.get('target_audience', '学生')}",
            16, COLOR_WHITE
        )

        # 日期
        date_box = slide.shapes.add_textbox(Inches(1), Inches(3.9), Inches(8), Inches(0.4))
        date_p = date_box.text_frame.paragraphs[0]
        date_p.alignment = PP_ALIGN.CENTER
        self._add_run(date_p, datetime.now().strftime('%Y-%m-%d'), 14, COLOR_WHITE)

        self._add_footer_bar(slide)

    def _create_directory_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """目录页：编号卡片式排版，每条一行，留白充足"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '课程目录'))

        # 目录条目：优先教学流程，其次本页内容，最后知识点
        items = []
        for flow in instruction.get('teaching_flow', []):
            stage = flow.get('stage', f'阶段{len(items) + 1}')
            content = flow.get('content', '')
            time = flow.get('time_allocation', '')
            items.append((stage, content, time))
        if not items:
            for line in self._content_lines(slide_info.get('content', '')):
                if line.strip():
                    items.append((line.strip(), '', ''))
        if not items:
            # 无教学流程时按知识点生成目录：拆出小标题(蓝色)与说明(纯黑)
            for point in instruction.get('knowledge_points', []):
                point = str(point)
                for sep in ('（', '(', '：', ':'):
                    if sep in point:
                        head, tail = point.split(sep, 1)
                        tail = tail.rstrip('）)')
                        items.append((head.strip(), f"{sep}{tail}{'）' if sep == '（' else ''}", ''))
                        break
                else:
                    items.append((point, '核心知识点', ''))
        items = items[:5]

        if not items:
            self._add_footer_bar(slide)
            return

        # 卡片式纵向排布
        area_top, area_bottom = 1.35, 5.15
        gap = 0.18
        card_h = min(0.72, (area_bottom - area_top - gap * (len(items) - 1)) / len(items))
        for i, (stage, content, time) in enumerate(items):
            y = area_top + i * (card_h + gap)
            self._add_card(slide, Inches(0.9), Inches(y), Inches(8.2), Inches(card_h))

            # 橙色编号圆点
            circle_d = 0.44
            circle = slide.shapes.add_shape(
                MSO_SHAPE.OVAL,
                Inches(1.15), Inches(y + (card_h - circle_d) / 2),
                Inches(circle_d), Inches(circle_d)
            )
            circle.fill.solid()
            circle.fill.fore_color.rgb = COLOR_ACCENT_ORANGE
            circle.line.fill.background()
            circle_tf = circle.text_frame
            circle_tf.word_wrap = False
            circle_tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            circle_p = circle_tf.paragraphs[0]
            circle_p.alignment = PP_ALIGN.CENTER
            self._add_run(circle_p, str(i + 1), 16, COLOR_WHITE, True)

            # 条目文字：标题蓝色粗体 + 说明纯黑，每条一行
            text_box = slide.shapes.add_textbox(
                Inches(1.8), Inches(y), Inches(7.1), Inches(card_h)
            )
            text_tf = text_box.text_frame
            text_tf.word_wrap = False
            text_tf.vertical_anchor = MSO_ANCHOR.MIDDLE
            text_p = text_tf.paragraphs[0]
            self._add_run(text_p, str(stage), 18, COLOR_PRIMARY_BLUE, True)
            detail = content or ''
            if time:
                detail = f"{detail}（{time}）" if detail else f"（{time}）"
            if detail:
                self._add_run(text_p, f"  {detail}", 16, COLOR_BLACK)

        self._add_footer_bar(slide)

    def _create_knowledge_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """知识正文页：浅蓝渐变背景 + 深蓝标题栏，左侧知识点卡片，右侧图文区"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '知识点'))

        # 左侧：本页知识点卡片
        self._add_card(slide, Inches(0.4), Inches(1.25), Inches(6.0), Inches(3.85))
        self._add_section_title(slide, Inches(0.65), Inches(1.38), Inches(5.5), '本页知识点')

        content_box = slide.shapes.add_textbox(Inches(0.65), Inches(1.9), Inches(5.5), Inches(3.0))
        content_tf = content_box.text_frame
        content_tf.word_wrap = True
        lines = self._content_lines(slide_info.get('content', ''))
        self._write_bullets(content_tf, lines, font_size=16, space_after=8)

        # 右侧：TCP页面画握手流程图，其余页面给学习要点提示卡
        if self._is_tcp_page(slide_info):
            self._draw_handshake_diagram(slide, Inches(6.6), Inches(1.25), Inches(3.0), Inches(3.85))
        else:
            self._add_card(slide, Inches(6.6), Inches(1.25), Inches(3.0), Inches(3.85))
            self._add_section_title(slide, Inches(6.8), Inches(1.38), Inches(2.6), '学习要点')
            tip_box = slide.shapes.add_textbox(Inches(6.8), Inches(1.9), Inches(2.6), Inches(3.0))
            tip_tf = tip_box.text_frame
            tip_tf.word_wrap = True
            tips = instruction.get('key_points') or ['理解本页核心概念', '结合案例加深记忆']
            first = True
            for tip in tips[:4]:
                p = tip_tf.paragraphs[0] if first else tip_tf.add_paragraph()
                first = False
                self._add_run(p, '★ ', 14, COLOR_ACCENT_ORANGE, True)
                self._write_highlighted_text(p, str(tip), 14)
                p.space_after = Pt(8)

        self._add_footer_bar(slide)

    def _create_case_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """案例页：内容卡片 + 思考问题强调卡片"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '案例分析'))

        # 案例内容卡片
        self._add_card(slide, Inches(0.4), Inches(1.25), Inches(9.2), Inches(2.5))
        self._add_section_title(slide, Inches(0.65), Inches(1.38), Inches(8.7), '案例内容')
        content_box = slide.shapes.add_textbox(Inches(0.65), Inches(1.9), Inches(8.7), Inches(1.7))
        content_tf = content_box.text_frame
        content_tf.word_wrap = True
        lines = self._content_lines(slide_info.get('content', '案例内容待补充'))
        self._write_bullets(content_tf, lines, font_size=16, space_after=6)

        # 思考问题强调卡片（橙色描边浅橙底）
        self._add_card(slide, Inches(0.4), Inches(3.95), Inches(9.2), Inches(1.15),
                       fill_color=COLOR_QUIZ_BG, border_color=COLOR_ACCENT_ORANGE,
                       border_width=2.0)
        q_title = slide.shapes.add_textbox(Inches(0.65), Inches(4.05), Inches(8.7), Inches(0.35))
        self._add_run(q_title.text_frame.paragraphs[0], '思考问题', 16, COLOR_PRIMARY_BLUE, True)

        questions = instruction.get('classroom_questions') or []
        q_text = questions[0] if questions else '请结合本页案例，思考其中体现的核心原理'
        q_box = slide.shapes.add_textbox(Inches(0.65), Inches(4.45), Inches(8.7), Inches(0.55))
        q_tf = q_box.text_frame
        q_tf.word_wrap = True
        self._write_highlighted_text(q_tf.paragraphs[0], str(q_text), 14)

        self._add_footer_bar(slide)

    def _create_interaction_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """课堂互动页：活动卡片 + 橙色提示条（答题面板不在此页，见课堂互动练习页）"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '课堂互动'))

        # 互动活动卡片
        self._add_card(slide, Inches(0.4), Inches(1.25), Inches(9.2), Inches(2.9))
        self._add_section_title(slide, Inches(0.65), Inches(1.38), Inches(8.7), '互动活动')
        content_box = slide.shapes.add_textbox(Inches(0.65), Inches(1.9), Inches(8.7), Inches(2.1))
        content_tf = content_box.text_frame
        content_tf.word_wrap = True

        activities = instruction.get('classroom_activities', [])
        if activities and isinstance(activities[0], dict):
            lines = [f"{act.get('activity', '')}：{act.get('description', '')}" for act in activities]
        elif activities:
            lines = [str(act) for act in activities]
        else:
            lines = self._content_lines(slide_info.get('content', '互动活动内容'))
        self._write_bullets(content_tf, lines, font_size=16, space_after=8)

        # 橙色提示条
        hint = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE, Inches(0.4), Inches(4.35), Inches(9.2), Inches(0.65)
        )
        hint.fill.solid()
        hint.fill.fore_color.rgb = COLOR_ACCENT_ORANGE
        hint.line.fill.background()
        hint_tf = hint.text_frame
        hint_tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        hint_p = hint_tf.paragraphs[0]
        hint_p.alignment = PP_ALIGN.CENTER
        self._add_run(hint_p, '请同学们积极参与讨论 / 回答问题', 16, COLOR_WHITE, True)

        self._add_footer_bar(slide)

    def _create_quiz_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """课堂互动练习页：互动答题面板单独成页，全课件仅此一页"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '课堂互动练习'))

        # 答题游戏标题（小标题，20pt粗体蓝色）
        game = instruction.get('interactive_game') or {}
        game_title = game.get('title') or slide_info.get('content') or '互动答题'
        game_box = slide.shapes.add_textbox(Inches(0.4), Inches(1.12), Inches(9.2), Inches(0.42))
        game_p = game_box.text_frame.paragraphs[0]
        game_p.alignment = PP_ALIGN.CENTER
        self._add_run(game_p, str(game_title), 20, COLOR_PRIMARY_BLUE, True)

        # 提示语
        note_box = slide.shapes.add_textbox(Inches(0.4), Inches(1.56), Inches(9.2), Inches(0.3))
        note_p = note_box.text_frame.paragraphs[0]
        note_p.alignment = PP_ALIGN.CENTER
        self._add_run(note_p, '配套互动答题游戏已生成独立HTML文件，可下载后课堂使用', 12, COLOR_BLACK)

        # 答题面板卡片（浅橙底 + 橙色描边）
        self._add_card(slide, Inches(0.6), Inches(1.95), Inches(8.8), Inches(3.15),
                       fill_color=COLOR_QUIZ_BG, border_color=COLOR_ACCENT_ORANGE,
                       border_width=2.5)

        questions = self._get_quiz_questions(instruction)
        top0 = 2.12
        step = min(1.35, (5.0 - top0) / max(len(questions), 1))
        for i, q in enumerate(questions):
            y = top0 + i * step
            # 题干
            q_box = slide.shapes.add_textbox(Inches(0.85), Inches(y), Inches(8.3), Inches(0.4))
            q_tf = q_box.text_frame
            q_tf.word_wrap = True
            q_p = q_tf.paragraphs[0]
            self._add_run(q_p, f"第{i + 1}题：", 14, COLOR_BLACK, True)
            self._write_highlighted_text(q_p, q['question'], 14, bold=True)

            # 选项
            if q.get('options'):
                o_box = slide.shapes.add_textbox(Inches(1.0), Inches(y + 0.4), Inches(8.1), Inches(0.3))
                o_tf = o_box.text_frame
                o_tf.word_wrap = True
                self._write_highlighted_text(o_tf.paragraphs[0], q['options'], 12)

            # 答案（橙色加粗强调）
            if q.get('answer'):
                a_box = slide.shapes.add_textbox(Inches(1.0), Inches(y + 0.72), Inches(8.1), Inches(0.3))
                a_p = a_box.text_frame.paragraphs[0]
                self._add_run(a_p, f"答案：{q['answer']}", 12, COLOR_ACCENT_ORANGE, True)

        self._add_footer_bar(slide)

    @staticmethod
    def _get_quiz_questions(instruction: Dict) -> List[Dict]:
        """组装答题面板题目：TCP课程用序号挑战题，其余课程用课堂提问"""
        course_text = (str(instruction.get('course_title', '')) + ' '
                       + ' '.join(str(p) for p in (instruction.get('knowledge_points') or [])))
        if 'TCP' in course_text or 'tcp' in course_text.lower() or '握手' in course_text:
            return [
                {
                    'question': 'TCP第一次握手发送什么报文？',
                    'options': 'A. SYN    B. SYN+ACK    C. ACK    D. FIN',
                    'answer': 'A'
                },
                {
                    'question': '客户端发送的seq=100，服务端回复的ack是多少？',
                    'options': 'A. 100    B. 101    C. 99    D. 102',
                    'answer': 'B'
                }
            ]

        questions = instruction.get('classroom_questions') or []
        result = [{'question': str(q), 'options': '', 'answer': ''} for q in questions[:3]]
        if not result:
            result = [{'question': '请回顾本课核心知识点，小组内互相提问并作答',
                       'options': '', 'answer': ''}]
        return result

    def _create_summary_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """总结页：重点/难点双卡片"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '本课重点总结'))

        # 重点卡片
        self._add_card(slide, Inches(0.4), Inches(1.25), Inches(4.5), Inches(3.85))
        self._add_section_title(slide, Inches(0.6), Inches(1.38), Inches(4.1), '教学重点')
        key_box = slide.shapes.add_textbox(Inches(0.6), Inches(1.9), Inches(4.1), Inches(3.0))
        key_tf = key_box.text_frame
        key_tf.word_wrap = True
        first = True
        for point in instruction.get('key_points', []):
            p = key_tf.paragraphs[0] if first else key_tf.add_paragraph()
            first = False
            self._add_run(p, '★ ', 16, COLOR_ACCENT_ORANGE, True)
            self._write_highlighted_text(p, str(point), 16)
            p.space_after = Pt(10)

        # 难点卡片
        self._add_card(slide, Inches(5.1), Inches(1.25), Inches(4.5), Inches(3.85))
        self._add_section_title(slide, Inches(5.3), Inches(1.38), Inches(4.1), '教学难点')
        diff_box = slide.shapes.add_textbox(Inches(5.3), Inches(1.9), Inches(4.1), Inches(3.0))
        diff_tf = diff_box.text_frame
        diff_tf.word_wrap = True
        first = True
        for point in instruction.get('difficult_points', []):
            p = diff_tf.paragraphs[0] if first else diff_tf.add_paragraph()
            first = False
            self._add_run(p, '▲ ', 14, COLOR_ACCENT_ORANGE, True)
            self._write_highlighted_text(p, str(point), 14)
            p.space_after = Pt(8)

        self._add_footer_bar(slide)

    def _create_ending_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """结尾页：蓝紫渐变背景 + 白色致谢语"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_COVER_TOP, COLOR_COVER_BOTTOM, angle=45)

        # 感谢语
        thank_box = slide.shapes.add_textbox(Inches(2), Inches(1.9), Inches(6), Inches(1.2))
        thank_p = thank_box.text_frame.paragraphs[0]
        thank_p.alignment = PP_ALIGN.CENTER
        self._add_run(thank_p, '感谢聆听', 44, COLOR_WHITE, True)

        # 作业提示
        homework = instruction.get('homework', '完成课后练习')
        homework_box = slide.shapes.add_textbox(Inches(1), Inches(3.4), Inches(8), Inches(1))
        homework_tf = homework_box.text_frame
        homework_tf.word_wrap = True
        homework_p = homework_tf.paragraphs[0]
        homework_p.alignment = PP_ALIGN.CENTER
        self._add_run(homework_p, f"课后作业：{homework}", 18, COLOR_WHITE)

        self._add_footer_bar(slide)

    def _create_tcp_handshake_single_slide(self, prs: Presentation, instruction: Dict):
        """
        创建TCP三次握手单页完整教学幻灯片（左右分栏布局）
        仅用于用户明确要求"只要1页"的场景：整份课件只有这一页，
        因此右侧答题面板在全课件中仍只出现一次
        """
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, instruction.get('course_title', 'TCP三次握手：连接建立的核心机制'))

        # 副标题
        subtitle_box = slide.shapes.add_textbox(Inches(0.2), Inches(1.05), Inches(9.6), Inches(0.35))
        subtitle_p = subtitle_box.text_frame.paragraphs[0]
        subtitle_p.alignment = PP_ALIGN.CENTER
        self._add_run(subtitle_p, '理解连接建立过程、seq与ack规则，以及为什么需要三次握手',
                      14, COLOR_PRIMARY_BLUE, True)

        # 左侧：知识点讲解
        self._add_section_title(slide, Inches(0.2), Inches(1.45), Inches(5.5), '知识点讲解')

        self._add_card(slide, Inches(0.2), Inches(1.95), Inches(5.5), Inches(1.55))
        flow_title = slide.shapes.add_textbox(Inches(0.35), Inches(2.03), Inches(5.2), Inches(0.3))
        self._add_run(flow_title.text_frame.paragraphs[0], '三次握手流程', 14, COLOR_PRIMARY_BLUE, True)
        flow_content = slide.shapes.add_textbox(Inches(0.35), Inches(2.38), Inches(5.2), Inches(1.05))
        flow_tf = flow_content.text_frame
        flow_tf.word_wrap = True
        for i, line in enumerate(['1. 客户端发送SYN，请求建立连接',
                                  '2. 服务端回复SYN+ACK，确认并请求',
                                  '3. 客户端回复ACK，确认连接建立']):
            p = flow_tf.paragraphs[0] if i == 0 else flow_tf.add_paragraph()
            self._write_highlighted_text(p, line, 12)
            p.space_after = Pt(4)

        self._add_card(slide, Inches(0.2), Inches(3.6), Inches(5.5), Inches(1.4))
        formula_title = slide.shapes.add_textbox(Inches(0.35), Inches(3.68), Inches(5.2), Inches(0.3))
        self._add_run(formula_title.text_frame.paragraphs[0], 'seq与ack计算规则', 14, COLOR_PRIMARY_BLUE, True)
        formula_content = slide.shapes.add_textbox(Inches(0.35), Inches(4.03), Inches(5.2), Inches(0.9))
        formula_tf = formula_content.text_frame
        formula_tf.word_wrap = True
        for i, line in enumerate(['seq：发送方序号 | ack = 对方seq + 1',
                                  '示例：seq=x → ack=x+1']):
            p = formula_tf.paragraphs[0] if i == 0 else formula_tf.add_paragraph()
            self._write_highlighted_text(p, line, 12)
            p.space_after = Pt(4)

        # 右侧：互动答题模块（单页模式下全课件仅此一页含答题面板）
        right_title = slide.shapes.add_textbox(Inches(6.0), Inches(1.45), Inches(3.8), Inches(0.4))
        right_p = right_title.text_frame.paragraphs[0]
        right_p.alignment = PP_ALIGN.CENTER
        game = instruction.get('interactive_game') or {}
        self._add_run(right_p, game.get('title', 'TCP握手序号大挑战'), 20, COLOR_PRIMARY_BLUE, True)

        game_note = slide.shapes.add_textbox(Inches(6.0), Inches(1.9), Inches(3.8), Inches(0.3))
        note_p = game_note.text_frame.paragraphs[0]
        note_p.alignment = PP_ALIGN.CENTER
        self._add_run(note_p, '互动答题游戏已生成独立HTML文件', 10, COLOR_BLACK)

        self._add_card(slide, Inches(6.0), Inches(2.3), Inches(3.8), Inches(2.7),
                       fill_color=COLOR_QUIZ_BG, border_color=COLOR_ACCENT_ORANGE,
                       border_width=2.5)

        questions = self._get_quiz_questions(instruction)[:2]
        for i, q in enumerate(questions):
            y = 2.45 + i * 1.3
            q_box = slide.shapes.add_textbox(Inches(6.2), Inches(y), Inches(3.4), Inches(0.55))
            q_tf = q_box.text_frame
            q_tf.word_wrap = True
            q_p = q_tf.paragraphs[0]
            self._add_run(q_p, f"第{i + 1}题：", 11, COLOR_BLACK, True)
            self._write_highlighted_text(q_p, q['question'], 11, bold=True)

            if q.get('options'):
                o_box = slide.shapes.add_textbox(Inches(6.2), Inches(y + 0.55), Inches(3.4), Inches(0.3))
                self._write_highlighted_text(o_box.text_frame.paragraphs[0], q['options'], 10)

            if q.get('answer'):
                a_box = slide.shapes.add_textbox(Inches(6.2), Inches(y + 0.9), Inches(3.4), Inches(0.3))
                self._add_run(a_box.text_frame.paragraphs[0], f"答案：{q['answer']}",
                              10, COLOR_ACCENT_ORANGE, True)

        # 底部总结条（页脚色条之上）
        summary_box = slide.shapes.add_textbox(Inches(0.2), Inches(5.02), Inches(9.6), Inches(0.28))
        summary_p = summary_box.text_frame.paragraphs[0]
        summary_p.alignment = PP_ALIGN.CENTER
        self._add_run(summary_p, '三次握手的本质：通过双方确认，建立可靠连接，同时协调初始序号。',
                      12, COLOR_DEEP_BLUE, True)

        self._add_footer_bar(slide)

    def _create_tcp_handshake_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """
        TCP知识页（多页模式）：只展示本页知识点，右侧为握手流程图，
        不再嵌入互动答题面板（答题面板统一在"课堂互动练习"页）
        """
        self._create_knowledge_slide(prs, slide_info, instruction)

    def _append_references_slide(self, prs: Presentation, instruction: Dict):
        """
        溯源兜底：凡使用了知识库参考资料（citation_sources非空），
        在课件最后追加一页"参考资料"，列出全部来源文档名
        """
        sources = instruction.get('citation_sources') or []
        if not sources:
            return

        refs_info = {
            'slide_type': 'references',
            'template_type': 'references',
            'title': '参考资料',
            'content': '\n'.join(f'参考：{name}' for name in sources)
        }
        instruction.setdefault('ppt_structure', []).append(refs_info)
        self._create_references_slide(prs, refs_info, instruction)
        logger.info(f"已在课件最后追加参考资料页: {sources}")

    def _create_references_slide(self, prs: Presentation, slide_info: Dict, instruction: Dict):
        """参考资料页：列出课件引用到的知识库文档"""
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self._set_bg_gradient(slide, COLOR_BG_TOP, COLOR_BG_BOTTOM)
        self._add_title_bar(slide, slide_info.get('title', '参考资料'))

        sources = instruction.get('citation_sources') or []
        lines = [f'参考：{name}' for name in sources]
        if not lines:
            lines = self._content_lines(slide_info.get('content', ''))

        self._add_card(slide, Inches(0.6), Inches(1.4), Inches(8.8), Inches(3.5))
        self._add_section_title(slide, Inches(0.85), Inches(1.55), Inches(8.3), '本课内容参考以下来源')

        content_box = slide.shapes.add_textbox(Inches(0.85), Inches(2.1), Inches(8.3), Inches(2.6))
        content_tf = content_box.text_frame
        content_tf.word_wrap = True
        self._write_bullets(content_tf, lines, font_size=16, space_after=10)

        self._add_footer_bar(slide)

    def _get_default_structure(self, instruction: Dict) -> List[Dict]:
        """
        获取默认PPT结构

        Args:
            instruction: 融合指令

        Returns:
            默认幻灯片结构列表
        """
        course_title = instruction.get('course_title', '教学课件')
        knowledge_points = instruction.get('knowledge_points', [])

        structure = [
            {'slide_type': 'cover', 'title': course_title},
            {'slide_type': 'directory', 'title': '课程目录'},
        ]

        # 添加知识点幻灯片
        for i, point in enumerate(knowledge_points):
            structure.append({
                'slide_type': 'knowledge',
                'title': f'知识点{i+1}',
                'content': point
            })

        # 添加案例和互动
        structure.append({'slide_type': 'case', 'title': '案例分析', 'content': '相关案例'})
        structure.append({'slide_type': 'interaction', 'title': '课堂互动', 'content': '互动活动'})
        structure.append({'slide_type': 'summary', 'title': '重点总结'})
        structure.append({'slide_type': 'ending', 'title': '课程结束'})

        return structure


# 全局PPT生成器实例
_ppt_generator = None


def get_ppt_generator() -> PPTGenerator:
    """
    获取全局PPT生成器实例（单例模式）

    Returns:
        PPTGenerator实例
    """
    global _ppt_generator
    if _ppt_generator is None:
        _ppt_generator = PPTGenerator()
    return _ppt_generator
