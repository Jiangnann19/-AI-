"""
PPT逐页渲染为PNG图片

渲染链路（按优先级）：
1. LibreOffice(soffice)：pptx -> pdf -> 逐页png（pymupdf）
2. Windows且装有PowerPoint：COM导出整份PNG
两者都不可用时返回空列表，由前端展示"请下载PPTX后查看"提示
"""

import os
import re
import shutil
import logging
import subprocess

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def _find_soffice():
    """定位LibreOffice可执行文件"""
    soffice = shutil.which('soffice') or shutil.which('libreoffice')
    if soffice:
        return soffice
    for candidate in (
        r'C:\Program Files\LibreOffice\program\soffice.exe',
        r'C:\Program Files (x86)\LibreOffice\program\soffice.exe',
        '/usr/bin/soffice',
        '/usr/local/bin/soffice',
        '/Applications/LibreOffice.app/Contents/MacOS/soffice',
    ):
        if os.path.exists(candidate):
            return candidate
    return None


def _pdf_to_pngs(pdf_path: str, out_dir: str) -> list:
    """用pymupdf把PDF逐页渲染为PNG"""
    import fitz  # pymupdf

    images = []
    doc = fitz.open(pdf_path)
    try:
        for i, page in enumerate(doc, 1):
            pix = page.get_pixmap(matrix=fitz.Matrix(1.6, 1.6))
            img_path = os.path.join(out_dir, f'slide_{i}.png')
            pix.save(img_path)
            images.append(img_path)
    finally:
        doc.close()
    return images


def _render_with_libreoffice(ppt_path: str, out_dir: str) -> list:
    """LibreOffice链路：pptx -> pdf -> png"""
    soffice = _find_soffice()
    if not soffice:
        logger.info("未检测到LibreOffice，跳过soffice渲染链路")
        return []

    try:
        result = subprocess.run(
            [soffice, '--headless', '--convert-to', 'pdf', '--outdir', out_dir, ppt_path],
            capture_output=True, timeout=180
        )
        pdf_path = os.path.join(out_dir, os.path.splitext(os.path.basename(ppt_path))[0] + '.pdf')
        if result.returncode != 0 or not os.path.exists(pdf_path):
            logger.warning(f"LibreOffice转换PDF失败: {result.stderr.decode('utf-8', 'ignore')[:200]}")
            return []

        images = _pdf_to_pngs(pdf_path, out_dir)
        try:
            os.remove(pdf_path)
        except OSError:
            pass
        logger.info(f"LibreOffice链路渲染完成: {len(images)}页")
        return images
    except Exception as e:
        logger.error(f"LibreOffice渲染链路失败: {e}")
        return []


def _render_with_powerpoint(ppt_path: str, out_dir: str) -> list:
    """Windows PowerPoint COM链路：整份导出PNG（文件名形如 幻灯片1.PNG）"""
    if os.name != 'nt':
        return []

    ps_script = (
        "$ppt = New-Object -ComObject PowerPoint.Application; "
        f"$pres = $ppt.Presentations.Open('{ppt_path}', $true, $false, $false); "
        f"$pres.SaveAs('{out_dir}', 18); "
        "$pres.Close(); $ppt.Quit()"
    )
    try:
        result = subprocess.run(
            ['powershell.exe', '-NoProfile', '-Command', ps_script],
            capture_output=True, timeout=180
        )
        if result.returncode != 0:
            logger.warning(f"PowerPoint导出失败: {result.stderr.decode('utf-8', 'ignore')[:200]}")
            return []

        # PowerPoint导出的文件名为 幻灯片N.PNG，统一改名为 slide_N.png 便于排序与引用
        images = []
        for name in os.listdir(out_dir):
            if not name.lower().endswith('.png'):
                continue
            f = os.path.join(out_dir, name)
            m = re.search(r'(\d+)', name)
            if not m:
                continue
            target = os.path.join(out_dir, f'slide_{int(m.group(1))}.png')
            if os.path.normcase(os.path.abspath(f)) != os.path.normcase(os.path.abspath(target)):
                if os.path.exists(target):
                    os.remove(target)
                os.rename(f, target)
            images.append(target)

        # 按页码数字排序并去重
        images = sorted(set(images),
                        key=lambda p: int(re.search(r'(\d+)', os.path.basename(p)).group(1)))
        logger.info(f"PowerPoint链路渲染完成: {len(images)}页")
        return images
    except Exception as e:
        logger.error(f"PowerPoint渲染链路失败: {e}")
        return []


def render_ppt_slides(ppt_path: str, output_root: str) -> list:
    """
    把PPT每页渲染为PNG

    Args:
        ppt_path: pptx文件路径
        output_root: 输出根目录（在其下建 <课件名>_slides/ 子目录）

    Returns:
        PNG文件的相对路径列表（相对output_root，用于拼URL）；渲染失败返回[]
    """
    ppt_path = os.path.abspath(ppt_path)
    if not os.path.exists(ppt_path):
        logger.error(f"待渲染PPT不存在: {ppt_path}")
        return []

    stem = re.sub(r'[\\/:*?"<>|\s]+', '_', os.path.splitext(os.path.basename(ppt_path))[0])
    out_dir = os.path.join(output_root, stem + '_slides')
    os.makedirs(out_dir, exist_ok=True)

    # 清理旧图，避免与新页数不一致
    for old_name in os.listdir(out_dir):
        if old_name.lower().endswith('.png'):
            try:
                os.remove(os.path.join(out_dir, old_name))
            except OSError:
                pass

    images = _render_with_libreoffice(ppt_path, out_dir)
    if not images:
        images = _render_with_powerpoint(ppt_path, out_dir)

    if not images:
        logger.warning("PPT预览图渲染链路均不可用，前端将提示下载查看")
        return []

    return [os.path.relpath(p, output_root) for p in images]
