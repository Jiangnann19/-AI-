"""
教学意图理解模块
使用大模型结构化解析教师的对话意图
"""

import json
import logging
import re
from typing import Dict, List, Optional
from .llm_client import get_llm_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IntentAnalyzer:
    """教学意图分析器"""
    
    def __init__(self):
        """初始化意图分析器"""
        self.llm_client = get_llm_client()
        self.system_prompt = """你是大学计算机网络专业教学设计专家。你的任务不是简单摘抄原文填表，而是深度解析用户教学需求，进行教学设计推理。

规则：
1. 教学目标：拆分为【知识目标、能力目标、素养目标】三层，不要直接复制用户一句话
2. 受众分析：针对大学一年级学生，预判前置知识、学生容易踩的认知误区
3. 重难点：区分【教学重点：必须掌握的核心知识】、【教学难点：学生容易混淆、难以理解的内容】，并简单解释难点成因
4. 自动生成适配本知识点的课堂提问、简短课堂小活动。

输出必须严格遵守给定JSON结构，字段名称保持不变。
禁止直接原样复制用户输入，必须做教学层面的加工、拆解、推理。"""
    
    def analyze_requirement_completeness(self, user_input: str, conversation_history: List[Dict] = None, rag_context: str = None) -> Dict:
        """
        分析教学需求并生成结构化课件需求（已移除10项字段强制校验，直接弹出确认）
        
        Args:
            user_input: 用户输入文本
            conversation_history: 对话历史
            rag_context: 外部传入的RAG上下文
            
        Returns:
            包含结构化需求及确认信息的字典
        """
        # 先判断是否是课件需求
        is_course_demand = self._detect_course_demand(user_input, conversation_history)
        
        if not is_course_demand:
            # 不是课件需求，正常对话
            return {
                "is_course_demand": False,
                "is_complete": False,
                "missing_fields": [],
                "structured_requirement": {},
                "need_user_confirm": False,
                "confirm_summary_text": ""
            }
        
        # 是课件需求：先本地解析用户输入中的结构化字段，确认弹窗必须展示用户原文
        parsed_fields = self._parse_structured_requirement(user_input)

        # 调用analyze方法获取LLM结构化意图（用于补全用户未写的课堂活动、提问等字段）
        logger.info("检测到课件需求，直接生成结构化需求")
        llm_intent = self.analyze(user_input, conversation_history, rag_context)
        if not isinstance(llm_intent, dict) or llm_intent.get('error'):
            logger.warning(f"LLM意图分析不可用，确认弹窗仅使用本地解析结果: "
                           f"{llm_intent.get('error') if isinstance(llm_intent, dict) else llm_intent}")
            llm_intent = {}

        # 合并：用户原文优先，LLM补全其余字段
        intent = self._merge_parsed_requirement(llm_intent, parsed_fields)

        # 直接弹出确认弹窗，不再校验10项字段
        confirm_summary = self._generate_confirm_summary(intent)
        logger.info(f"教学需求已生成，弹出确认弹窗")

        return {
            "is_course_demand": True,
            "is_complete": True,
            "missing_fields": [],
            "structured_requirement": intent,
            "need_user_confirm": True,
            "confirm_summary_text": confirm_summary
        }

    # 结构化需求文本中字段标签与intent字段的映射
    _STRUCT_FIELD_LABELS = {
        'knowledge_objective': ['知识目标'],
        'ability_objective': ['能力目标'],
        'quality_objective': ['素养目标'],
        'duration': ['授课时长', '课时'],
        'target_grade': ['受众年级', '目标受众', '授课对象', '受众'],
        'prerequisite_knowledge': ['前置知识', '前导知识'],
        'cognitive_misconceptions': ['认知误区', '常见误区'],
        'knowledge_points': ['主要知识点', '知识点'],
        'key_points': ['教学重点', '重点'],
        'difficult_points': ['教学难点', '难点'],
    }

    def _parse_structured_requirement(self, user_input: str) -> Dict:
        """
        本地解析用户输入的结构化教学需求文本（不依赖LLM）
        从“知识目标：... 授课时长：...”这类带标签文本中提取字段

        Args:
            user_input: 用户输入文本

        Returns:
            intent格式的部分字段字典，仅包含解析到的字段
        """
        label_field = {}
        for field, labels in self._STRUCT_FIELD_LABELS.items():
            for label in labels:
                label_field[label] = field

        # 长标签优先匹配，避免“受众”抢“受众年级”、“重点”抢“教学重点”
        all_labels = sorted(label_field.keys(), key=len, reverse=True)
        pattern = re.compile('(' + '|'.join(re.escape(label) for label in all_labels) + r')\s*[:：]')
        matches = list(pattern.finditer(user_input))
        if not matches:
            return {}

        # 每个标签的值 = 标签之后到下一个标签之前的文本
        raw_fields = {}
        for idx, match in enumerate(matches):
            field = label_field[match.group(1)]
            start = match.end()
            end = matches[idx + 1].start() if idx + 1 < len(matches) else len(user_input)
            value = user_input[start:end].strip()
            if value and field not in raw_fields:
                raw_fields[field] = value

        parsed = {}

        # 三层教学目标
        objective = {}
        for key in ('knowledge_objective', 'ability_objective', 'quality_objective'):
            if raw_fields.get(key):
                objective[key] = self._clean_scalar(raw_fields[key])
        if objective:
            parsed['teaching_objective'] = objective

        if raw_fields.get('duration'):
            parsed['duration'] = self._clean_scalar(raw_fields['duration'])
        if raw_fields.get('target_grade'):
            parsed['target_grade'] = self._clean_scalar(raw_fields['target_grade'])

        # 受众分析
        audience = {}
        if raw_fields.get('prerequisite_knowledge'):
            audience['prerequisite_knowledge'] = self._clean_scalar(raw_fields['prerequisite_knowledge'])
        if raw_fields.get('cognitive_misconceptions'):
            audience['cognitive_misconceptions'] = self._split_list_items(raw_fields['cognitive_misconceptions'])
        if audience:
            parsed['audience_analysis'] = audience

        if raw_fields.get('knowledge_points'):
            parsed['knowledge_points'] = self._split_list_items(raw_fields['knowledge_points'])

        # 教学重难点
        difficulties = {}
        if raw_fields.get('key_points'):
            difficulties['key_points'] = self._split_list_items(raw_fields['key_points'])
        if raw_fields.get('difficult_points'):
            difficulties['difficult_points'] = [
                self._parse_difficult_point(item)
                for item in self._split_list_items(raw_fields['difficult_points'])
            ]
        if difficulties:
            parsed['key_difficulties'] = difficulties

        logger.info(f"本地解析结构化需求完成，提取到字段: {list(parsed.keys())}")
        return parsed

    @staticmethod
    def _clean_scalar(value: str) -> str:
        """标量字段清洗：多行合并为一行（行间补分号），去除首尾分隔符"""
        value = re.sub(r'\s*\n\s*', '；', value.strip())
        value = re.sub(r'；{2,}', '；', value)
        return value.strip('；;，,、 \t')

    @staticmethod
    def _split_list_items(value: str) -> List[str]:
        """
        列表字段切分：按换行/分号拆项，去掉行首序号与项目符号
        不用顿号、逗号切分，防止切断括号内的枚举（如SYN_SENT、SYN_RCVD）
        """
        items = []
        for item in re.split(r'[\n；;]+', value):
            item = re.sub(r'^(?:\d+\s*[.、)）]\s*|[-•*]\s*)', '', item.strip())
            item = item.strip().strip('；;，,、 ')
            if item:
                items.append(item)
        return items

    @staticmethod
    def _parse_difficult_point(item: str) -> Dict:
        """解析单条教学难点：末尾括号内容作为难点成因，拆成{content, reason}结构"""
        match = re.match(r'^(.*?)[（(](.+)[）)]\s*$', item)
        if match:
            content = match.group(1).strip('，,、 ')
            reason = match.group(2).strip()
            if content and reason:
                return {'content': content, 'reason': reason}
        return {'content': item, 'reason': ''}

    def _merge_parsed_requirement(self, llm_intent: Dict, parsed: Dict) -> Dict:
        """
        合并本地解析结果与LLM意图：用户输入中明确写出的字段以用户原文为准，
        用户没写的字段（课堂活动、课堂提问、课件风格等）保留LLM的教学设计补全
        """
        merged = dict(llm_intent) if isinstance(llm_intent, dict) else {}
        merged.pop('error', None)

        for field in ('teaching_objective', 'duration', 'target_grade', 'knowledge_points'):
            if parsed.get(field):
                merged[field] = parsed[field]

        # 受众分析按子字段合并
        if parsed.get('audience_analysis'):
            audience = merged.get('audience_analysis')
            audience = dict(audience) if isinstance(audience, dict) else {}
            audience.update(parsed['audience_analysis'])
            merged['audience_analysis'] = audience

        # 教学重难点按子字段合并
        if parsed.get('key_difficulties'):
            key_difficulties = merged.get('key_difficulties')
            key_difficulties = dict(key_difficulties) if isinstance(key_difficulties, dict) else {}
            key_difficulties.update({k: v for k, v in parsed['key_difficulties'].items() if v})
            merged['key_difficulties'] = key_difficulties

        return merged
    
    def _detect_course_demand(self, user_input: str, conversation_history: List[Dict] = None) -> bool:
        """
        检测是否是课件需求
        
        Args:
            user_input: 用户输入
            conversation_history: 对话历史
            
        Returns:
            是否是课件需求
        """
        # 关键词检测
        course_keywords = ['课件', '教学', '教案', 'PPT', '讲义', '课程', '授课', '生成', '制作']
        user_input_lower = user_input.lower()
        
        # 检查用户输入是否包含课件相关关键词
        has_keyword = any(keyword in user_input_lower for keyword in course_keywords)
        
        # 检查对话历史中是否已经表达过课件需求
        if conversation_history:
            for msg in conversation_history[-3:]:  # 检查最近3轮对话
                content = msg.get('content', '').lower()
                if any(keyword in content for keyword in course_keywords):
                    return True
        
        return has_keyword
    
    def _generate_confirm_summary(self, intent: Dict) -> str:
        """
        生成确认总结文本
        
        Args:
            intent: 意图信息字典
            
        Returns:
            确认总结文本
        """
        teaching_objective = intent.get('teaching_objective', {})
        if isinstance(teaching_objective, dict):
            objective_text = f"""
知识目标：{teaching_objective.get('knowledge_objective', '未指定')}
能力目标：{teaching_objective.get('ability_objective', '未指定')}
素养目标：{teaching_objective.get('quality_objective', '未指定')}
"""
        else:
            objective_text = f"教学目标：{teaching_objective}"

        key_difficulties = intent.get('key_difficulties', {})
        if isinstance(key_difficulties, dict):
            key_points = key_difficulties.get('key_points', []) or []
            if isinstance(key_points, str):
                key_points = [key_points]
            difficult_points = key_difficulties.get('difficult_points', []) or []
            dp_texts = []
            for dp in difficult_points:
                if isinstance(dp, dict):
                    dp_text = dp.get('content', '')
                    if dp.get('reason'):
                        dp_text += f"（{dp['reason']}）"
                    dp_texts.append(dp_text)
                else:
                    dp_texts.append(str(dp))
            difficulties = f"教学重点：{', '.join(str(kp) for kp in key_points)}\n教学难点：{chr(10).join(dp_texts)}"
        elif isinstance(key_difficulties, (list, tuple)):
            difficulties = f"教学重难点：{', '.join(str(item) for item in key_difficulties)}"
        elif key_difficulties:
            difficulties = f"教学重难点：{key_difficulties}"
        else:
            difficulties = "教学重难点：未指定"

        audience_analysis = intent.get('audience_analysis', {})
        if isinstance(audience_analysis, dict):
            misconceptions = audience_analysis.get('cognitive_misconceptions', [])
            if isinstance(misconceptions, (list, tuple)):
                misconceptions_text = ', '.join(str(m) for m in misconceptions)
            else:
                misconceptions_text = str(misconceptions)
            audience_text = f"""
前置知识：{audience_analysis.get('prerequisite_knowledge', '未指定')}
认知误区：{misconceptions_text}
"""
        else:
            audience_text = ""

        knowledge_points = intent.get('knowledge_points', [])
        if isinstance(knowledge_points, str):
            knowledge_points_text = knowledge_points
        else:
            knowledge_points_text = ', '.join(str(p) for p in knowledge_points)

        summary = f"""
【教学需求确认】
{objective_text}
授课时长：{intent.get('duration', '未指定')}
受众年级：{intent.get('target_grade', '未指定')}
{audience_text}
知识点：{knowledge_points_text}
{difficulties}
"""
        return summary.strip()
    
    def analyze(self, user_input: str, conversation_history: List[Dict] = None, rag_context: str = None) -> Dict:
        """
        分析用户输入的教学意图
        
        Args:
            user_input: 用户输入文本
            conversation_history: 对话历史
            rag_context: 外部传入的RAG上下文
            
        Returns:
            结构化的教学意图信息
        """
        # 构建提示词
        prompt = f"""请分析以下教师的教学需求输入，提取结构化的教学要素：

教师输入：{user_input}

"""

        if conversation_history:
            prompt += f"\n对话历史：\n"
            for msg in conversation_history[-5:]:  # 只取最近5轮对话
                role = msg.get('role', 'user')
                content = msg.get('content', '')
                prompt += f"{role}: {content}\n"

        prompt += """
请以JSON格式返回分析结果，包含以下字段：
{
    "teaching_objective": {
        "knowledge_objective": "知识目标：学生应该掌握的具体知识内容",
        "ability_objective": "能力目标：学生应该具备的技能和能力",
        "quality_objective": "素养目标：学生应该培养的综合素质和价值观"
    },
    "duration": "授课时长（如：45分钟、90分钟）",
    "knowledge_points": ["知识点1", "知识点2", ...],
    "key_difficulties": {
        "key_points": ["教学重点1", "教学重点2"],
        "difficult_points": [{"content": "教学难点内容", "reason": "难点成因解释"}]
    },
    "target_grade": "受众年级（如：大学一年级高职学生）",
    "audience_analysis": {
        "prerequisite_knowledge": "前置知识要求",
        "cognitive_misconceptions": ["学生容易存在的认知误区1", "认知误区2"]
    },
    "classroom_activities": [
        {
            "activity": "活动名称",
            "description": "活动描述",
            "interaction_type": "问答/讨论/游戏/演示"
        }
    ],
    "classroom_questions": ["课堂提问1", "课堂提问2", "课堂提问3"],
    "style_preference": "课件风格偏好（如：简洁现代、活泼生动、专业严谨）",
    "special_requirements": "其他特殊要求"
}

注意事项：
1. 如果对话历史中已经包含了某些信息，请在分析时融合这些信息
2. 教学目标必须按照知识、能力、素养三层进行拆解，不能简单复制用户原话
3. 重难点要区分重点和难点，并解释难点成因
4. 要预判学生的前置知识和认知误区
5. 自动生成3-5个适配知识点的课堂提问
"""

        try:
            result = self.llm_client.structured_completion(prompt, self.system_prompt, rag_context=rag_context)
            logger.info(f"意图分析完成: {result.get('teaching_objective', 'N/A')}")
            return result
        except Exception as e:
            logger.error(f"意图分析失败: {e}")
            # LLM调用失败时返回空结果
            return {
                "error": str(e)
            }
    
    # 注释：已移除generate_clarification方法，不再生成追问
    # def generate_clarification(self, current_intent: Dict) -> str:
    #     """
    #     根据当前意图状态生成追问问题（已废弃）
    #     """
    #     pass
    
    def summarize_intent(self, intent: Dict) -> str:
        """
        总结教学意图
        
        Args:
            intent: 意图信息字典
            
        Returns:
            总结文本
        """
        # 适配新的教学目标结构
        teaching_objective = intent.get('teaching_objective', {})
        if isinstance(teaching_objective, dict):
            objective_text = f"""
知识目标：{teaching_objective.get('knowledge_objective', '未指定')}
能力目标：{teaching_objective.get('ability_objective', '未指定')}
素养目标：{teaching_objective.get('quality_objective', '未指定')}
"""
        else:
            objective_text = f"教学目标：{teaching_objective}"
        
        # 适配新的重难点结构
        key_difficulties = intent.get('key_difficulties', {})
        if isinstance(key_difficulties, dict):
            key_points = key_difficulties.get('key_points', [])
            difficult_points = key_difficulties.get('difficult_points', [])
            if difficult_points and isinstance(difficult_points[0], dict):
                difficulties_text = '\n'.join([f"{dp.get('content', '')}（{dp.get('reason', '')}）" for dp in difficult_points])
            else:
                difficulties_text = ', '.join(difficult_points)
            difficulties = f"教学重点：{', '.join(key_points)}\n教学难点：{difficulties_text}"
        else:
            difficulties = f"教学重难点：{', '.join(key_difficulties)}"
        
        # 适配新的受众分析结构
        audience_analysis = intent.get('audience_analysis', {})
        if isinstance(audience_analysis, dict):
            audience_text = f"""
前置知识：{audience_analysis.get('prerequisite_knowledge', '未指定')}
认知误区：{', '.join(audience_analysis.get('cognitive_misconceptions', []))}
"""
        else:
            audience_text = ""
        
        # 适配新的课堂活动结构
        classroom_activities = intent.get('classroom_activities', [])
        if classroom_activities and isinstance(classroom_activities[0], dict):
            activities_text = '\n'.join([f"{act.get('activity', '')}: {act.get('description', '')}" for act in classroom_activities])
        else:
            activities_text = ', '.join(classroom_activities)
        
        # 获取课堂提问
        classroom_questions = intent.get('classroom_questions', [])
        questions_text = '\n'.join([f"{i+1}. {q}" for i, q in enumerate(classroom_questions)])
        
        summary = f"""
【教学需求确认】
{objective_text}
授课时长：{intent.get('duration', '未指定')}
受众年级：{intent.get('target_grade', '未指定')}
{audience_text}
知识点：{', '.join(intent.get('knowledge_points', []))}
{difficulties}
课堂活动：
{activities_text}
课堂提问：
{questions_text}
课件风格：{intent.get('style_preference', '未指定')}
特殊要求：{intent.get('special_requirements', '无')}
"""
        return summary.strip()
    
    # 注释：已移除check_completeness方法，不再校验10项字段
    # def check_completeness(self, intent: Dict) -> bool:
    #     """
    #     检查意图信息是否完整（已废弃）
    #     """
    #     pass

    def apply_modification(self, current_intent: Dict, modification: str) -> Dict:
        """
        应用用户修改指令到当前意图
        
        Args:
            current_intent: 当前意图信息
            modification: 用户修改指令
            
        Returns:
            更新后的意图信息
        """
        # 构建修改指令处理提示词
        prompt = f"""请根据用户的修改指令，更新当前的教学意图信息。

当前教学意图：
{json.dumps(current_intent, ensure_ascii=False, indent=2)}

用户修改指令：{modification}

请以JSON格式返回更新后的教学意图，保持原有的字段结构。如果修改指令涉及某个字段的更新，请更新该字段；如果涉及新增内容，请相应添加。注意教学目标需要按照知识、能力、素养三层结构返回。

返回格式：
{{
    "teaching_objective": {{
        "knowledge_objective": "知识目标",
        "ability_objective": "能力目标", 
        "quality_objective": "素养目标"
    }},
    "duration": "更新后的授课时长",
    "knowledge_points": ["更新后的知识点列表"],
    "key_difficulties": {{
        "key_points": ["教学重点"],
        "difficult_points": [{{"content": "教学难点", "reason": "难点成因"}}]
    }},
    "target_grade": "更新后的受众年级",
    "audience_analysis": {{
        "prerequisite_knowledge": "前置知识",
        "cognitive_misconceptions": ["认知误区"]
    }},
    "classroom_activities": [
        {{
            "activity": "活动名称",
            "description": "活动描述",
            "interaction_type": "互动类型"
        }}
    ],
    "classroom_questions": ["课堂提问"],
    "style_preference": "更新后的风格偏好",
    "special_requirements": "更新后的特殊要求"
}}
"""

        try:
            updated_intent = self.llm_client.structured_completion(prompt, self.system_prompt)
            logger.info(f"修改指令应用完成: {modification}")
            # 直接返回更新后的意图，不添加默认值，让完整性检测识别缺失
            return updated_intent
        except Exception as e:
            logger.error(f"修改指令应用失败: {e}")
            # 降级处理：返回原意图
            return current_intent


# 全局意图分析器实例
_intent_analyzer = None


def get_intent_analyzer() -> IntentAnalyzer:
    """
    获取全局意图分析器实例（单例模式）
    
    Returns:
        IntentAnalyzer实例
    """
    global _intent_analyzer
    if _intent_analyzer is None:
        _intent_analyzer = IntentAnalyzer()
    return _intent_analyzer
