"""
用户认证与权限模块
- SQLite 存储用户账号（id / 用户名 / 密码哈希 / 角色 / 状态 / 创建时间）
- 角色 role（三级层级）：
  - super_admin（超级管理员）：可进入用户管理端，管理管理员和普通用户的全部操作
  - admin（管理员）：可进入用户管理端，只能管理普通用户（不能管理其他管理员或超管）
  - user（普通教师）：只能使用教学功能
- 状态 status：active（正常，可登录并使用接口）、disabled（禁用，无法登录、已有会话立即失效，历史数据保留）
- 提供注册、登录、登出、当前会话用户查询接口
- login_required / admin_required 装饰器保护业务接口与管理接口
会话基于 Flask 签名 Cookie（app.secret_key），前端无需额外处理 token
"""

import os
import re
import sqlite3
import logging
import functools
from datetime import datetime

from flask import Blueprint, request, jsonify, session, g
from werkzeug.security import generate_password_hash, check_password_hash

logger = logging.getLogger(__name__)

auth_bp = Blueprint('auth', __name__)

# 用户数据库：backend/data/users.db
_DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
_DB_PATH = os.path.join(_DB_DIR, 'users.db')

# 角色与状态枚举
ROLE_SUPER_ADMIN = 'super_admin'
ROLE_ADMIN = 'admin'
ROLE_USER = 'user'
VALID_ROLES = (ROLE_SUPER_ADMIN, ROLE_ADMIN, ROLE_USER)

# 权限层级：数字越大权限越高
ROLE_LEVELS = {
    ROLE_USER: 1,
    ROLE_ADMIN: 2,
    ROLE_SUPER_ADMIN: 3,
}

# 可进入管理端的角色
MANAGER_ROLES = (ROLE_SUPER_ADMIN, ROLE_ADMIN)

STATUS_ACTIVE = 'active'
STATUS_DISABLED = 'disabled'
VALID_STATUSES = (STATUS_ACTIVE, STATUS_DISABLED)

# 用户名：3-20位，支持中英文、数字、下划线
_USERNAME_PATTERN = re.compile(r'^[一-龥A-Za-z0-9_]{3,20}$')
_MIN_PASSWORD_LEN = 6


def _get_db():
    """获取 SQLite 连接"""
    os.makedirs(_DB_DIR, exist_ok=True)
    conn = sqlite3.connect(_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_column(conn, table, column, decl):
    """老库平滑迁移：缺少列时执行 ALTER TABLE ADD COLUMN"""
    cols = [row['name'] for row in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    if column not in cols:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {decl}')
        logger.info(f"用户表迁移：新增列 {table}.{column}")


def init_auth_db():
    """初始化用户表（应用启动时调用），并保证存在至少一个管理员账号"""
    os.makedirs(_DB_DIR, exist_ok=True)
    conn = _get_db()
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'user',
                status TEXT NOT NULL DEFAULT 'active',
                created_at TEXT NOT NULL
            )
            """
        )
        # 老版本库没有 role/status 列，自动补列并回填默认值
        _ensure_column(conn, 'users', 'role', f"TEXT NOT NULL DEFAULT '{ROLE_USER}'")
        _ensure_column(conn, 'users', 'status', f"TEXT NOT NULL DEFAULT '{STATUS_ACTIVE}'")
        conn.commit()

        # 首次启动创建默认超级管理员（可用环境变量覆盖，部署后请及时改密）
        admin_username = os.getenv('ADMIN_USERNAME', 'admin')
        admin_password = os.getenv('ADMIN_PASSWORD', 'admin123')
        row = conn.execute('SELECT id FROM users WHERE username = ?', (admin_username,)).fetchone()
        if not row:
            conn.execute(
                'INSERT INTO users (username, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, ?)',
                (admin_username, generate_password_hash(admin_password),
                 ROLE_SUPER_ADMIN, STATUS_ACTIVE, datetime.now().isoformat(timespec='seconds'))
            )
            conn.commit()
            logger.info(f"已创建默认超级管理员账号: {admin_username}（请尽快修改默认密码）")

        # 老库迁移：如果没有超级管理员，把默认 admin 账号升级为超级管理员
        super_count = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE role = ?', (ROLE_SUPER_ADMIN,)
        ).fetchone()['c']
        if super_count == 0:
            conn.execute(
                'UPDATE users SET role = ? WHERE username = ?',
                (ROLE_SUPER_ADMIN, admin_username)
            )
            conn.commit()
            logger.info(f"已将账号 {admin_username} 升级为超级管理员（兼容旧库迁移）")

        logger.info(f"用户数据库初始化完成: {_DB_PATH}")
    finally:
        conn.close()


def _validate_credentials(username, password):
    """校验用户名/密码格式，返回错误信息；通过则返回 None"""
    if not username or not password:
        return '用户名和密码不能为空'
    if not _USERNAME_PATTERN.match(username):
        return '用户名需为3-20位，支持中英文、数字、下划线'
    if len(password) < _MIN_PASSWORD_LEN:
        return f'密码长度不能少于{_MIN_PASSWORD_LEN}位'
    return None


def _find_user_by_name(conn, username):
    return conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()


def _public_user(row):
    """去除敏感字段后的用户信息"""
    return {
        'id': row['id'],
        'username': row['username'],
        'role': row['role'],
        'status': row['status'],
        'created_at': row['created_at']
    }


def load_current_user():
    """
    载入当前会话用户并缓存到 g：
    - 未登录返回 None
    - 账号被禁用/已删除同样视为未认证，并清掉失效会话
    """
    if 'current_user' in g:
        return g.current_user

    user_id = session.get('user_id')
    if not user_id:
        g.current_user = None
        return None

    conn = _get_db()
    try:
        row = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    finally:
        conn.close()

    if not row:
        session.clear()
        g.current_user = None
        return None

    g.current_user = _public_user(row)
    return g.current_user


def current_user():
    """获取当前登录用户信息，未登录返回 None"""
    return load_current_user()


def login_required(view):
    """登录与账号状态校验装饰器：未登录401，账号禁用403"""
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        user = load_current_user()
        if not user:
            return jsonify({
                'success': False,
                'code': 'UNAUTHORIZED',
                'error': '未登录或登录状态已过期，请先登录'
            }), 401
        if user.get('status') != STATUS_ACTIVE:
            return jsonify({
                'success': False,
                'code': 'ACCOUNT_DISABLED',
                'error': '账号已被禁用，请联系管理员'
            }), 403
        return view(*args, **kwargs)
    return wrapped


def can_manage(operator, target):
    """
    判断操作者是否有权管理目标用户：
    - 超级管理员可管理管理员和普通用户，但不能管理其他超管
    - 管理员只能管理普通用户
    - 任何人都不能管理自己（由调用方另行检查）
    """
    op_level = ROLE_LEVELS.get(operator['role'], 0)
    tgt_level = ROLE_LEVELS.get(target['role'], 0)
    return op_level > tgt_level


def admin_required(view):
    """管理端权限装饰器：超管和管理员均可进入，非管理角色403"""
    @functools.wraps(view)
    @login_required
    def wrapped(*args, **kwargs):
        if g.current_user.get('role') not in MANAGER_ROLES:
            return jsonify({
                'success': False,
                'code': 'FORBIDDEN',
                'error': '需要管理员权限'
            }), 403
        return view(*args, **kwargs)
    return wrapped


@auth_bp.route('/api/auth/register', methods=['POST'])
def register():
    """用户注册：注册账号一律为普通用户，注册成功后自动登录并建立会话"""
    try:
        data = request.get_json() or {}
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''

        error = _validate_credentials(username, password)
        if error:
            return jsonify({'success': False, 'error': error}), 400

        conn = _get_db()
        try:
            if _find_user_by_name(conn, username):
                return jsonify({'success': False, 'error': '用户名已存在，请更换或直接登录'}), 409

            now = datetime.now().isoformat(timespec='seconds')
            cursor = conn.execute(
                'INSERT INTO users (username, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, ?)',
                (username, generate_password_hash(password), ROLE_USER, STATUS_ACTIVE, now)
            )
            conn.commit()
            user_id = cursor.lastrowid
            logger.info(f"新用户注册: id={user_id}, username={username}")
        finally:
            conn.close()

        # 注册成功自动登录
        session.clear()
        session['user_id'] = user_id
        session['username'] = username

        return jsonify({
            'success': True,
            'message': '注册成功',
            'user': {'id': user_id, 'username': username,
                     'role': ROLE_USER, 'status': STATUS_ACTIVE, 'created_at': now}
        })

    except Exception as e:
        logger.error(f"用户注册错误: {str(e)}")
        return jsonify({'success': False, 'error': f'注册失败: {str(e)}'}), 500


@auth_bp.route('/api/auth/login', methods=['POST'])
def login():
    """用户登录（管理员与普通用户共用，按角色进入不同界面）"""
    try:
        data = request.get_json() or {}
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''

        if not username or not password:
            return jsonify({'success': False, 'error': '用户名和密码不能为空'}), 400

        conn = _get_db()
        try:
            row = _find_user_by_name(conn, username)
            if not row or not check_password_hash(row['password_hash'], password):
                return jsonify({'success': False, 'error': '用户名或密码错误'}), 401
            if row['status'] != STATUS_ACTIVE:
                return jsonify({'success': False, 'code': 'ACCOUNT_DISABLED',
                                'error': '账号已被禁用，请联系管理员'}), 403
            user = _public_user(row)
        finally:
            conn.close()

        # 防止登录后固定会话攻击
        session.clear()
        session['user_id'] = user['id']
        session['username'] = user['username']
        logger.info(f"用户登录: id={user['id']}, username={username}, role={user['role']}")

        return jsonify({
            'success': True,
            'message': '登录成功',
            'user': user
        })

    except Exception as e:
        logger.error(f"用户登录错误: {str(e)}")
        return jsonify({'success': False, 'error': f'登录失败: {str(e)}'}), 500


@auth_bp.route('/api/auth/logout', methods=['POST'])
def logout():
    """退出登录"""
    username = session.get('username')
    session.clear()
    g.pop('current_user', None)
    logger.info(f"用户退出登录: {username}")
    return jsonify({'success': True, 'message': '已退出登录'})


@auth_bp.route('/api/auth/me', methods=['GET'])
def me():
    """查询当前登录用户（含角色与状态）"""
    user = load_current_user()
    if not user:
        return jsonify({'success': False, 'error': '未登录'}), 401
    return jsonify({'success': True, 'user': user})
