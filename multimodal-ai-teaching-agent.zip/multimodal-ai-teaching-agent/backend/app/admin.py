"""
用户管理端 API
- 超级管理员（super_admin）可管理：管理员 + 普通用户（新增/改角色/启禁用/重置密码/删除）
- 管理员（admin）可管理：仅普通用户
- 任何人不能管理同级或上级（can_manage 基于 ROLE_LEVELS 层级判断）
- 自锁保护：不能修改/删除自己
- 最后超管保护：系统必须保留至少一个启用的超级管理员

接口：
- GET  /api/admin/stats          用户概览统计
- GET  /api/admin/users          用户列表（分页 + 关键字 + 角色/状态筛选）
- POST /api/admin/users          新增用户（超管可指定任意角色，管理员只能新增普通用户）
- PUT  /api/admin/users/<id>     修改角色 / 启用禁用 / 重置密码
- DELETE /api/admin/users/<id>   删除用户
"""

import logging
from datetime import datetime

from flask import Blueprint, request, jsonify, g
from werkzeug.security import generate_password_hash

from app.auth import (
    _get_db, _find_user_by_name, _validate_credentials,
    admin_required, _public_user, can_manage,
    ROLE_SUPER_ADMIN, ROLE_ADMIN, ROLE_USER, VALID_ROLES,
    MANAGER_ROLES, ROLE_LEVELS,
    STATUS_ACTIVE, STATUS_DISABLED, VALID_STATUSES,
)

logger = logging.getLogger(__name__)

admin_bp = Blueprint('admin', __name__)

DEFAULT_PAGE_SIZE = 10
MAX_PAGE_SIZE = 100


def _get_user_or_404(conn, user_id):
    return conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()


def _count_by_role(conn, role, exclude_id=None, active_only=False):
    """统计指定角色的用户数量"""
    sql = "SELECT COUNT(*) AS c FROM users WHERE role = ?"
    params = [role]
    if active_only:
        sql += " AND status = ?"
        params.append(STATUS_ACTIVE)
    if exclude_id is not None:
        sql += " AND id != ?"
        params.append(exclude_id)
    return conn.execute(sql, params).fetchone()['c']


def _can_create_role(operator_role, target_role):
    """判断操作者能否创建指定角色的用户"""
    # 超管可创建任意角色；管理员只能创建普通用户
    if operator_role == ROLE_SUPER_ADMIN:
        return True
    if operator_role == ROLE_ADMIN:
        return target_role == ROLE_USER
    return False


@admin_bp.route('/api/admin/stats', methods=['GET'])
@admin_required
def admin_stats():
    """用户概览：总数、正常、禁用、超级管理员、管理员、普通用户、今日新增"""
    conn = _get_db()
    try:
        total = conn.execute('SELECT COUNT(*) AS c FROM users').fetchone()['c']
        active = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE status = ?', (STATUS_ACTIVE,)).fetchone()['c']
        disabled = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE status = ?', (STATUS_DISABLED,)).fetchone()['c']
        super_admins = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE role = ?', (ROLE_SUPER_ADMIN,)).fetchone()['c']
        admins = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE role = ?', (ROLE_ADMIN,)).fetchone()['c']
        users = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE role = ?', (ROLE_USER,)).fetchone()['c']
        today = datetime.now().date().isoformat()
        new_today = conn.execute(
            'SELECT COUNT(*) AS c FROM users WHERE created_at LIKE ?', (today + '%',)).fetchone()['c']
    finally:
        conn.close()

    return jsonify({
        'success': True,
        'stats': {
            'total': total,
            'active': active,
            'disabled': disabled,
            'super_admins': super_admins,
            'admins': admins,
            'users': users,
            'new_today': new_today
        }
    })


@admin_bp.route('/api/admin/users', methods=['GET'])
@admin_required
def admin_list_users():
    """用户分页列表（超管和管理员均可查看全部用户，但操作权限不同）"""
    try:
        page = max(1, int(request.args.get('page', 1)))
        page_size = min(MAX_PAGE_SIZE, max(1, int(request.args.get('page_size', DEFAULT_PAGE_SIZE))))
        keyword = (request.args.get('keyword') or '').strip()
        role = request.args.get('role') or ''
        status = request.args.get('status') or ''

        if role and role not in VALID_ROLES:
            return jsonify({'success': False, 'error': '非法的角色筛选值'}), 400
        if status and status not in VALID_STATUSES:
            return jsonify({'success': False, 'error': '非法的状态筛选值'}), 400

        where = []
        params = []
        if keyword:
            where.append('username LIKE ?')
            params.append(f'%{keyword}%')
        if role:
            where.append('role = ?')
            params.append(role)
        if status:
            where.append('status = ?')
            params.append(status)
        where_sql = ('WHERE ' + ' AND '.join(where)) if where else ''

        conn = _get_db()
        try:
            total = conn.execute(
                f'SELECT COUNT(*) AS c FROM users {where_sql}', params).fetchone()['c']
            rows = conn.execute(
                f'SELECT * FROM users {where_sql} ORDER BY id ASC LIMIT ? OFFSET ?',
                params + [page_size, (page - 1) * page_size]
            ).fetchall()
        finally:
            conn.close()

        return jsonify({
            'success': True,
            'total': total,
            'page': page,
            'page_size': page_size,
            'users': [_public_user(r) for r in rows]
        })

    except ValueError:
        return jsonify({'success': False, 'error': '分页参数格式错误'}), 400
    except Exception as e:
        logger.error(f"查询用户列表错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api/admin/users', methods=['POST'])
@admin_required
def admin_create_user():
    """新增用户：超管可指定任意角色，管理员只能新增普通用户"""
    try:
        data = request.get_json() or {}
        username = (data.get('username') or '').strip()
        password = data.get('password') or ''
        role = data.get('role') or ROLE_USER
        status = data.get('status') or STATUS_ACTIVE
        operator_role = g.current_user['role']

        error = _validate_credentials(username, password)
        if error:
            return jsonify({'success': False, 'error': error}), 400
        if role not in VALID_ROLES:
            return jsonify({'success': False, 'error': '角色取值非法'}), 400
        if status not in VALID_STATUSES:
            return jsonify({'success': False, 'error': '状态取值非法'}), 400
        # 管理员只能创建普通用户
        if not _can_create_role(operator_role, role):
            return jsonify({'success': False,
                            'error': '权限不足：管理员只能创建普通用户，创建管理员需超级管理员权限'}), 403

        conn = _get_db()
        try:
            if _find_user_by_name(conn, username):
                return jsonify({'success': False, 'error': '用户名已存在'}), 409
            now = datetime.now().isoformat(timespec='seconds')
            cursor = conn.execute(
                'INSERT INTO users (username, password_hash, role, status, created_at) VALUES (?, ?, ?, ?, ?)',
                (username, generate_password_hash(password), role, status, now)
            )
            conn.commit()
            user_id = cursor.lastrowid
            row = _get_user_or_404(conn, user_id)
        finally:
            conn.close()

        logger.info(f"管理员 {g.current_user['username']}({operator_role}) 新增用户: {username}(id={user_id}, role={role})")
        return jsonify({'success': True, 'message': '用户创建成功', 'user': _public_user(row)})

    except Exception as e:
        logger.error(f"新增用户错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api/admin/users/<int:user_id>', methods=['PUT'])
@admin_required
def admin_update_user(user_id):
    """
    修改用户（仅传需要修改的字段）：
    - role: super_admin/admin/user     角色变更
    - status: active/disabled          启用/禁用
    - password: 新密码（至少6位）
    权限边界：超管可改管理员和用户；管理员只能改普通用户
    """
    try:
        data = request.get_json() or {}
        role = data.get('role')
        status = data.get('status')
        password = data.get('password')
        operator = g.current_user
        operator_id = operator['id']
        operator_role = operator['role']

        if role is not None and role not in VALID_ROLES:
            return jsonify({'success': False, 'error': '角色取值非法'}), 400
        if status is not None and status not in VALID_STATUSES:
            return jsonify({'success': False, 'error': '状态取值非法'}), 400
        if password is not None and len(password) < 6:
            return jsonify({'success': False, 'error': '密码长度不能少于6位'}), 400
        if role is None and status is None and password is None:
            return jsonify({'success': False, 'error': '没有需要更新的字段'}), 400

        conn = _get_db()
        try:
            row = _get_user_or_404(conn, user_id)
            if not row:
                return jsonify({'success': False, 'error': '用户不存在'}), 404

            target = _public_user(row)

            # 自锁保护：不能修改自己的角色或状态（重置密码可以）
            if user_id == operator_id and (role is not None or status is not None):
                return jsonify({'success': False,
                                'error': '不能修改当前登录账号自身的角色或状态（防止误锁账号）'}), 400

            # 权限边界：操作者权限必须高于目标用户
            if role is not None or status is not None:
                if not can_manage(operator, target):
                    return jsonify({'success': False,
                                    'error': '权限不足：不能管理同级或上级账号'}), 403

            # 角色变更的额外校验：管理员不能将用户提升为管理员或超管
            if role is not None and operator_role == ROLE_ADMIN and role != ROLE_USER:
                return jsonify({'success': False,
                                'error': '权限不足：管理员只能将用户保持为普通用户，提升为管理员需超级管理员权限'}), 403

            # 防止取消最后一个启用的超级管理员
            target_is_active_super = row['role'] == ROLE_SUPER_ADMIN and row['status'] == STATUS_ACTIVE
            will_lose_super = target_is_active_super and (
                role in (ROLE_ADMIN, ROLE_USER) or status == STATUS_DISABLED
            )
            if will_lose_super and _count_by_role(conn, ROLE_SUPER_ADMIN, exclude_id=user_id, active_only=True) < 1:
                return jsonify({'success': False,
                                'error': '系统必须保留至少一个启用的超级管理员'}), 400

            if role is not None:
                conn.execute('UPDATE users SET role = ? WHERE id = ?', (role, user_id))
            if status is not None:
                conn.execute('UPDATE users SET status = ? WHERE id = ?', (status, user_id))
            if password is not None:
                conn.execute('UPDATE users SET password_hash = ? WHERE id = ?',
                             (generate_password_hash(password), user_id))
            conn.commit()
            row = _get_user_or_404(conn, user_id)
        finally:
            conn.close()

        logger.info(f"管理员 {operator['username']}({operator_role}) 更新用户 id={user_id}: "
                    f"role={role}, status={status}, password_reset={password is not None}")
        return jsonify({'success': True, 'message': '保存成功', 'user': _public_user(row)})

    except Exception as e:
        logger.error(f"更新用户错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@admin_bp.route('/api/admin/users/<int:user_id>', methods=['DELETE'])
@admin_required
def admin_delete_user(user_id):
    """删除用户：权限必须高于目标；不能删除自己；不能删除最后一个超管"""
    try:
        operator = g.current_user
        operator_id = operator['id']

        if user_id == operator_id:
            return jsonify({'success': False, 'error': '不能删除当前登录的账号'}), 400

        conn = _get_db()
        try:
            row = _get_user_or_404(conn, user_id)
            if not row:
                return jsonify({'success': False, 'error': '用户不存在'}), 404

            target = _public_user(row)

            # 权限边界：操作者权限必须高于目标用户
            if not can_manage(operator, target):
                return jsonify({'success': False,
                                'error': '权限不足：不能删除同级或上级账号'}), 403

            # 防止删除最后一个启用的超级管理员
            if row['role'] == ROLE_SUPER_ADMIN and row['status'] == STATUS_ACTIVE \
                    and _count_by_role(conn, ROLE_SUPER_ADMIN, exclude_id=user_id, active_only=True) < 1:
                return jsonify({'success': False,
                                'error': '系统必须保留至少一个启用的超级管理员'}), 400

            conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
            conn.commit()
        finally:
            conn.close()

        logger.info(f"管理员 {operator['username']}({operator['role']}) 删除用户 id={user_id}")
        return jsonify({'success': True, 'message': '用户已删除'})

    except Exception as e:
        logger.error(f"删除用户错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500
