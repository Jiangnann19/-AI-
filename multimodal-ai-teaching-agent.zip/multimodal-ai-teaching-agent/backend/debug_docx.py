# -*- coding: utf-8 -*-
"""
单独调试 docx 解析逻辑：
1) python-docx 直接读取 uploads 下的 docx 文件，打印段落数/内容，验证是否报错或读到空内容
2) 模拟 /api/knowledge/upload 的完整链路（parse -> chunk -> add_documents），定位失败环节
全程不触碰 OCR 模块
"""
import os
import sys
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('debug_docx')

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')


def step1_raw_python_docx(file_path):
    """只用 python-docx 读文件，不经过任何项目代码"""
    print(f"\n{'=' * 60}")
    print(f"[步骤1] python-docx 直接读取: {file_path}")
    print(f"{'=' * 60}")
    try:
        from docx import Document
        doc = Document(file_path)
        paras = [p.text for p in doc.paragraphs]
        non_empty = [p for p in paras if p.strip()]
        print(f"  段落总数: {len(paras)}, 非空段落: {len(non_empty)}")
        print(f"  表格数: {len(doc.tables)}")
        for i, p in enumerate(non_empty[:5]):
            print(f"  段落{i + 1}: {p[:80]!r}")
        table_text = 0
        for t in doc.tables:
            for row in t.rows:
                for cell in row.cells:
                    table_text += len(cell.text.strip())
        print(f"  表格字符总量: {table_text}")
        print(f"  => 结论: python-docx 读取正常")
        return True
    except Exception as e:
        import traceback
        print(f"  => 结论: python-docx 读取报错: {type(e).__name__}: {e}")
        traceback.print_exc()
        return False


def step2_project_parser(file_path):
    """走项目里的 document_parser.parse()，看 full_text 是否为空"""
    print(f"\n{'=' * 60}")
    print(f"[步骤2] 项目 DocumentParser.parse: {file_path}")
    print(f"{'=' * 60}")
    from app.parsers.document_parser import get_document_parser
    parser = get_document_parser()
    parsed = parser.parse(file_path)
    full_text = parsed.get('full_text', '')
    print(f"  type={parsed.get('type')!r}, full_text长度={len(full_text)}")
    print(f"  full_text前120字符: {full_text[:120]!r}")
    print(f"  => 结论: {'提取到文本' if full_text.strip() else '提取文本为空！！'}")
    return full_text


def step3_full_pipeline(file_path):
    """模拟 /api/knowledge/upload: parse -> chunk -> add_documents（需要DashScope联网）"""
    print(f"\n{'=' * 60}")
    print(f"[步骤3] 完整入库链路: {file_path}")
    print(f"{'=' * 60}")
    from app.parsers.document_parser import get_document_parser
    from rag.vector_store import get_vector_store

    parser = get_document_parser()
    parsed = parser.parse(file_path)
    full_text = parsed.get('full_text', '')
    if not full_text.strip():
        print("  => full_text为空，流程在这里就会跳过入库（count不增加）")
        return

    kb = get_vector_store()
    chunks = kb.chunk_text(full_text, chunk_size=500, overlap=50)
    print(f"  分块数: {len(chunks)}")

    try:
        added = kb.add_documents(chunks, metadatas=[{'source': 'debug_test', 'type': 'debug'} for _ in chunks])
        print(f"  入库块数: {added}")
        print(f"  => 结论: 入库成功")
        # 清掉调试数据
        kb.delete_document('debug_test')
        print(f"  调试数据已清理")
    except Exception as e:
        import traceback
        print(f"  => 结论: 入库失败: {type(e).__name__}: {e}")
        traceback.print_exc()


if __name__ == '__main__':
    targets = []
    for name in ['TCP.docx', 'docx']:
        p = os.path.join(UPLOAD_DIR, name)
        if os.path.exists(p):
            targets.append(p)

    which = sys.argv[1] if len(sys.argv) > 1 else 'all'

    for p in targets:
        if which in ('1', 'all'):
            step1_raw_python_docx(p)
        if which in ('2', 'all'):
            step2_project_parser(p)

    # 完整链路只对第一个目标跑一次（避免重复联网调用）
    if which in ('3', 'all') and targets:
        step3_full_pipeline(targets[0])
