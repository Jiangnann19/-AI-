# -*- coding: utf-8 -*-
"""
端到端验证：模拟前端 POST /api/knowledge/upload 上传中文名 docx，
确认 解析->分块->向量化->入库 全链路成功，验证后清理测试数据
"""
import io
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import importlib.util

_backend_dir = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location('flask_app', os.path.join(_backend_dir, 'app.py'))
_flask_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_flask_module)
app = _flask_module.app

from rag.vector_store import get_vector_store

SRC = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads', 'TCP.docx')
CN_NAME = '教案调试验证.docx'


def main():
    with open(SRC, 'rb') as f:
        data = f.read()

    client = app.test_client()
    resp = client.post(
        '/api/knowledge/upload',
        data={'files': (io.BytesIO(data), CN_NAME)},
        content_type='multipart/form-data'
    )
    result = resp.get_json()
    print(f"\nHTTP状态: {resp.status_code}")
    print(f"返回: success={result.get('success')}, count={result.get('count')}, total_chunks={result.get('total_chunks')}")
    for f in result.get('uploaded_files', []):
        print(f"  文件: {f['filename']}, 提取{f['text_length']}字符, 分块{f['chunks']}, 入库{f['added']}")

    ok = result.get('success') and result.get('count') == 1 and result.get('total_chunks', 0) > 0
    print(f"\n=> 端到端验证: {'通过 ✓' if ok else '失败 ✗'}")

    # 抽查入库内容是否为正文（检索TCP相关）
    if ok:
        kb = get_vector_store()
        hits = kb.search('TCP三次握手', top_k=1, similarity_threshold=0)
        if hits:
            print(f"检索抽查: 来源={hits[0]['metadata'].get('source')}, 内容前60字={hits[0]['content'][:60]!r}")
        deleted = kb.delete_document(CN_NAME)
        print(f"测试数据已清理: 删除{deleted}块")

        # 检查知识库是否残留历史垃圾数据（之前中文名上传产生的占位文本）
        stats = kb.get_stats()
        print(f"\n当前知识库: {stats['total_documents']}个文档, {stats['total_chunks']}个块")
        for doc_name in stats['documents']:
            print(f"  文档: {doc_name!r} ({stats['doc_stats'][doc_name]}块)")


if __name__ == '__main__':
    main()
